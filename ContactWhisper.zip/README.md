# ContactWhisper — Smart Contact Manager

An offline Android contact manager (Kotlin + Jetpack Compose UI, Java data structures & algorithms, Room/SQLite storage).
No account, no sign-in, no cloud sync, no internet permission, no external speech API, no LLM. Your contacts stay on the phone.

Package `com.contactwhisper.app` · Version 1.0.0 · minSdk 26 · targetSdk/compileSdk 35 · target device: Vivo Y15C

---

## 1. Build and run

Requirements: Android Studio (Koala or newer) **or** JDK 17+ and the Android SDK (platform 35) with `ANDROID_HOME` /
`local.properties` (`sdk.dir=...`). Internet is needed once, to download Gradle and the dependencies.

```bash
./gradlew assembleDebug               # app/build/outputs/apk/debug/app-debug.apk
./gradlew testDebugUnitTest           # JVM unit tests (Java DSA, validator, PIN hashing, voice parser + state machine)
./gradlew connectedDebugAndroidTest   # instrumented tests (needs a phone/emulator)
./gradlew installDebug                # install on a connected phone (USB debugging on)
```

Windows: `gradlew.bat`. Gradle wrapper 8.9 (paired with AGP 8.7.3), Kotlin 2.0.21, KSP 2.0.21-1.0.28, Compose BOM 2024.12.01,
Room 2.6.1, DataStore 1.1.1, WorkManager 2.9.1, Biometric 1.1.0, Navigation Compose 2.8.5.

> **Status:** this refinement pass was written in a cloud sandbox that cannot reach Google Maven, Maven Central or the Android
> SDK, so **`./gradlew assembleDebug` has not been run on this code**. Section 8 lists exactly what was and was not verified.
> Please run the build once and send me the first compiler message, if any.

**Colours:** Emerald card `#051912`; Crimson card `#3A101A` (muted, charcoal-mixed). `#78081C` is the crimson reference used for outlines, indicators and pressed states (defined once in `ui/theme/Theme.kt`; the Appearance previews read the same palettes).

Roboto: add `roboto_regular.ttf`, `roboto_medium.ttf`, `roboto_bold.ttf` to `app/src/main/res/font/` (see `docs/ASSETS.md`).

## 2. Features

| Area | What it does |
|---|---|
| Launch | Splash (icon, gradient "Contact Whisper", ivory "Smart Contact Manager", lighter "Every Contact, One Whisper Away.", faint crimson + emerald **corner** glows, no loading text) → local profile setup → Home. |
| Profile setup | Photo ringed in crimson **and** emerald with a small two-colour camera badge, recessed inputs with two-colour outlines, "This info is stored on this device only.", emerald Continue button with crimson outline. |
| Phone import | After the profile exists, Home explains why the app wants your phone contacts, then asks for `READ_CONTACTS`. Names, numbers and e-mails are copied **into the local database** (never uploaded), duplicates are skipped, the search indexes are rebuilt, and a summary lists what was skipped or conflicted. Runs on a background thread. Done once; **Profile Customization › Import phone contacts** repeats it safely (nothing you created or edited is touched). Denying the permission leaves the app fully usable. "ICE"/"Emergency" phonebook entries come in as ordinary contacts; the Emergency Services list stays separate. |
| Home | Header: profile, **Undo, Redo** (disabled when empty), Settings gear. One universal search box (name, phone, email, address, notes, category) with the Search and Mic icons inside it. "**Sort by:**" menu (A–Z, Z–A, Recently Added, By Category) opens as separate solid gray cards with an ivory outline, cascading downward. Emergency Services panel, contact cards (Call icon, then Favorite). Add button. Exactly four bottom tabs: Home, Categories, Favorites, Bin. |
| Contacts | Add / view / edit / delete (delete = move to Bin). Name and phone required. Manual add/edit requires an **11-digit Pakistani mobile** (spaces/hyphens ignored, `+92 3xx` becomes `03xx`). Imported numbers are kept exactly as imported and stay valid until you edit them. Duplicate warnings never merge or delete. |
| Categories | Family, Friends, Work, Other + your own (create / rename / delete; contacts of a deleted category move to "Other"). Arrow at the far right of every row. Same card gestures inside expanded categories. |
| Favorites | Starred contacts, same cards and gestures. |
| Emergency Services | Own screen. Cards show name, number and a call button only (no edit/delete icons): tap opens details/edit, horizontal swipe edits, **double-tap moves it to the Bin** (restoring returns it to the Emergency list), drag-down dials. No 11-digit rule for these numbers. The seeded 100 / 102 / 112 / 1122 are editable **samples, not verified as official**. |
| Bin | Back arrow to Home. Deleted contacts and emergency entries, 30-day retention. Select All, Restore Selected, Restore All, Delete Selected Permanently, Delete All (always confirmed), per-item restore/delete. Centered "Bin is empty" state. |
| Undo / Redo | Two custom Java stacks. Add, edit, delete, favorite, category change and **restore from the Bin** are all undoable. Permanent deletion is irreversible and purges history, see section 4. |
| App Lock | "Enable App Lock": fingerprint / device screen lock, or an app PIN. Touch-only. |
| Appearance | "Choose a theme / It is applied to every screen." Two large live miniatures titled **Crimson** and **Emerald**. |
| About | Icon, gradient title, feature cards, developer section with the watermark. |
| Settings | Exactly four entries: Profile Customization, Appearance, App Lock, About. (Hidden contacts and Help were removed.) |
| Notifications | Rounded charcoal card with an icon and theme accent; Undo on delete; auto-dismiss after 2 s; swipe to dismiss; never blocks touches. |
| Voice assistant | Section 7. |
| Calling | Section 3. |
| Background | WorkManager daily job purges Bin entries older than 30 days (also at start-up). |

Not included on purpose: blocked contacts, call history, cloud sync, Google sign-in, Help screen, hidden contacts.

## 3. Gestures and calling

| Gesture | Action |
|---|---|
| Tap | Open Contact Details (waits the system double-tap timeout, ~300 ms, to tell it from a double tap) |
| Double tap | ~500 ms smoke burst from the card centre, then move to the Bin (Room + index), Undo snackbar |
| **Hold** ~250 ms (card lifts slightly + soft haptic tick), then drag **down** ≥ 80 dp and release | The whole card moves as one rigid object with slight spring lag/resistance (no stretch or tilt), springs back in ~150–200 ms, and the call starts **immediately on release**, exactly once |
| Horizontal swipe | Open Edit |
| Two-finger swipe left→right / right→left | Undo / Redo (app-wide) |
| One-finger swipe left→right across the search bar | Opens the voice assistant |

A press starts undecided and nothing is consumed. Quick release → tap / double-tap. Movement past touch-slop *before* the 250 ms hold
completes: mostly horizontal → edit swipe, anything vertical → abandoned so the list scrolls (never calls). After the hold only a
downward drag starts the pull; up/sideways cancels (no call, no edit); releasing a hold without pulling does nothing (so it can never
feed double-tap delete). Release below 80 dp never calls; a second finger or cancellation never calls. The Call/Favorite buttons are excluded from the
card gestures and every gesture has a visible alternative (buttons, details screen, TalkBack custom actions).

**Calling is not permission-free.** Personal contacts: if `CALL_PHONE` is granted the call is placed directly (`ACTION_CALL`);
otherwise the system dialer opens with the number filled in (`ACTION_DIAL`). The permission is requested once, on the first call
attempt; if refused, the dialer is used from then on. **Emergency Services numbers always open the dialer** (Android restricts
direct emergency calling by apps). Decision code: `ui/components/Caller.kt`; intents: `util/Dialer.kt`.

**The delete smoke is a procedural approximation.** `ui/components/Smoke.kt` draws 13 soft, stretched, curving wisps (layered
blobs with varied size, opacity, speed and delay) plus a dense core, in the theme's crimson or emerald, for 500 ms, then releases
its particle table. It is **not** the supplied video (a video has no alpha channel and would show a black rectangle), and it is
not photographic smoke; a real smoke texture sequence with transparency would look better and could replace `drawSmokeBurst`
without touching the gesture code.

## 4. Undo/Redo integrity

* History entries hold **stable contact ids and immutable snapshots**, not mutable contact objects.
* Restoring from the Bin is recorded (`UndoableAction.RESTORE`): Undo sends the contact back to the Bin, Redo restores it again.
* **Permanent deletion** (one, selected, Select All / Delete All, or the automatic 30-day purge) erases the Room rows and index
  entries, then calls `UndoRedoManager.purgeContacts(ids)`, which removes **every** Add / Edit / Delete / Restore / Favorite
  entry that mentions those ids from **both** stacks. Nothing in the history can re-create a permanently deleted contact.
* Emergency Services entries live in their own table; they are recoverable from the Bin but have **no Undo/Redo history**
  (the delete snackbar's Undo restores them directly).
* History is memory-only: it starts empty after the process restarts (the Bin does not).

Tested scenarios (`UndoRedoManagerTest`, `tools/jvm-check/RepoCheck.kt`): add → permanently delete → Undo cannot restore;
delete → restore → Undo returns it to the Bin; restore → Redo restores again; delete → Undo returns it; permanent delete after
several edits leaves no older entry able to re-create it; Select All / Delete All; auto-purge.

## 5. Architecture and DSA

```
app/src/main/java/com/contactwhisper/app
├── dsa/        Java: ContactRecord, ContactNode, ContactLinkedList, ContactHashTable, CustomStack<T> (+removeIf),
│               ContactAlgorithms (search + merge sort), ContactIndex, DuplicateDetector, UndoableAction, UndoRedoManager, SortMode
├── domain/     Java: ContactValidator (+ Pakistani mobile rules)
├── data/       Room entities/DAOs/AppDatabase (v2 + migration), ContactRepository (single entry point, import),
│               EmergencyRepository (+Bin), DeviceContactReader, SettingsStore (DataStore), PinHasher
├── auth/       AuthController (BiometricPrompt + PIN dialog) — used only by touch UI
├── voice/      VoiceCommandParser, VoiceConversation (pure state machine), VoiceAssistant, SpeechInput, SpeechOutput
├── work/       BinCleanupWorker
├── ui/         Compose: theme, components (GestureCard, Smoke, Caller, snackbar, import host), screens, voice host, CWRoot
└── util/       Dialer, PhotoStorage
```

Room/SQLite is the durable store; the Java `ContactIndex` (linked list + phone/email/name hash tables) is the in-memory index.
Every write runs under one mutex: Room transaction → index → published snapshot. Undo/Redo applies each step to **both**.
Search and sorting run off the main thread. Complexities: linked list insert O(1), find O(n); hash tables O(1) average;
stacks O(1); search O(n·m); merge sort O(n log n).

**Database migration (v1 → v2).** The Hidden-contacts column was removed; contacts that had been hidden simply become ordinary
contacts (no data is deleted). `emergency_services` gained `deletedAt`. The AUTOINCREMENT sequence is preserved so ids are never
reused. The migration SQL was replayed against a real v1 SQLite database (see section 8).

## 6. Security

* App Lock, the app PIN and fingerprint settings are **touch-controlled only**. The voice assistant has no request type that can
  touch them, refuses spoken attempts ("enable app lock", "change my pin", …) and cannot bypass authentication.
* PIN: PBKDF2-HMAC-SHA256, 120 000 iterations, random 16-byte salt, constant-time compare; the PIN is never stored. (The
  on-screen implementation notes were removed from the UI; the security itself is unchanged.)
* While App Lock is on the window is `FLAG_SECURE`. The PIN hash and contacts live in app-private storage, protected by
  Android's sandbox and App Lock; they are **not** separately encrypted. `allowBackup` is off.
* Contact data never leaves the device; there is no internet permission.
* Permissions: `READ_CONTACTS` (import, asked after an explanation), `CALL_PHONE` (direct calling, asked on the first call),
  `RECORD_AUDIO` (voice session, asked when one starts; never recording in the background), `USE_BIOMETRIC`.

## 7. Voice assistant

Start it by tapping the **mic** in the search field, or with a deliberate **one-finger left-to-right swipe across the Home search bar**
(≥ 96 dp, mostly horizontal, within 0.7 s; it only observes touches, so tapping, the cursor, typing and selection are unaffected).
The old two-finger bottom-to-top gesture was removed.

**It is a continuous session.** It stays open until you say "close", tap Close / Back, or the app leaves the foreground. Android's
`SpeechRecognizer` works in sequential requests, so the app starts the next request automatically the moment one ends. There is a
short, device-dependent gap between requests (and some speech services beep); that cannot be removed from the app side.

* **Silence is not a command.** No message, no retry button, no state change; listening just continues.
* **Speech that isn't understood** is answered once with "I didn't catch that. Please say it again." and listening continues. There
  is no Try Again button; Close is the only persistent control.
* **No overlapping speech.** `SpeechOutput` hands the engine one utterance at a time and starts the next from the
  `UtteranceProgressListener` completion callback (no timed delays). Recognition is paused while the assistant speaks, so it never
  transcribes itself, and resumes from the same callback. Cancelling or closing lets the sentence in progress finish; stale lines are
  dropped. "Close" says a short goodbye, finishes it, then stops. Duplicate or late recognizer callbacks are ignored (token per request).
* **"View" fixed.** After "I found Ahmed Khan. What would you like to do?", the replies "View", "View this contact", "Open contact",
  "Show details" and "Show me the details" act on the selected contact (they no longer start a search for "view"). "Show Ahmed Khan"
  opens that contact. A recognizer mis-hearing of "view" ("you", "few") is accepted only as the whole answer to that question.

| Say | Result |
|---|---|
| "Open Home / Categories / Favorites / Bin / Emergency Services / Settings", "Go back" | Navigates |
| "Find Ahmed", "Ahmed Khan", "Show my family contacts" | Searches any field; one match → asks what to do; several → lists them, never guesses |
| "Call / Edit / Delete / View …", "Add … to favorites", "Remove … from favorites" | Acts on the contact (delete and edit ask to confirm; call opens the dialer) |
| "Add contact" | Name → phone → optional e-mail → review → confirm |
| "Expand / collapse Family", "Create category …", "Rename Work to Office", "Remove category …" | Category operations (removal confirms) |
| "Sort A to Z / Z to A / recently added / by category" | Sorts Home |
| "Open bin", "Select all", "Restore all", "Restore Ahmed", "Restore selected" | Bin operations |
| "Delete all permanently", "Permanently delete Sara" | Needs an explicit **yes** (a plain "ok" does not count); "Delete all" alone is refused as ambiguous |
| "Add / edit / remove emergency service …" | Emergency entries (no 11-digit rule) |
| "Change theme to Emerald" | Switches theme |
| "Open my profile", "Change my name to …" | Profile (photo: tap the camera icon) |
| "Undo", "Redo" | History |
| "Cancel", "Close" | Cancel the question / end the session |

Moving a contact to the Bin and permanent deletion are always clearly different. The assistant **never** touches App Lock, the PIN,
fingerprint or any authentication setting.

Presentation: the first screen is a solid charcoal listening screen; follow-up questions use the translucent overlay; between
commands a compact panel keeps the screen you opened visible. Every question can also be answered with buttons or a text box.

**Needs a physical device:** recognition quality and spoken replies on the Vivo Y15C (Google speech services required; recognition
is generally online, the app does not claim offline support), permission allow/deny/"don't ask again", missing speech services,
a phone call arriving mid-session, rotation, and the real gap between recognition requests.

## 8. Verification status — what was actually run

Run in the cloud sandbox (real execution):
* **Java DSA + validator + undo/redo tests: 63 JUnit tests, all passing** (plain `javac` + JUnit).
* **Voice parser + state machine: 59 JUnit tests, all passing** (`tools/jvm-check/run_voice.sh`: the real Kotlin sources compiled
  with the embedded Kotlin compiler against the real Java search index; no microphone needed). Writing them found and fixed one bug
  (a "you" mis-hearing of "view" was treated as a name).
* **Repository logic: 60 behavioural checks, all passing** (`tools/jvm-check/run.sh`: the real `ContactRepository`,
  `EmergencyRepository` and import code over in-memory fake DAOs): the five Undo/Redo scenarios, bulk permanent delete, history
  invalidation, +92 normalisation, phonebook import (duplicates, skipped, non-standard numbers, same name/different number, ICE,
  re-import idempotence, Bin non-resurrection), Emergency Bin/restore.
* **Room migration v1→v2:** the SQL was replayed against a real SQLite v1 database in Python: data preserved, formerly hidden
  contacts become ordinary, AUTOINCREMENT preserved, empty-table case works.
* All Kotlin sources **parse** (no syntax errors).

**NOT run, and not claimed:**
1. `./gradlew assembleDebug` — Compose/AndroidX/Room-KSP code was not type-checked (no Android SDK or Maven access here). Treat the
   first build as the first compile; expect to fix a few small errors.
2. Instrumented tests (`app/src/androidTest`: real Room, DataStore, card gestures, Dialer) were updated for this pass but **never run**.
3. Everything that needs the phone: the visual result of the glows, gradients, bevels and the sort cascade; the smoke look;
   elastic drag feel and double-tap timing; contact import against the real Contacts Provider; permission grant/deny/dialer-fallback
   paths; App Lock prompts; snackbar timing and swipe; two-finger gestures; voice (section 7).
4. Release/R8 build, never tried; use debug builds for the demo.

Known limitations: Undo/Redo history resets on process restart; Emergency entries have no undo history; no contact photos; seeded emergency
numbers are unverified samples; pull-to-call needs the 250 ms hold (deliberate, to stop scroll accidents); the smoke is
procedural; Roboto falls back to the platform sans-serif until the font files are added; no supplied icons exist for email, location,
notes, close, check, emergency, restore, select-all (vector placeholders are used, `docs/ASSETS.md`).

## 9. Assets
See `docs/ASSETS.md` for every supplied asset, where it is used, derived-asset notes, and what is missing.
