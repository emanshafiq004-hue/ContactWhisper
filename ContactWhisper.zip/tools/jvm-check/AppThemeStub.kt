package com.contactwhisper.app.data

/** Same shape as the real enum in SettingsStore.kt (which needs DataStore, unavailable in this JVM-only harness). */
enum class AppTheme { CRIMSON, EMERALD }
