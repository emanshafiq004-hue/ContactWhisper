// Minimal stand-ins for the androidx.room API so the data layer (Entities/Daos/ContactRepository/EmergencyRepository)
// can be compiled and exercised on a plain JVM. NOT part of the app build.
package androidx.room

import kotlin.reflect.KClass

annotation class Index(vararg val value: String, val unique: Boolean = false)
annotation class Entity(val tableName: String = "", val indices: Array<Index> = [])
annotation class PrimaryKey(val autoGenerate: Boolean = false)
annotation class Dao
annotation class Query(val value: String)
annotation class Insert(val onConflict: Int = 3)
annotation class Update
annotation class Database(val entities: Array<KClass<*>>, val version: Int, val exportSchema: Boolean = true)
object OnConflictStrategy { const val REPLACE = 1; const val IGNORE = 5 }
abstract class RoomDatabase
suspend fun <R> RoomDatabase.withTransaction(block: suspend () -> R): R = block()
