// JVM scenario checks for the data layer (run with tools/jvm-check/run.sh). Exits non-zero on any failure.
import com.contactwhisper.app.data.*
import com.contactwhisper.app.dsa.SortMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

var passed = 0
val failures = mutableListOf<String>()
fun check(name: String, cond: Boolean) { if (cond) passed++ else { failures += name; println("  FAIL: $name") } }

fun newRepo(): Pair<ContactRepository, AppDatabase> {
    val db = AppDatabase(); val repo = ContactRepository(db); runBlocking { repo.ensureDefaultCategories(); repo.load() }; return repo to db
}
fun d(name: String, phone: String = "03001234567", email: String = "") = ContactDraft(name, phone, email)
fun ContactRepository.names() = contacts.value.map { it.name }.sorted()

fun main() = runBlocking {
    // 1. Add -> permanently delete via Bin -> Undo cannot restore it
    run {
        val (repo, db) = newRepo()
        val a = repo.addContact(d("Ann"))
        repo.moveToBin(a.id)
        check("1 pre: ann in bin", db.contacts.rows[a.id]?.deletedAt != null)
        check("1 history mentions ann before purge", repo.historyMentions(a.id))
        repo.permanentlyDelete(listOf(a.id))
        check("1 row erased from Room", db.contacts.rows[a.id] == null)
        check("1 history no longer mentions ann", !repo.historyMentions(a.id))
        check("1 undo/redo unavailable", !repo.history.value.canUndo && !repo.history.value.canRedo)
        val u = repo.undo(); val r = repo.redo()
        check("1 undo performs nothing", !u.performed); check("1 redo performs nothing", !r.performed)
        check("1 ann still gone", repo.contacts.value.isEmpty() && db.contacts.rows[a.id] == null)
    }
    // 1b. other contacts' history survives; undo only touches them
    run {
        val (repo, db) = newRepo()
        val a = repo.addContact(d("Ann", "03001111111")); val b = repo.addContact(d("Bob", "03002222222"))
        repo.moveToBin(a.id); repo.permanentlyDelete(listOf(a.id))
        check("1b bob history kept", repo.history.value.canUndo && repo.historyMentions(b.id))
        val u = repo.undo()
        check("1b undo removes bob's add only", u.performed && repo.contacts.value.isEmpty() && db.contacts.rows[a.id] == null)
        check("1b second undo nothing", !repo.undo().performed)
        val rd = repo.redo()   // redo of Bob's add is fine; Ann must never come back
        check("1b redo restores bob not ann", rd.performed && repo.names() == listOf("Bob") && db.contacts.rows[a.id] == null)
    }
    // 2. Delete -> Restore -> Undo -> back in Bin
    run {
        val (repo, db) = newRepo()
        val a = repo.addContact(d("Ann")); repo.moveToBin(a.id)
        check("2 restore ok", repo.restore(a.id) == RestoreResult.Restored)
        check("2 active after restore", repo.names() == listOf("Ann") && db.contacts.rows[a.id]?.deletedAt == null)
        check("2 restore recorded", repo.history.value.canUndo)
        val u = repo.undo()
        check("2 undo performed", u.performed)
        check("2 contact back in Bin", repo.contacts.value.isEmpty() && db.contacts.rows[a.id]?.deletedAt != null)
        check("2 redo available", repo.history.value.canRedo)
        // 3. Redo reapplies the restoration
        val r = repo.redo()
        check("3 redo performed", r.performed)
        check("3 contact restored again", repo.names() == listOf("Ann") && db.contacts.rows[a.id]?.deletedAt == null)
        // and the chain keeps working: undo twice more => delete undone (active) ... verify stack integrity
        check("3 undo again -> Bin", repo.undo().performed && repo.contacts.value.isEmpty())
        check("3 undo the delete -> active", repo.undo().performed && repo.names() == listOf("Ann"))
    }
    // 4. Delete -> Undo
    run {
        val (repo, db) = newRepo()
        val a = repo.addContact(d("Ann", email = "a@x.com")); repo.setFavorite(a.id, true)
        repo.moveToBin(a.id)
        check("4 gone from list", repo.contacts.value.isEmpty())
        check("4 undo performed", repo.undo().performed)
        val back = repo.getActive(a.id)
        check("4 returned intact", back != null && back.isFavorite && back.email == "a@x.com" && db.contacts.rows[a.id]?.deletedAt == null)
        check("4 redo deletes again", repo.redo().performed && repo.contacts.value.isEmpty())
    }
    // 5. Multiple edits then permanent delete -> nothing can recreate it
    run {
        val (repo, db) = newRepo()
        val a = repo.addContact(d("Ann"))
        repo.updateContact(a.id, d("Ann B", "03001234567"))
        repo.updateContact(a.id, d("Ann C", "03009999999"))
        repo.setFavorite(a.id, true)
        repo.moveToBin(a.id)
        repo.undo(); repo.redo()                                   // leave stuff on both stacks
        repo.restore(a.id); repo.moveToBin(a.id)
        repo.undo()                                                 // redo stack now holds entries about Ann
        check("5 pre: history has Ann", repo.historyMentions(a.id))
        // she is active again after that undo -> send her to Bin again (new action) and purge
        repo.moveToBin(a.id)
        repo.permanentlyDelete(listOf(a.id))
        check("5 history purged both stacks", !repo.historyMentions(a.id) && !repo.history.value.canUndo && !repo.history.value.canRedo)
        var resurrected = false
        repeat(6) { repo.undo(); repo.redo(); if (db.contacts.rows[a.id] != null || repo.getActive(a.id) != null) resurrected = true }
        check("5 never resurrected", !resurrected)
    }
    // 6. Select-all / Delete-all in the Bin purges every id
    run {
        val (repo, db) = newRepo()
        val ids = (1..4).map { repo.addContact(d("C$it", "0300111000$it")).id }
        ids.forEach { repo.moveToBin(it) }
        repo.restore(ids[0]); repo.moveToBin(ids[0])
        val n = repo.permanentlyDelete(ids)
        check("6 all erased", n == 4 && db.contacts.rows.isEmpty())
        check("6 history empty", !repo.history.value.canUndo && !repo.history.value.canRedo && ids.none { repo.historyMentions(it) })
    }
    // 7. Permanent delete ignores contacts that are NOT in the Bin
    run {
        val (repo, db) = newRepo()
        val a = repo.addContact(d("Ann"))
        check("7 nothing removed", repo.permanentlyDelete(listOf(a.id)) == 0)
        check("7 still active + history intact", repo.names() == listOf("Ann") && repo.historyMentions(a.id))
    }
    // 8. Auto-purge after 30 days also invalidates history
    run {
        val (repo, db) = newRepo()
        val a = repo.addContact(d("Ann")); repo.moveToBin(a.id)
        val removed = repo.purgeExpired(System.currentTimeMillis() + ContactRepository.RETENTION_MS + 1000)
        check("8 expired purge", removed == 1 && db.contacts.rows.isEmpty() && !repo.historyMentions(a.id))
        check("8 undo nothing", !repo.undo().performed)
    }
    // 9. Phone saved normalised; hidden gone; search without hidden
    run {
        val (repo, db) = newRepo()
        val a = repo.addContact(d("Ann", "+92 300 1234567"))
        check("9 +92 converted on save", db.contacts.rows[a.id]?.phone == "03001234567")
        check("9 search", repo.search("ann", SortMode.A_Z).size == 1)
    }
    // 10. Phonebook import
    run {
        val (repo, db) = newRepo()
        repo.addContact(d("Existing Eve", "03005550000", "eve@x.com"))
        val sum = repo.importContacts(listOf(
            ImportedContact("Ali Raza", listOf("0300 111 2222", "0321 000 0000"), listOf("ali@x.com", "ali2@x.com")),
            ImportedContact("Eve Again", listOf("+92 300 5550000"), emptyList()),                 // duplicate phone
            ImportedContact("Eve Mail", listOf("0345 9999999"), listOf("EVE@x.com")),             // duplicate email
            ImportedContact("No Phone", emptyList(), listOf("np@x.com")),                         // skipped
            ImportedContact("", listOf("0301 2223333"), emptyList()),                             // skipped (no name)
            ImportedContact("Landline Larry", listOf("021 3456789"), emptyList()),                // non-standard, kept
            ImportedContact("Ali Raza", listOf("0300 111 2222"), emptyList()),                    // dup of batch entry
            ImportedContact("Existing Eve", listOf("0302 7776666"), emptyList()),                 // same name, other number
            ImportedContact("ICE - Mom", listOf("0333 1234567"), emptyList()),                    // ICE = ordinary contact
        ))
        check("10 scanned", sum.scanned == 9)
        check("10 imported 4", sum.imported == 4)
        check("10 duplicates", sum.duplicates.sorted() == listOf("Ali Raza", "Eve Again", "Eve Mail"))
        check("10 skipped", sum.skipped.size == 2)
        check("10 nonStandard", sum.nonStandardPhones == listOf("Landline Larry"))
        check("10 sameName", sum.sameNameDifferentNumber == listOf("Existing Eve"))
        val ali = repo.contacts.value.first { it.name == "Ali Raza" }
        check("10 number kept exactly as imported", ali.phone == "0300 111 2222")
        check("10 extra numbers/emails kept in notes", ali.notes.contains("0321 000 0000") && ali.notes.contains("ali2@x.com") && ali.email == "ali@x.com")
        check("10 ICE imported as ordinary", repo.names().contains("ICE - Mom"))
        check("10 DSA/Room agree", repo.contacts.value.size == db.contacts.rows.values.count { it.deletedAt == null } && repo.contacts.value.size == 5)
        check("10 import not in undo history", repo.history.value.canUndo.let { true } && repo.getActive(ali.id) != null)
        // Re-import is idempotent and keeps edits
        repo.updateContact(ali.id, d("Ali Renamed", "0300 111 2222"))
        val again = repo.importContacts(listOf(ImportedContact("Ali Raza", listOf("0300 111 2222"), emptyList())))
        check("10 re-import adds nothing", again.imported == 0 && again.duplicates.size == 1)
        check("10 user edit preserved", repo.names().contains("Ali Renamed") && !repo.names().contains("Ali Raza"))
        // binned contact is not re-imported
        repo.moveToBin(repo.contacts.value.first { it.name == "ICE - Mom" }.id)
        val third = repo.importContacts(listOf(ImportedContact("ICE - Mom", listOf("0333 1234567"), emptyList())))
        check("10 binned contact not resurrected by import", third.imported == 0 && !repo.names().contains("ICE - Mom"))
        check("10 index ids unique", repo.contacts.value.map { it.id }.toSet().size == repo.contacts.value.size && repo.contacts.value.all { it.id > 0 })
    }
    // 11. Emergency entries: bin + restore keeps type/number
    run {
        val db = AppDatabase(); val er = EmergencyRepository(db)
        er.seed(EmergencySeed.entries)
        val police = er.entries.first().first { it.name == "Police" }
        val moved = er.moveToBin(police.id)
        check("11 moved", moved != null && er.entries.first().none { it.name == "Police" })
        check("11 in bin with number", er.binItems.first().single().let { it.name == "Police" && it.number == police.number })
        check("11 moving twice refused", er.moveToBin(police.id) == null)
        check("11 restore returns to emergency list", er.restore(police.id) && er.entries.first().any { it.name == "Police" && it.number == police.number } && er.binItems.first().isEmpty())
        er.moveToBin(police.id)
        check("11 permanent delete only from bin", er.permanentlyDelete(listOf(police.id)) == 1 && db.emergency.rows[police.id] == null)
        check("11 active ones cannot be permanently deleted", er.permanentlyDelete(er.entries.first().map { it.id }) == 0)
        check("11 seed not recreated when list was emptied", !er.isEmpty())
        er.add("Short", "15"); check("11 short number accepted", er.entries.first().any { it.number == "15" })
    }
    println("passed=$passed failed=${failures.size}")
    if (failures.isNotEmpty()) { println(failures); kotlin.system.exitProcess(1) }
}
