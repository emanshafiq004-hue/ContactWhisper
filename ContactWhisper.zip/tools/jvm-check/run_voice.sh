#!/bin/bash
# Compiles the pure-Kotlin voice layer (parser + conversation state machine) with its JUnit tests and runs them on a plain JVM.
# Needs only a JDK + the Kotlin/JUnit jars in Gradle's lib dir. No Android SDK.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; OUT="${TMPDIR:-/tmp}/cw-jvm-voice"; G="${GRADLE_LIB:-/opt/gradle-8.14.3/lib}"
rm -rf "$OUT"; mkdir -p "$OUT/j" "$OUT/k"
javac -nowarn -d "$OUT/j" $(find "$ROOT/app/src/main/java" -name '*.java') 2>&1 | grep -v "Picked up" || true
KCP="$G/kotlin-compiler-embeddable-2.0.21.jar:$G/kotlin-stdlib-2.0.21.jar:$G/kotlin-script-runtime-2.0.21.jar:$G/kotlin-reflect-2.0.21.jar:$G/trove4j-1.0.20200330.jar:$G/kotlinx-coroutines-core-jvm-1.6.4.jar:$G/annotations-24.0.1.jar"
JU="$G/junit-4.13.2.jar:$(ls $G/hamcrest*.jar | head -1)"
M="$ROOT/app/src/main/java/com/contactwhisper/app"; T="$ROOT/app/src/test/java/com/contactwhisper/app/voice"
java -cp "$KCP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect \
  -cp "$OUT/j:$G/kotlin-stdlib-2.0.21.jar:$G/kotlinx-coroutines-core-jvm-1.6.4.jar:$JU" -d "$OUT/k" \
  "$ROOT/tools/jvm-check/RoomStubs.kt" "$ROOT/tools/jvm-check/FakeDb.kt" "$ROOT/tools/jvm-check/AppThemeStub.kt" \
  "$M/data/Entities.kt" "$M/data/ContactRepository.kt" "$M/data/Daos.kt" "$M/data/EmergencyRepository.kt" "$M/data/EmergencySeed.kt" \
  "$M/voice/VoiceCommandParser.kt" "$M/voice/VoiceConversation.kt" \
  "$T/VoiceCommandParserTest.kt" "$T/VoiceConversationTest.kt" 2>&1 | grep -v "Picked up" | grep -E "error|exception" || true
java -cp "$OUT/k:$OUT/j:$G/kotlin-stdlib-2.0.21.jar:$G/kotlinx-coroutines-core-jvm-1.6.4.jar:$JU" org.junit.runner.JUnitCore \
  com.contactwhisper.app.voice.VoiceCommandParserTest com.contactwhisper.app.voice.VoiceConversationTest 2>&1 | grep -v "Picked up" | tail -${1:-40}
