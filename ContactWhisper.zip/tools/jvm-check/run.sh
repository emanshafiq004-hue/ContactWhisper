#!/bin/bash
# Compiles the data layer + Java DSA against Room stubs and runs RepoCheck. Needs only a JDK + the Kotlin jars in Gradle's lib dir.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; OUT="${TMPDIR:-/tmp}/cw-jvm-check"; G="${GRADLE_LIB:-/opt/gradle-8.14.3/lib}"
rm -rf "$OUT"; mkdir -p "$OUT/j" "$OUT/k"
javac -nowarn -d "$OUT/j" $(find "$ROOT/app/src/main/java" -name '*.java') 2>&1 | grep -v "Picked up" || true
KCP="$G/kotlin-compiler-embeddable-2.0.21.jar:$G/kotlin-stdlib-2.0.21.jar:$G/kotlin-script-runtime-2.0.21.jar:$G/kotlin-reflect-2.0.21.jar:$G/trove4j-1.0.20200330.jar:$G/kotlinx-coroutines-core-jvm-1.6.4.jar:$G/annotations-24.0.1.jar"
D="$ROOT/app/src/main/java/com/contactwhisper/app/data"
java -cp "$KCP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -cp "$OUT/j:$G/kotlin-stdlib-2.0.21.jar:$G/kotlinx-coroutines-core-jvm-1.6.4.jar" -d "$OUT/k" \
  "$ROOT/tools/jvm-check/RoomStubs.kt" "$ROOT/tools/jvm-check/FakeDb.kt" "$ROOT/tools/jvm-check/RepoCheck.kt" \
  "$D/Entities.kt" "$D/Daos.kt" "$D/ContactRepository.kt" "$D/EmergencyRepository.kt" "$D/EmergencySeed.kt" 2>&1 | grep -v "Picked up" | grep -E "error|exception" || true
java -cp "$OUT/k:$OUT/j:$G/kotlin-stdlib-2.0.21.jar:$G/kotlinx-coroutines-core-jvm-1.6.4.jar" RepoCheckKt 2>&1 | grep -v "Picked up"
