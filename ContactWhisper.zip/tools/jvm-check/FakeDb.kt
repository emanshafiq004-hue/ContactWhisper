// In-memory DAOs that mimic the SQL in Daos.kt (incl. AUTOINCREMENT ids that are never reused).
package com.contactwhisper.app.data

import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map

class FakeContactDao : ContactDao {
    val rows = linkedMapOf<Long, ContactEntity>()
    private var seq = 0L
    private val change = MutableStateFlow(0)
    private fun touch() { change.value++ }
    override suspend fun getActive() = rows.values.filter { it.deletedAt == null }
    override fun observeBin(): Flow<List<ContactEntity>> =
        change.map { rows.values.filter { it.deletedAt != null }.sortedByDescending { it.deletedAt } }
    override suspend fun getById(id: Long) = rows[id]
    override suspend fun getBin() = rows.values.filter { it.deletedAt != null }
    override suspend fun insert(entity: ContactEntity): Long {
        val id = if (entity.id == 0L) ++seq else { if (entity.id > seq) seq = entity.id; entity.id }
        rows[id] = entity.copy(id = id); touch(); return id
    }
    override suspend fun update(entity: ContactEntity) { if (rows.containsKey(entity.id)) rows[entity.id] = entity; touch() }
    override suspend fun softDelete(id: Long, deletedAt: Long) { rows[id]?.let { rows[id] = it.copy(deletedAt = deletedAt) }; touch() }
    override suspend fun clearDeleted(id: Long) { rows[id]?.let { rows[id] = it.copy(deletedAt = null) }; touch() }
    override suspend fun hardDelete(id: Long): Int { val r = rows.remove(id) != null; touch(); return if (r) 1 else 0 }
    override suspend fun hardDeleteBinItems(ids: List<Long>): Int {
        var n = 0; for (id in ids) if (rows[id]?.deletedAt != null) { rows.remove(id); n++ }; touch(); return n
    }
    override suspend fun expiredIds(cutoff: Long) = rows.values.filter { (it.deletedAt ?: Long.MAX_VALUE) < cutoff }.map { it.id }
    override suspend fun binIdsAmong(ids: List<Long>) = rows.values.filter { it.deletedAt != null && it.id in ids }.map { it.id }
    override suspend fun purgeBefore(cutoff: Long): Int {
        val ids = expiredIds(cutoff); ids.forEach { rows.remove(it) }; touch(); return ids.size
    }
    override suspend fun renameCategory(oldName: String, newName: String) {
        rows.replaceAll { _, v -> if (v.category == oldName) v.copy(category = newName) else v }; touch()
    }
    override suspend fun binCount() = rows.values.count { it.deletedAt != null }
}

class FakeCategoryDao : CategoryDao {
    val rows = linkedMapOf<Long, CategoryEntity>(); private var seq = 0L
    private val change = MutableStateFlow(0)
    override fun observeAll(): Flow<List<CategoryEntity>> = change.map { rows.values.toList() }
    override suspend fun count() = rows.size
    override suspend fun getById(id: Long) = rows[id]
    override suspend fun findByName(name: String) = rows.values.firstOrNull { it.name.equals(name, true) }
    override suspend fun insert(entity: CategoryEntity): Long {
        if (findByName(entity.name) != null) return -1
        val id = ++seq; rows[id] = entity.copy(id = id); change.value++; return id
    }
    override suspend fun rename(id: Long, newName: String) { rows[id]?.let { rows[id] = it.copy(name = newName) } }
    override suspend fun delete(id: Long) { rows.remove(id) }
}

class FakeEmergencyDao : EmergencyDao {
    val rows = linkedMapOf<Long, EmergencyEntity>(); private var seq = 0L
    private val change = MutableStateFlow(0)
    override fun observeAll(): Flow<List<EmergencyEntity>> =
        change.map { rows.values.filter { it.deletedAt == null }.sortedWith(compareBy({ it.sortOrder }, { it.id })) }
    override fun observeBin(): Flow<List<EmergencyEntity>> =
        change.map { rows.values.filter { it.deletedAt != null }.sortedByDescending { it.deletedAt } }
    override suspend fun count() = rows.size
    override suspend fun maxOrder() = rows.values.maxOfOrNull { it.sortOrder } ?: -1
    override suspend fun getById(id: Long) = rows[id]
    override suspend fun insert(entity: EmergencyEntity): Long { val id = ++seq; rows[id] = entity.copy(id = id); change.value++; return id }
    override suspend fun update(entity: EmergencyEntity) { rows[entity.id] = entity; change.value++ }
    override suspend fun softDelete(id: Long, deletedAt: Long): Int {
        val r = rows[id]; if (r == null || r.deletedAt != null) return 0
        rows[id] = r.copy(deletedAt = deletedAt); change.value++; return 1
    }
    override suspend fun clearDeleted(id: Long): Int {
        val r = rows[id]; if (r == null || r.deletedAt == null) return 0
        rows[id] = r.copy(deletedAt = null); change.value++; return 1
    }
    override suspend fun hardDeleteBinItems(ids: List<Long>): Int {
        var n = 0; for (id in ids) if (rows[id]?.deletedAt != null) { rows.remove(id); n++ }; change.value++; return n
    }
    override suspend fun purgeBefore(cutoff: Long): Int {
        val ids = rows.values.filter { (it.deletedAt ?: Long.MAX_VALUE) < cutoff }.map { it.id }
        ids.forEach { rows.remove(it) }; change.value++; return ids.size
    }
}

/** Stand-in for the Room database (the real AppDatabase.kt is excluded from this harness). */
class AppDatabase(
    val contacts: FakeContactDao = FakeContactDao(),
    val categories: FakeCategoryDao = FakeCategoryDao(),
    val emergency: FakeEmergencyDao = FakeEmergencyDao(),
) : RoomDatabase() {
    fun contactDao(): ContactDao = contacts
    fun categoryDao(): CategoryDao = categories
    fun emergencyDao(): EmergencyDao = emergency
}
