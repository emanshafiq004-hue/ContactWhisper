# Room, Compose and WorkManager ship their own consumer rules.
# Keep the Java DSA classes readable in stack traces.
-keep class com.contactwhisper.app.dsa.** { *; }
-keep class com.contactwhisper.app.domain.** { *; }
