package com.contactwhisper.app;

import com.contactwhisper.app.dsa.ContactRecord;

/** Small factory so tests stay readable. */
final class TestData {
    private TestData() {
    }

    static ContactRecord c(long id, String name, String phone) {
        return new ContactRecord(id, name, phone, "", "", "", "", false, 1000L + id, 1000L + id);
    }

    static ContactRecord full(long id, String name, String phone, String email, String address,
                              String notes, String category, long createdAt) {
        return new ContactRecord(id, name, phone, email, address, notes, category, false, createdAt, createdAt);
    }
}
