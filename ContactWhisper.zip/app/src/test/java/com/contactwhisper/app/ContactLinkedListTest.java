package com.contactwhisper.app;

import static com.contactwhisper.app.TestData.c;
import static org.junit.Assert.*;

import com.contactwhisper.app.dsa.ContactLinkedList;
import com.contactwhisper.app.dsa.ContactRecord;

import org.junit.Test;

public class ContactLinkedListTest {

    @Test
    public void insertFirstAndLastKeepOrder() {
        ContactLinkedList list = new ContactLinkedList();
        list.insertLast(c(2, "B", "222"));
        list.insertFirst(c(1, "A", "111"));
        list.insertLast(c(3, "C", "333"));
        ContactRecord[] arr = list.toArray();
        assertEquals(3, list.size());
        assertEquals(1, arr[0].getId());
        assertEquals(2, arr[1].getId());
        assertEquals(3, arr[2].getId());
    }

    @Test
    public void findByIdFindsAndMisses() {
        ContactLinkedList list = new ContactLinkedList();
        list.insertLast(c(5, "Ann", "555"));
        assertEquals("Ann", list.findById(5).getName());
        assertNull(list.findById(6));
        assertTrue(list.contains(5));
        assertFalse(list.contains(6));
    }

    @Test
    public void updateReplacesRecordInPlace() {
        ContactLinkedList list = new ContactLinkedList();
        list.insertLast(c(1, "Old", "111"));
        ContactRecord old = list.update(c(1, "New", "111"));
        assertEquals("Old", old.getName());
        assertEquals("New", list.findById(1).getName());
        assertEquals(1, list.size());
        assertNull(list.update(c(99, "Ghost", "000")));
    }

    @Test
    public void removeHeadMiddleTailAndMissing() {
        ContactLinkedList list = new ContactLinkedList();
        for (long i = 1; i <= 4; i++) list.insertLast(c(i, "N" + i, "" + i));
        assertEquals(2, list.remove(2).getId());   // middle
        assertEquals(1, list.remove(1).getId());   // head
        assertEquals(4, list.remove(4).getId());   // tail
        assertNull(list.remove(42));
        assertEquals(1, list.size());
        // tail pointer must have moved: appending after removing the tail has to work
        list.insertLast(c(9, "N9", "9"));
        ContactRecord[] arr = list.toArray();
        assertEquals(3, arr[0].getId());
        assertEquals(9, arr[1].getId());
    }

    @Test
    public void removeLastRemainingThenReuse() {
        ContactLinkedList list = new ContactLinkedList();
        list.insertFirst(c(1, "Only", "1"));
        list.remove(1);
        assertTrue(list.isEmpty());
        list.insertLast(c(2, "Again", "2"));
        assertEquals(1, list.size());
        assertEquals(2, list.toArray()[0].getId());
    }

    @Test
    public void iteratorWalksAllNodes() {
        ContactLinkedList list = new ContactLinkedList();
        list.insertLast(c(1, "A", "1"));
        list.insertLast(c(2, "B", "2"));
        int count = 0;
        for (ContactRecord r : list) count += (int) r.getId();
        assertEquals(3, count);
    }
}
