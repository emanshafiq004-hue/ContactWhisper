package com.contactwhisper.app.voice

import com.contactwhisper.app.data.AppTheme
import com.contactwhisper.app.dsa.SortMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Deterministic parsing: plain strings in, a [VoiceCommand] (or a small value) out. */
class VoiceCommandParserTest {
    private fun cmd(text: String) = VoiceCommandParser.parseCommand(text)

    // ---- find / actions

    @Test fun bareNameIsAPlainSearch() {
        assertEquals(VoiceCommand.Find("ahmed khan", null), cmd("Ahmed Khan."))
        assertEquals(VoiceCommand.Find("ali", null), cmd("  ALI  "))
    }

    @Test fun findAndSearchVerbs() {
        assertEquals(VoiceCommand.Find("ahmed khan", null), cmd("Find Ahmed Khan"))
        assertEquals(VoiceCommand.Find("sara", null), cmd("Search for Sara"))
        assertEquals(VoiceCommand.Find("sara", null), cmd("look up Sara please"))
    }

    @Test fun actionVerbsCarryTheAction() {
        assertEquals(VoiceCommand.Find("ahmed", VoiceAction.CALL), cmd("Call Ahmed"))
        assertEquals(VoiceCommand.Find("sara", VoiceAction.EDIT), cmd("Edit Sara"))
        assertEquals(VoiceCommand.Find("ali", VoiceAction.DELETE), cmd("Delete Ali"))
        assertEquals(VoiceCommand.Find("sara", VoiceAction.VIEW), cmd("open contact Sara"))
    }

    @Test fun showNameViewsOrFinds() {
        val c = cmd("Show Ahmed Khan")
        assertTrue(c is VoiceCommand.Find && c.query == "ahmed khan")
    }

    @Test fun capitalisationAndPunctuationAreIgnored() {
        assertEquals(VoiceCommand.Find("sara", VoiceAction.CALL), cmd("CALL, sara!"))
    }

    // ---- the "View" bug: bare view-style replies are ACTIONS (in AskingAction), never a contact called "View"

    @Test fun viewVariantsAreActionsForTheSelectedContact() {
        for (phrase in listOf("view", "View.", "view this contact", "open contact", "Open the contact", "show details", "show me the details", "details")) {
            assertEquals("'$phrase'", VoiceAction.VIEW, VoiceCommandParser.parseAction(phrase))
        }
    }

    @Test fun viewHomophonesOnlyCountAsTheWholeAnswer() {
        assertEquals(VoiceAction.VIEW, VoiceCommandParser.parseAction("you", allowHomophones = true))
        assertNull(VoiceCommandParser.parseAction("you", allowHomophones = false))
    }

    @Test fun otherActionReplies() {
        assertEquals(VoiceAction.EDIT, VoiceCommandParser.parseAction("I want to edit"))
        assertEquals(VoiceAction.DELETE, VoiceCommandParser.parseAction("delete it"))
        assertEquals(VoiceAction.CALL, VoiceCommandParser.parseAction("call him"))
        assertNull(VoiceCommandParser.parseAction("call or delete"))   // conflicting: never guess
        assertNull(VoiceCommandParser.parseAction("banana"))
    }

    // ---- navigation, sort, theme, close

    @Test fun openScreens() {
        assertEquals(VoiceCommand.Open(VoiceScreen.HOME), cmd("open home"))
        assertEquals(VoiceCommand.Open(VoiceScreen.CATEGORIES), cmd("open categories"))
        assertEquals(VoiceCommand.Open(VoiceScreen.FAVORITES), cmd("open favorites"))
        assertEquals(VoiceCommand.Open(VoiceScreen.BIN), cmd("open bin"))
        assertEquals(VoiceCommand.Open(VoiceScreen.EMERGENCY), cmd("open emergency services"))
        assertEquals(VoiceCommand.Open(VoiceScreen.SETTINGS), cmd("open settings"))
    }

    @Test fun sortModes() {
        assertEquals(VoiceCommand.Sort(SortMode.A_Z), cmd("sort a to z"))
        assertEquals(VoiceCommand.Sort(SortMode.Z_A), cmd("sort z to a"))
    }

    @Test fun themeChange() {
        assertEquals(VoiceCommand.Theme(AppTheme.EMERALD), cmd("change theme to emerald"))
        assertEquals(VoiceCommand.Theme(AppTheme.CRIMSON), cmd("switch to crimson theme"))
        assertEquals(VoiceCommand.Theme(null), cmd("change theme"))
    }

    @Test fun closeAndBack() {
        assertEquals(VoiceCommand.Close, cmd("close"))
        assertEquals(VoiceCommand.Close, cmd("Close."))
        assertTrue(VoiceCommandParser.isClose("close the assistant"))
        assertEquals(VoiceCommand.Back, cmd("go back"))
    }

    @Test fun emptyIsNotACommandWithAName() {
        assertEquals(VoiceCommand.Unknown, cmd(""))
        assertEquals(VoiceCommand.Unknown, cmd("   ... "))
    }

    // ---- Bin: moving to the Bin is NOT permanent deletion

    @Test fun binCommands() {
        assertEquals(VoiceCommand.BinSelectAll, cmd("select all"))
        assertEquals(VoiceCommand.BinRestoreAll, cmd("restore all"))
        assertEquals(VoiceCommand.BinRestoreSelected, cmd("restore selected"))
        assertEquals(VoiceCommand.BinRestore("ahmed"), cmd("restore Ahmed"))
    }

    @Test fun permanentDeleteNeedsTheWordPermanently() {
        val all = cmd("delete all permanently")
        assertTrue(all is VoiceCommand.BinDeletePermanently)
        val one = cmd("permanently delete Sara")
        assertTrue(one is VoiceCommand.BinDeletePermanently && (one as VoiceCommand.BinDeletePermanently).query == "sara")
        assertEquals(VoiceCommand.BinDeleteAmbiguous, cmd("delete all"))
        // "delete Sara" alone is the ordinary move-to-Bin command
        assertEquals(VoiceCommand.Find("sara", VoiceAction.DELETE), cmd("delete Sara"))
    }

    // ---- security is never reachable by voice

    @Test fun securityRequestsAreRefused() {
        for (phrase in listOf("enable app lock", "turn off app lock", "disable the lock", "change my pin", "remove app pin", "set a pin",
            "change fingerprint settings", "bypass authentication", "unlock the app", "open app lock")) {
            assertEquals("'$phrase'", VoiceCommand.SecurityRefused, cmd(phrase))
        }
    }

    // ---- confirmations stay strict

    @Test fun yesNoIsStrict() {
        assertEquals(YesNo.YES, VoiceCommandParser.parseYesNo("Yes"))
        assertEquals(YesNo.YES, VoiceCommandParser.parseYesNo("go ahead"))
        assertEquals(YesNo.NO, VoiceCommandParser.parseYesNo("no"))
        assertEquals(YesNo.NO, VoiceCommandParser.parseYesNo("yes no"))            // a NO word always wins
        assertNull(VoiceCommandParser.parseYesNo("delete"))                          // an echo of the command is not consent
        assertNull(VoiceCommandParser.parseYesNo("maybe"))
        assertNull(VoiceCommandParser.parseYesNo(""))
    }

    @Test fun permanentDeleteConfirmationIsEvenStricter() {
        assertEquals(YesNo.YES, VoiceCommandParser.parseStrictYesNo("yes"))
        assertEquals(YesNo.YES, VoiceCommandParser.parseStrictYesNo("confirm"))
        assertNull(VoiceCommandParser.parseStrictYesNo("ok"))
        assertNull(VoiceCommandParser.parseStrictYesNo("sure"))
    }

    // ---- fields and spoken values

    @Test fun editFields() {
        assertEquals(EditField.NAME, VoiceCommandParser.parseEditField("the name"))
        assertEquals(EditField.PHONE, VoiceCommandParser.parseEditField("phone number"))
        assertEquals(EditField.EMAIL, VoiceCommandParser.parseEditField("email"))
        assertNull(VoiceCommandParser.parseEditField("name and email"))
        assertNull(VoiceCommandParser.parseEditField("something else"))
    }

    @Test fun ordinals() {
        assertEquals(0, VoiceCommandParser.parseOrdinal("first"))
        assertEquals(1, VoiceCommandParser.parseOrdinal("the second one"))
        assertNull(VoiceCommandParser.parseOrdinal("ahmed khan"))
    }

    @Test fun spokenPhoneNumbers() {
        assertEquals("03001234567", VoiceCommandParser.normalizeSpokenPhone("zero three zero zero one two three four five six seven"))
        assertEquals("0300", VoiceCommandParser.normalizeSpokenPhone("zero three double zero"))
        assertEquals("call me maybe", VoiceCommandParser.normalizeSpokenPhone("call me maybe"))
    }

    @Test fun spokenEmail() {
        assertEquals("ahmed@example.com", VoiceCommandParser.normalizeSpokenEmail("ahmed at example dot com"))
    }

    @Test fun clearAndSkip() {
        assertTrue(VoiceCommandParser.isClear("clear"))
        assertFalse(VoiceCommandParser.isClear("Lahore Cantt"))
        assertTrue(VoiceCommandParser.isSkip("skip"))
    }
}
