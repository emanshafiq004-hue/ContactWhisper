package com.contactwhisper.app;

import static org.junit.Assert.*;

import com.contactwhisper.app.domain.ContactValidator;

import org.junit.Test;

public class ContactValidatorTest {

    @Test
    public void nameAndPhoneAreRequired() {
        ContactValidator.Result r = ContactValidator.validate("  ", "", "", "", "");
        assertFalse(r.isValid());
        assertNotNull(r.nameError);
        assertNotNull(r.phoneError);
        assertNull(r.emailError);
    }

    @Test
    public void validMinimalContact() {
        assertTrue(ContactValidator.validate("Ann", "0300 1234567", "", "", "").isValid());
    }

    @Test
    public void manualFormsRequireAnElevenDigitPakistaniMobile() {
        String[] ok = {"03001234567", "0300 1234567", "0300-1234567", "0300 123 4567", "+92 300 1234567",
                "+92-300-1234567", "+923001234567", "00923001234567"};
        for (String p : ok) assertNull(p, ContactValidator.validateMobile(p));
        String[] bad = {"", "   ", "0300123456", "030012345678", "04001234567", "300 1234567", "+1 415 555 2671",
                "(0300) 1234567", "0300.1234567", "0300 123456a", "+92 21 1234567", "112", "+92+300 1234567"};
        for (String p : bad) assertNotNull(p, ContactValidator.validateMobile(p));
    }

    @Test
    public void plusNinetyTwoIsConvertedToLocalFormat() {
        assertEquals("03001234567", ContactValidator.normalizePkMobile("+92 300 1234567"));
        assertEquals("03451234567", ContactValidator.normalizePkMobile("0345-123-4567"));
        assertEquals("03001234567", ContactValidator.phoneForSave(" +92-300-1234567 "));
        assertNull(ContactValidator.normalizePkMobile("+92 400 1234567"));
        assertEquals("Not a number", ContactValidator.phoneForSave("  Not a number "));
    }

    @Test
    public void formValidationUsesMobileRuleButNeverBlocksAnUntouchedImportedNumber() {
        // new contact with a foreign number: rejected
        assertNotNull(ContactValidator.validate("Ann", "+44 20 7946 0958", "", "", "").phoneError);
        // editing a contact whose imported (non-mobile) number is unchanged: accepted
        assertNull(ContactValidator.validate("Ann", "+44 20 7946 0958", "", "", "", "+44 20 7946 0958").phoneError);
        // ... but changing it to another non-mobile number is rejected
        assertNotNull(ContactValidator.validate("Ann", "021 1234567", "", "", "", "+44 20 7946 0958").phoneError);
    }

    @Test
    public void emergencyNumbersAreNotSubjectToTheMobileRule() {
        for (String n : new String[]{"15", "100", "112", "1122", "+92 21 111 222"}) {
            assertNull(n, ContactValidator.validateEmergencyNumber(n));
            assertNotNull(n, ContactValidator.validateMobile(n));
        }
    }

    @Test
    public void internationalAndFormattedPhonesAreAccepted() {
        String[] ok = {"+92 300 1234567", "+1 (415) 555-2671", "0300-1234567", "112", "+44 20 7946 0958", "*123#"};
        for (String p : ok) assertNull(p, ContactValidator.validatePhone(p));
    }

    @Test
    public void badPhonesAreRejected() {
        String[] bad = {"abc", "12", "+92+300 1234567", "1234567890123456", "0300 12x4567"};
        for (String p : bad) assertNotNull(p, ContactValidator.validatePhone(p));
    }

    @Test
    public void emailIsOptionalButValidatedWhenPresent() {
        assertNull(ContactValidator.validateEmail(""));
        assertNull(ContactValidator.validateEmail("john@example.com"));
        assertNotNull(ContactValidator.validateEmail("john@"));
        assertNotNull(ContactValidator.validateEmail("john example.com"));
        assertNotNull(ContactValidator.validateEmail("a@b"));
    }

    @Test
    public void emergencyNumbersAllowShortCodes() {
        assertNull(ContactValidator.validateEmergencyNumber("15"));
        assertNull(ContactValidator.validateEmergencyNumber("1122"));
        assertNull(ContactValidator.validateEmergencyNumber("+92 21 111 222"));
        assertNotNull(ContactValidator.validateEmergencyNumber("1"));
        assertNotNull(ContactValidator.validateEmergencyNumber(""));
        assertNotNull(ContactValidator.validateEmergencyNumber("12ab"));
    }

    @Test
    public void lengthLimits() {
        String longName = new String(new char[ContactValidator.MAX_NAME + 1]).replace('\0', 'a');
        assertNotNull(ContactValidator.validateName(longName));
        String longNotes = new String(new char[ContactValidator.MAX_NOTES + 1]).replace('\0', 'n');
        assertNotNull(ContactValidator.validate("A", "03001234567", "", "", longNotes).notesError);
    }
}
