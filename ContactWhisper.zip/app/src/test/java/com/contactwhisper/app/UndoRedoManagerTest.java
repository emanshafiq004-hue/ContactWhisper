package com.contactwhisper.app;

import static com.contactwhisper.app.TestData.c;
import static org.junit.Assert.*;

import com.contactwhisper.app.dsa.ContactIndex;
import com.contactwhisper.app.dsa.ContactRecord;
import com.contactwhisper.app.dsa.UndoRedoManager;
import com.contactwhisper.app.dsa.UndoableAction;

import org.junit.Test;

import java.util.Collections;

public class UndoRedoManagerTest {

    /** Minimal applier mirroring what the Kotlin repository does, so the stack protocol is verified end-to-end. */
    private static void apply(ContactIndex idx, UndoableAction a, boolean undoing) {
        switch (a.getType()) {
            case ADD:
                if (undoing) idx.remove(a.getContactId()); else idx.add(a.getAfter());
                break;
            case DELETE:
                if (undoing) idx.add(a.getBefore()); else idx.remove(a.getContactId());
                break;
            case RESTORE:
                if (undoing) idx.remove(a.getContactId()); else idx.add(a.getAfter());
                break;
            default: // EDIT, FAVORITE, CATEGORY
                idx.update(undoing ? a.getBefore() : a.getAfter());
        }
    }

    private static void undo(UndoRedoManager m, ContactIndex idx) {
        UndoableAction a = m.peekUndo();
        apply(idx, a, true);
        m.commitUndo();
    }

    private static void redo(UndoRedoManager m, ContactIndex idx) {
        UndoableAction a = m.peekRedo();
        apply(idx, a, false);
        m.commitRedo();
    }

    @Test
    public void undoAndRedoAddRestoreAndReapply() {
        ContactIndex idx = new ContactIndex();
        UndoRedoManager m = new UndoRedoManager();
        ContactRecord a = c(1, "Ann", "111");
        idx.add(a);
        m.record(UndoableAction.add(a));

        undo(m, idx);
        assertEquals(0, idx.size());
        assertTrue(m.canRedo());
        assertFalse(m.canUndo());

        redo(m, idx);
        assertEquals(1, idx.size());
        assertEquals(a, idx.get(1));
        assertTrue(idx.isConsistent());
    }

    @Test
    public void editRestoresExactBeforeFields() {
        ContactIndex idx = new ContactIndex();
        UndoRedoManager m = new UndoRedoManager();
        ContactRecord before = c(1, "Ann", "111");
        idx.rebuild(Collections.singletonList(before));
        ContactRecord after = before.withDetails("Anna", "222", "a@x.com", "Road 1", "note", "Work", 5000);
        idx.update(after);
        m.record(UndoableAction.edit(before, after));

        undo(m, idx);
        assertEquals(before, idx.get(1));
        assertEquals(0, idx.findByEmail("a@x.com").size());
        assertEquals(1, idx.findByPhone("111").size());

        redo(m, idx);
        assertEquals(after, idx.get(1));
        assertTrue(idx.isConsistent());
    }

    @Test
    public void deleteUndoBringsBackContactWithState() {
        ContactIndex idx = new ContactIndex();
        UndoRedoManager m = new UndoRedoManager();
        ContactRecord r = c(1, "Ann", "111").withFavorite(true).withCategory("Family");
        idx.add(r);
        idx.remove(1);
        m.record(UndoableAction.delete(r));

        undo(m, idx);
        ContactRecord back = idx.get(1);
        assertTrue(back.isFavorite());
        assertEquals("Family", back.getCategory());

        redo(m, idx);
        assertNull(idx.get(1));
    }

    @Test
    public void favoriteChangeIsReversible() {
        ContactIndex idx = new ContactIndex();
        UndoRedoManager m = new UndoRedoManager();
        ContactRecord before = c(1, "Ann", "111");
        ContactRecord after = before.withFavorite(true);
        idx.add(before);
        idx.update(after);
        m.record(UndoableAction.favorite(before, after));
        undo(m, idx);
        assertFalse(idx.get(1).isFavorite());
        redo(m, idx);
        assertTrue(idx.get(1).isFavorite());
    }

    @Test
    public void newActionAfterUndoClearsRedoHistory() {
        UndoRedoManager m = new UndoRedoManager();
        m.record(UndoableAction.add(c(1, "A", "1")));
        m.record(UndoableAction.add(c(2, "B", "2")));
        m.commitUndo();                     // pretend B was undone
        assertTrue(m.canRedo());
        m.record(UndoableAction.add(c(3, "C", "3")));
        assertFalse("redo must be cleared by a new action", m.canRedo());
        assertEquals(2, m.undoSize());
    }

    @Test
    public void multipleUndoRedoFollowLifoOrder() {
        UndoRedoManager m = new UndoRedoManager();
        UndoableAction a1 = UndoableAction.add(c(1, "A", "1"));
        UndoableAction a2 = UndoableAction.add(c(2, "B", "2"));
        UndoableAction a3 = UndoableAction.add(c(3, "C", "3"));
        m.record(a1); m.record(a2); m.record(a3);
        assertSame(a3, m.peekUndo()); m.commitUndo();
        assertSame(a2, m.peekUndo()); m.commitUndo();
        assertSame(a2, m.peekRedo()); m.commitRedo();   // redo returns the most recently undone first
        assertSame(a2, m.peekUndo());
        assertEquals(1, m.redoSize());
    }

    @Test
    public void discardDropsFailedActionWithoutMovingToRedo() {
        UndoRedoManager m = new UndoRedoManager();
        m.record(UndoableAction.delete(c(1, "A", "1")));
        m.discardUndo();
        assertFalse(m.canUndo());
        assertFalse(m.canRedo());
    }

    @Test
    public void emptyManagerHasNothingToDo() {
        UndoRedoManager m = new UndoRedoManager();
        assertFalse(m.canUndo());
        assertFalse(m.canRedo());
        assertNull(m.peekUndo());
        assertNull(m.peekRedo());
    }

    @Test
    public void labelsAndContactIds() {
        assertEquals("Add contact", UndoableAction.add(c(7, "A", "1")).getLabel());
        assertEquals(7, UndoableAction.delete(c(7, "A", "1")).getContactId());
        assertEquals(7, UndoableAction.add(c(7, "A", "1")).getContactId());
    }

    // ------------------------------------------------------------ restore + permanent-delete invalidation

    @Test
    public void restoreIsUndoableAndRedoable() {
        ContactIndex idx = new ContactIndex();
        UndoRedoManager m = new UndoRedoManager();
        ContactRecord r = c(1, "Ann", "111");
        m.record(UndoableAction.restore(r));
        idx.add(r);                                  // contact was restored into the list

        undo(m, idx);                                // undo the RESTORE -> back in the Bin
        assertNull(idx.get(1));
        assertTrue(m.canRedo());

        redo(m, idx);                                // redo -> restored again
        assertNotNull(idx.get(1));
        assertEquals("Restore contact", UndoableAction.restore(r).getLabel());
    }

    @Test
    public void purgeRemovesEveryEntryForTheIdFromBothStacks() {
        UndoRedoManager m = new UndoRedoManager();
        ContactRecord a = c(1, "A", "111");
        ContactRecord b = c(2, "B", "222");
        m.record(UndoableAction.add(a));
        m.record(UndoableAction.add(b));
        m.record(UndoableAction.edit(a, a.withCategory("Work")));
        m.record(UndoableAction.delete(a));
        m.record(UndoableAction.restore(a));
        m.commitUndo();                              // the RESTORE of A now sits on the redo stack
        m.record(UndoableAction.favorite(b, b.withFavorite(true)));   // clears redo
        m.record(UndoableAction.delete(a));
        m.commitUndo();                              // a DELETE of A now sits on redo as well

        assertTrue(m.mentions(1));
        int removed = m.purgeContacts(Collections.singletonList(1L));
        assertTrue(removed >= 4);
        assertFalse("no history may mention a purged id", m.mentions(1));
        assertTrue("other contacts keep their history", m.mentions(2));
        // what is left is exactly B's add + favorite
        assertEquals(2, m.undoSize());
        assertEquals(0, m.redoSize());
        assertEquals(UndoableAction.Type.FAVORITE, m.peekUndo().getType());
    }

    @Test
    public void purgeKeepsRelativeOrderOfRemainingEntries() {
        UndoRedoManager m = new UndoRedoManager();
        UndoableAction a1 = UndoableAction.add(c(1, "A", "1"));
        UndoableAction a2 = UndoableAction.add(c(2, "B", "2"));
        UndoableAction a3 = UndoableAction.add(c(3, "C", "3"));
        m.record(a1); m.record(a2); m.record(a3);
        m.purgeContacts(Collections.singletonList(2L));
        assertSame(a3, m.peekUndo()); m.commitUndo();
        assertSame(a1, m.peekUndo());
        assertEquals(0, m.purgeContacts(Collections.<Long>emptyList()));
    }
}
