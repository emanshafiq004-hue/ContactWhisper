package com.contactwhisper.app;

import static com.contactwhisper.app.TestData.c;
import static com.contactwhisper.app.TestData.full;
import static org.junit.Assert.*;

import com.contactwhisper.app.dsa.ContactAlgorithms;
import com.contactwhisper.app.dsa.ContactLinkedList;
import com.contactwhisper.app.dsa.ContactRecord;
import com.contactwhisper.app.dsa.SortMode;

import org.junit.Test;

public class ContactAlgorithmsTest {

    private static String names(ContactRecord[] arr) {
        StringBuilder sb = new StringBuilder();
        for (ContactRecord r : arr) sb.append(r.getName()).append(',');
        return sb.toString();
    }

    private ContactLinkedList sample() {
        ContactLinkedList list = new ContactLinkedList();
        list.insertLast(full(1, "Ahmed Khan", "+92 300 1234567", "ahmed@example.com", "Karachi, Pakistan", "Friend from college", "Friends", 100));
        list.insertLast(full(2, "fatima Ali", "0301 7654321", "", "Lahore", "", "Family", 300));
        list.insertLast(full(3, "Bilal Hussain", "(0302) 987-6543", "bilal@work.org", "", "Project lead", "Work", 200));
        return list;
    }

    // ------------------------------------------------------------ normalisation

    @Test
    public void phoneNormalisation() {
        assertEquals("923001234567", ContactAlgorithms.normalizePhone("+92 (300) 123-4567"));
        assertEquals("", ContactAlgorithms.normalizePhone(null));
        assertEquals(ContactAlgorithms.phoneKey("0300 1234567"), ContactAlgorithms.phoneKey("+92 300 1234567"));
        assertEquals("112", ContactAlgorithms.phoneKey("112"));
        assertEquals("ali khan", ContactAlgorithms.nameKey("  ALI    Khan "));
        assertEquals("a@b.com", ContactAlgorithms.emailKey("  A@B.Com "));
    }

    // ------------------------------------------------------------ search

    @Test
    public void searchByEveryField() {
        ContactLinkedList l = sample();
        assertEquals("Ahmed Khan,", names(ContactAlgorithms.search(l, "ahm")));          // name partial
        assertEquals("Ahmed Khan,", names(ContactAlgorithms.search(l, "EXAMPLE.COM")));  // email, case-insensitive
        assertEquals("fatima Ali,", names(ContactAlgorithms.search(l, "lahore")));       // address
        assertEquals("Bilal Hussain,", names(ContactAlgorithms.search(l, "project")));   // notes
        assertEquals("Bilal Hussain,", names(ContactAlgorithms.search(l, "work")));      // category
    }

    @Test
    public void searchPhoneIgnoresPunctuation() {
        ContactLinkedList l = sample();
        assertEquals("Ahmed Khan,", names(ContactAlgorithms.search(l, "3001234")));
        assertEquals("Ahmed Khan,", names(ContactAlgorithms.search(l, "300 123-4")));
        assertEquals("Bilal Hussain,", names(ContactAlgorithms.search(l, "0302987")));
    }

    @Test
    public void emptyQueryReturnsAllVisibleAndNoMatchReturnsEmpty() {
        ContactLinkedList l = sample();
        assertEquals(3, ContactAlgorithms.search(l, "").length);
        assertEquals(3, ContactAlgorithms.search(l, null).length);
        assertEquals(0, ContactAlgorithms.search(l, "zzzzqqq").length);
    }


    // ------------------------------------------------------------ sorting

    @Test
    public void sortAzIsCaseInsensitive() {
        ContactRecord[] in = ContactAlgorithms.search(sample(), "");
        assertEquals("Ahmed Khan,Bilal Hussain,fatima Ali,", names(ContactAlgorithms.sort(in, SortMode.A_Z)));
    }

    @Test
    public void sortZaIsExactReverseOfAz() {
        ContactRecord[] in = ContactAlgorithms.search(sample(), "");
        assertEquals("fatima Ali,Bilal Hussain,Ahmed Khan,", names(ContactAlgorithms.sort(in, SortMode.Z_A)));
    }

    @Test
    public void sortRecentlyAddedUsesCreationTimestamp() {
        ContactRecord[] in = ContactAlgorithms.search(sample(), "");
        // created: Ahmed=100, Bilal=200, fatima=300
        assertEquals("fatima Ali,Bilal Hussain,Ahmed Khan,", names(ContactAlgorithms.sort(in, SortMode.RECENTLY_ADDED)));
    }

    @Test
    public void sortByCategoryThenNameWithUncategorisedLast() {
        ContactLinkedList l = sample();
        l.insertLast(full(5, "Zed", "555", "", "", "", "Family", 500));
        l.insertLast(full(6, "Nobody", "666", "", "", "", "", 600));
        ContactRecord[] sorted = ContactAlgorithms.sort(ContactAlgorithms.search(l, ""), SortMode.BY_CATEGORY);
        // Family: fatima, Zed | Friends: Ahmed | Work: Bilal | none: Nobody
        assertEquals("fatima Ali,Zed,Ahmed Khan,Bilal Hussain,Nobody,", names(sorted));
    }

    @Test
    public void mergeSortIsStableAndDoesNotMutateInput() {
        ContactRecord[] in = {
                c(1, "Sam", "1"), c(2, "sam", "2"), c(3, "Sam", "3")
        };
        // comparator ignoring ids: all equal -> stable sort must preserve input order
        ContactRecord[] out = ContactAlgorithms.mergeSort(in, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        assertEquals(1, out[0].getId());
        assertEquals(2, out[1].getId());
        assertEquals(3, out[2].getId());
        assertEquals(1, in[0].getId()); // input untouched
    }

    @Test
    public void mergeSortLargeRandomInputIsSorted() {
        java.util.Random rnd = new java.util.Random(42);
        ContactRecord[] in = new ContactRecord[500];
        for (int i = 0; i < in.length; i++) in[i] = c(i, "n" + rnd.nextInt(10000), "" + i);
        ContactRecord[] out = ContactAlgorithms.sort(in, SortMode.A_Z);
        for (int i = 1; i < out.length; i++) {
            assertTrue(ContactAlgorithms.NAME_ASC.compare(out[i - 1], out[i]) <= 0);
        }
        assertEquals(in.length, out.length);
    }

    @Test
    public void sortEmptyAndSingle() {
        assertEquals(0, ContactAlgorithms.sort(new ContactRecord[0], SortMode.A_Z).length);
        assertEquals(1, ContactAlgorithms.sort(new ContactRecord[]{c(1, "A", "1")}, SortMode.Z_A).length);
    }

    @Test
    public void customSubstringSearchIsCaseInsensitiveAndHandlesEdges() {
        assertTrue(ContactAlgorithms.containsIgnoreCase("Ahmed Khan", "med k"));
        assertTrue(ContactAlgorithms.containsIgnoreCase("Ahmed Khan", "ahmed khan"));
        assertTrue(ContactAlgorithms.containsIgnoreCase("Ahmed Khan", "khan"));   // match at the very end
        assertTrue(ContactAlgorithms.containsIgnoreCase("Ahmed Khan", ""));        // empty pattern matches
        assertFalse(ContactAlgorithms.containsIgnoreCase("Ahmed", "ahmedd"));      // pattern longer than text
        assertFalse(ContactAlgorithms.containsIgnoreCase("", "a"));
        assertFalse(ContactAlgorithms.containsIgnoreCase("aaab", "aab" + "c"));
        assertTrue(ContactAlgorithms.containsIgnoreCase("aaab", "aab"));           // overlapping prefix restarts correctly
    }
}
