package com.contactwhisper.app;

import static org.junit.Assert.*;

import com.contactwhisper.app.dsa.CustomStack;

import org.junit.Test;

public class CustomStackTest {

    @Test
    public void lifoOrder() {
        CustomStack<Integer> s = new CustomStack<>();
        s.push(1);
        s.push(2);
        s.push(3);
        assertEquals(3, (int) s.peek());
        assertEquals(3, (int) s.pop());
        assertEquals(2, (int) s.pop());
        assertEquals(1, (int) s.pop());
        assertTrue(s.isEmpty());
    }

    @Test
    public void growsPastInitialCapacity() {
        CustomStack<Integer> s = new CustomStack<>();
        for (int i = 0; i < 1000; i++) s.push(i);
        assertEquals(1000, s.size());
        for (int i = 999; i >= 0; i--) assertEquals(i, (int) s.pop());
    }

    @Test(expected = IllegalStateException.class)
    public void popOnEmptyThrows() {
        new CustomStack<String>().pop();
    }

    @Test(expected = IllegalStateException.class)
    public void peekOnEmptyThrows() {
        new CustomStack<String>().peek();
    }

    @Test
    public void clearResetsSize() {
        CustomStack<String> s = new CustomStack<>();
        s.push("a");
        s.push("b");
        s.clear();
        assertEquals(0, s.size());
        assertTrue(s.isEmpty());
        s.push("c");
        assertEquals("c", s.peek());
    }

    @Test
    public void removeIfKeepsOrderAndReportsCount() {
        CustomStack<Integer> st = new CustomStack<>();
        for (int i = 1; i <= 6; i++) st.push(i);
        assertEquals(3, st.removeIf(v -> v % 2 == 0));
        assertEquals(3, st.size());
        assertEquals(java.util.Arrays.asList(5, 3, 1), st.toListTopFirst());
        assertEquals(0, st.removeIf(v -> false));
        assertEquals(3, st.removeIf(v -> true));
        assertTrue(st.isEmpty());
    }
}
