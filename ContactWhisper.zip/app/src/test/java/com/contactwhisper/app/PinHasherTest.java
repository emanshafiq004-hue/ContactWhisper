package com.contactwhisper.app;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import com.contactwhisper.app.data.PinHasher;
import org.junit.Test;

/** App-PIN storage: salted PBKDF2 hash, never the PIN itself. (Kotlin object, called through INSTANCE.) */
public class PinHasherTest {

    @Test
    public void correctPinVerifiesAndWrongPinDoesNot() {
        byte[] salt = PinHasher.INSTANCE.newSalt();
        byte[] hash = PinHasher.INSTANCE.hash("2468", salt);
        assertTrue(PinHasher.INSTANCE.verify("2468", salt, hash));
        assertFalse(PinHasher.INSTANCE.verify("2469", salt, hash));
        assertFalse(PinHasher.INSTANCE.verify("", salt, hash));
    }

    @Test
    public void hashIsNotThePinAndIsSalted() {
        byte[] s1 = PinHasher.INSTANCE.newSalt();
        byte[] s2 = PinHasher.INSTANCE.newSalt();
        assertEquals(16, s1.length);
        assertNotEquals("salts must differ", PinHasher.INSTANCE.encode(s1), PinHasher.INSTANCE.encode(s2));
        byte[] h1 = PinHasher.INSTANCE.hash("1234", s1);
        byte[] h2 = PinHasher.INSTANCE.hash("1234", s2);
        assertEquals(32, h1.length);
        assertNotEquals("same PIN, different salt => different hash",
                PinHasher.INSTANCE.encode(h1), PinHasher.INSTANCE.encode(h2));
        assertFalse(PinHasher.INSTANCE.encode(h1).contains("1234"));
    }

    @Test
    public void hashIsDeterministicForSameSalt() {
        byte[] salt = PinHasher.INSTANCE.newSalt();
        assertArrayEquals(PinHasher.INSTANCE.hash("9999", salt), PinHasher.INSTANCE.hash("9999", salt));
    }

    @Test
    public void encodeDecodeRoundTrips() {
        byte[] salt = PinHasher.INSTANCE.newSalt();
        assertArrayEquals(salt, PinHasher.INSTANCE.decode(PinHasher.INSTANCE.encode(salt)));
    }

    @Test
    public void formatRules() {
        assertTrue(PinHasher.INSTANCE.isValidFormat("1234"));
        assertTrue(PinHasher.INSTANCE.isValidFormat("123456789012"));
        assertFalse(PinHasher.INSTANCE.isValidFormat("123"));
        assertFalse(PinHasher.INSTANCE.isValidFormat("1234567890123"));
        assertFalse(PinHasher.INSTANCE.isValidFormat("12a4"));
        assertFalse(PinHasher.INSTANCE.isValidFormat(""));
    }
}
