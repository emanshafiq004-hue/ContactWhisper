package com.contactwhisper.app.voice

import com.contactwhisper.app.data.ContactDraft
import com.contactwhisper.app.dsa.ContactRecord
import com.contactwhisper.app.dsa.DuplicateMatch
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** The state machine, driven exactly the way the Android layer drives it (final transcripts, taps, silence). */
class VoiceConversationTest {

    private class FakeBackend : VoiceBackend {
        val contacts = ArrayList<ContactRecord>()
        var bin = listOf<VoiceBin>()
        var selection = setOf<String>()
        var emergency = listOf<VoiceEmergency>()
        private var next = 1L

        fun add(name: String, phone: String, email: String = "", category: String = "", favorite: Boolean = false): ContactRecord {
            val r = ContactRecord(next++, name, phone, email, "", "", category, favorite, next, next)
            contacts += r
            return r
        }

        override fun search(query: String) = contacts.filter {
            val q = query.lowercase()
            it.name.lowercase().contains(q) || it.phone.contains(q) || it.email.lowercase().contains(q) || it.category.lowercase().contains(q)
        }
        override fun inCategory(category: String) = contacts.filter { it.category.equals(category, true) }
        override fun categoryNames() = listOf("Family", "Friends", "Work", "Other")
        override fun get(id: Long) = contacts.firstOrNull { it.id == id }
        override fun duplicates(draft: ContactDraft, excludeId: Long): List<DuplicateMatch> = emptyList()
        override fun binEntries() = bin
        override fun binSelection() = selection
        override fun emergencyEntries() = emergency
        override fun profileName() = "Eman"
        override fun expandedCategories() = emptySet<String>()
    }

    private lateinit var backend: FakeBackend
    private lateinit var convo: VoiceConversation
    private lateinit var ahmed: ContactRecord
    private lateinit var sara: ContactRecord

    private val ready = VoiceEnvironment(hasPermission = true, recognitionAvailable = true)

    @Before fun setUp() {
        backend = FakeBackend()
        ahmed = backend.add("Ahmed Khan", "03001234567", "ahmed@example.com", "Friends")
        sara = backend.add("Sara Ali", "03217654321", "", "Work")
        backend.add("Ali Raza", "03331112223")
        backend.add("Ali Hassan", "03441112223")
        convo = VoiceConversation(backend)
    }

    private fun open(): List<VoiceEffect> = convo.open(ready)
    private fun hear(text: String) = convo.onTranscript(listOf(text))
    private fun spoken(effects: List<VoiceEffect>) = effects.filterIsInstance<VoiceEffect.Speak>().map { it.text }
    private fun executed(effects: List<VoiceEffect>) = effects.filterIsInstance<VoiceEffect.Execute>().map { it.request }

    // ---- session start

    @Test fun openingWithPermissionStartsListeningWithoutSpeaking() {
        val e = open()
        assertEquals(VoiceState.AwaitingCommand, convo.state)
        assertTrue(spoken(e).isEmpty())
        assertTrue(convo.wantsInput)
    }

    @Test fun missingPermissionIsRequestedThenHonoured() {
        val e = convo.open(VoiceEnvironment(hasPermission = false, recognitionAvailable = true))
        assertTrue(e.contains(VoiceEffect.RequestPermission))
        assertFalse(convo.wantsInput)
        convo.onPermissionResult(true)
        assertEquals(VoiceState.AwaitingCommand, convo.state)
    }

    @Test fun deniedPermissionLeavesOnlyCloseAvailable() {
        convo.open(VoiceEnvironment(hasPermission = false, recognitionAvailable = true))
        convo.onPermissionResult(false)
        assertTrue(convo.state is VoiceState.Unavailable)
        assertFalse(convo.wantsInput)
    }

    @Test fun missingRecognizerIsReportedNotCrashed() {
        convo.open(VoiceEnvironment(hasPermission = true, recognitionAvailable = false))
        assertTrue(convo.state is VoiceState.Unavailable)
    }

    @Test fun aSecondOpenWhileActiveIsIgnored() {
        open()
        hear("find ahmed")
        val before = convo.snapshot
        assertTrue(open().isEmpty())
        assertEquals(before, convo.snapshot)
    }

    // ---- silence is not a command / unrecognized speech

    @Test fun silenceChangesNothingSaysNothingAndKeepsListening() {
        open()
        val before = convo.snapshot
        val e = convo.onSilence()
        assertTrue(e.isEmpty())
        assertEquals(before, convo.snapshot)
        assertTrue(convo.wantsInput)
    }

    @Test fun silenceInTheMiddleOfAQuestionKeepsTheQuestion() {
        open(); hear("find ahmed khan")
        val state = convo.state
        convo.onSilence(); convo.onSilence()
        assertEquals(state, convo.state)
    }

    @Test fun unrecognizedSpeechIsAnsweredOnceAndListeningContinues() {
        open()
        val e = hear("blah blah")
        // an unknown phrase is a contact search; nothing matches, so it is reported and the session stays open
        assertEquals(VoiceState.AwaitingCommand, convo.state)
        assertTrue(convo.wantsInput)
        assertTrue(spoken(e).isNotEmpty())
        val e2 = convo.onNotUnderstood()
        assertEquals(listOf(VoiceConversation.PHRASE_DIDNT_CATCH), spoken(e2))
        assertEquals(VoiceConversation.PHRASE_DIDNT_CATCH, convo.snapshot.assistant)
        assertEquals(VoiceState.AwaitingCommand, convo.state)
        assertTrue(convo.wantsInput)
    }

    @Test fun unclearSpeechNeverExecutesAnything() {
        open()
        for (phrase in listOf("mumble", "uh", "the", "okay then")) assertTrue(executed(hear(phrase)).isEmpty())
    }

    // ---- the View bug

    @Test fun viewAfterFindActsOnTheSelectedContact() {
        open()
        hear("find ahmed khan")
        assertTrue(convo.state is VoiceState.AskingAction)
        assertEquals("I found Ahmed Khan. What would you like to do?", convo.snapshot.assistant)
        val e = hear("View.")
        assertTrue(e.contains(VoiceEffect.OpenDetails(ahmed.id)))
        assertEquals(VoiceState.AwaitingCommand, convo.state) // not a new search for "view"
    }

    @Test fun everyViewPhraseWorksInAskingAction() {
        for (phrase in listOf("view", "View this contact", "Open contact", "Show details", "show me the details")) {
            val c = VoiceConversation(backend)
            c.open(ready)
            c.onTranscript(listOf("find ahmed khan"))
            val e = c.onTranscript(listOf(phrase))
            assertTrue("'$phrase'", e.contains(VoiceEffect.OpenDetails(ahmed.id)))
        }
    }

    @Test fun viewHomophoneIsAcceptedOnlyAsTheAnswerToWhatNext() {
        open(); hear("find ahmed khan")
        val e = hear("you")
        assertTrue(e.contains(VoiceEffect.OpenDetails(ahmed.id)))
    }

    @Test fun showNameOpensThatContact() {
        open()
        val e = hear("Show Ahmed Khan")
        assertTrue(e.contains(VoiceEffect.OpenDetails(ahmed.id)) || convo.state is VoiceState.AskingAction)
    }

    // ---- multiple / no matches

    @Test fun multipleMatchesAreListedNeverGuessed() {
        open()
        val e = hear("find ali")
        val s = convo.state as VoiceState.Choosing
        assertTrue(s.options.size >= 3)
        assertTrue(executed(e).isEmpty())
        assertTrue(e.none { it is VoiceEffect.OpenDetails || it is VoiceEffect.Dial })
    }

    @Test fun choosingByTapOrSpeechContinuesWithThatContact() {
        open(); hear("find ali")
        val choice = (convo.state as VoiceState.Choosing).options.first { it.label == "Ali Raza" }
        convo.onChoiceTapped(choice.id)
        assertTrue(convo.state is VoiceState.AskingAction)
        assertEquals("Ali Raza", (convo.state as VoiceState.AskingAction).contact.name)
    }

    @Test fun noMatchIsReportedAndListeningContinues() {
        open()
        val e = hear("find zaid")
        assertEquals(VoiceState.AwaitingCommand, convo.state)
        assertEquals("I couldn't find a contact matching zaid.", spoken(e).single())
        assertTrue(convo.wantsInput)
    }

    // ---- delete (to the Bin) needs an explicit yes

    @Test fun deleteNeedsConfirmationAndThenExecutes() {
        open()
        hear("delete sara")
        assertTrue(convo.state is VoiceState.ConfirmingDelete)
        // an echo of the command is not consent
        assertTrue(executed(hear("delete")).isEmpty())
        assertTrue(convo.state is VoiceState.ConfirmingDelete)
        val e = hear("yes")
        assertEquals(listOf<ActionRequest>(ActionRequest.MoveToBin(sara.id, "Sara Ali")), executed(e))
    }

    @Test fun decliningDeleteChangesNothing() {
        open(); hear("delete sara")
        assertTrue(executed(hear("no")).isEmpty())
        assertTrue(convo.isActive) // nothing deleted; the session stays open
        assertFalse(convo.state is VoiceState.ConfirmingDelete)
    }

    // ---- edit flow validates with the app's rules and confirms

    @Test fun editPhoneFlowAsksThenConfirmsThenExecutes() {
        open()
        hear("edit sara")
        assertTrue(convo.state is VoiceState.AskingEditField)
        assertEquals("What would you like to change: name, phone number, email, address, notes or category?", convo.snapshot.assistant)
        hear("phone number")
        assertTrue(convo.state is VoiceState.AskingEditValue)
        hear("zero three zero zero one two three four five six seven")
        val confirm = convo.state as VoiceState.ConfirmingEdit
        assertEquals("03001234567", confirm.newValue.filter { it.isDigit() })
        val e = hear("yes")
        assertTrue(executed(e).single() is ActionRequest.SaveEdit)
    }

    @Test fun cancelInTheMiddleOfAnEditChangesNothing() {
        open(); hear("edit sara"); hear("phone number")
        val e = hear("cancel")
        assertTrue(executed(e).isEmpty())
        assertEquals(VoiceState.AwaitingCommand, convo.state)
        assertEquals("Okay, cancelled.", convo.snapshot.assistant)
    }

    // ---- navigation commands keep the session open

    @Test fun navigationCommandsEmitNavigateAndStayOpen() {
        open()
        for ((phrase, screen) in listOf(
            "open home" to VoiceScreen.HOME, "open categories" to VoiceScreen.CATEGORIES, "open favorites" to VoiceScreen.FAVORITES,
            "open bin" to VoiceScreen.BIN, "open emergency services" to VoiceScreen.EMERGENCY, "open settings" to VoiceScreen.SETTINGS,
        )) {
            val e = hear(phrase)
            assertTrue("'$phrase'", e.contains(VoiceEffect.Navigate(screen)))
            assertEquals(VoiceState.AwaitingCommand, convo.state)
            assertTrue(convo.wantsInput)
        }
    }

    @Test fun backEmitsBackAndStaysOpen() {
        open()
        assertTrue(hear("go back").contains(VoiceEffect.Back))
        assertTrue(convo.isActive)
    }

    @Test fun severalCommandsInARowNeedNoRetap() {
        open()
        hear("open categories"); hear("open bin"); hear("open home"); hear("find sara")
        assertTrue(convo.isActive)
        assertTrue(convo.state is VoiceState.AskingAction)
        assertEquals(4, convo.snapshot.handled)
    }

    // ---- Bin operations: moving to the Bin vs permanent deletion

    @Test fun restoreAllRunsOnlyWhenTheBinHasEntries() {
        open()
        assertEquals("The Bin is empty.", spoken(hear("restore all")).last())
        backend.bin = listOf(VoiceBin("c:1", "Zed", false))
        val e = hear("restore all")
        assertTrue(executed(e).single() is ActionRequest.BinRestoreAll)
    }

    @Test fun permanentDeletionNeedsAnExplicitStrictYes() {
        backend.bin = listOf(VoiceBin("c:1", "Zed", false), VoiceBin("e:2", "Police", true))
        open()
        val e = hear("delete all permanently")
        assertTrue(executed(e).isEmpty())
        assertTrue(convo.state is VoiceState.ConfirmingBinDelete)
        // "ok" and "sure" are not strict enough for an irreversible delete
        assertTrue(executed(hear("ok")).isEmpty())
        assertTrue(convo.state is VoiceState.ConfirmingBinDelete)
        val done = executed(hear("yes"))
        val req = done.single() as ActionRequest.BinDeleteKeys
        assertEquals(setOf("c:1", "e:2"), req.keys.toSet())
    }

    @Test fun declinedPermanentDeletionDeletesNothing() {
        backend.bin = listOf(VoiceBin("c:1", "Zed", false))
        open(); hear("delete all permanently")
        assertTrue(executed(hear("no")).isEmpty())
        assertEquals(VoiceState.AwaitingCommand, convo.state)
    }

    @Test fun plainDeleteAllInTheBinIsNeverPermanent() {
        backend.bin = listOf(VoiceBin("c:1", "Zed", false))
        open()
        val e = hear("delete all")
        assertTrue(executed(e).isEmpty())
        assertEquals(VoiceState.AwaitingCommand, convo.state)
    }

    @Test fun permanentlyDeleteOneByName() {
        backend.bin = listOf(VoiceBin("c:7", "Sara Ali", false), VoiceBin("c:8", "Zed", false))
        open()
        hear("permanently delete sara")
        assertTrue(convo.state is VoiceState.ConfirmingBinDelete)
        val req = executed(hear("yes")).single() as ActionRequest.BinDeleteKeys
        assertEquals(listOf("c:7"), req.keys)
    }

    // ---- App Lock / security is unreachable by voice

    @Test fun securityRequestsAreRefusedAndExecuteNothing() {
        open()
        for (phrase in listOf("enable app lock", "turn off app lock", "remove app pin", "change fingerprint settings", "bypass authentication")) {
            val e = hear(phrase)
            assertTrue("'$phrase'", executed(e).isEmpty())
            assertEquals("'$phrase'", VoiceConversation.MSG_SECURITY, convo.snapshot.assistant)
            assertEquals(VoiceState.AwaitingCommand, convo.state)
        }
    }

    /**
     * The request vocabulary is closed. This `when` is exhaustive on purpose: adding any new request type breaks the
     * build here, forcing a review that it is not a security operation. None of today's types touches App Lock, the PIN,
     * biometrics or authentication.
     */
    private fun category(r: ActionRequest): String = when (r) {
        is ActionRequest.SaveEdit, is ActionRequest.MoveToBin, is ActionRequest.AddContact, is ActionRequest.SetFavorite -> "contact"
        is ActionRequest.ExpandCategory, is ActionRequest.CreateCategory, is ActionRequest.RenameCategory, is ActionRequest.RemoveCategory -> "category"
        is ActionRequest.SetSort, is ActionRequest.SetTheme -> "display"
        ActionRequest.BinSelectAll, ActionRequest.BinClearSelection, ActionRequest.BinRestoreSelected, ActionRequest.BinRestoreAll,
        is ActionRequest.BinRestoreOne, is ActionRequest.BinDeleteKeys -> "bin"
        is ActionRequest.AddEmergency, is ActionRequest.EditEmergency, is ActionRequest.RemoveEmergency -> "emergency"
        is ActionRequest.SaveProfileName -> "profile"
        ActionRequest.Undo, ActionRequest.Redo -> "history"
    }

    @Test fun everyRequestTypeIsOrdinaryContactDataNeverSecurity() {
        val samples = listOf<ActionRequest>(
            ActionRequest.Undo, ActionRequest.Redo, ActionRequest.BinSelectAll, ActionRequest.SaveProfileName("x"),
            ActionRequest.SetTheme(com.contactwhisper.app.data.AppTheme.EMERALD),
        )
        for (r in samples) assertTrue(category(r) in setOf("contact", "category", "display", "bin", "emergency", "profile", "history"))
    }

    // ---- closing

    @Test fun spokenCloseSaysGoodbyeThenEndsAfterSpeech() {
        open()
        val e = hear("close")
        assertEquals(VoiceState.Closing, convo.state)
        assertEquals(listOf(VoiceConversation.MSG_CLOSING), spoken(e))
        assertTrue(e.contains(VoiceEffect.CloseAfterSpeech))
        assertFalse(convo.wantsInput) // no listening while the closing sentence plays
        val end = convo.finishClose()
        assertTrue(end.contains(VoiceEffect.CloseNow))
        assertEquals(VoiceState.Idle, convo.state)
    }

    @Test fun closeButtonEndsTheSessionImmediately() {
        open(); hear("find sara")
        val e = convo.onClose()
        assertTrue(e.contains(VoiceEffect.CloseNow))
        assertEquals(VoiceState.Idle, convo.state)
        assertFalse(convo.wantsInput)
    }

    @Test fun leavingTheForegroundEndsTheSession() {
        open()
        convo.onInterrupted()
        assertEquals(VoiceState.Idle, convo.state)
        assertFalse(convo.wantsInput)
    }

    @Test fun nothingIsHeardOnceClosed() {
        open(); convo.onClose()
        assertTrue(hear("open bin").isEmpty())
        assertTrue(convo.onSilence().isEmpty())
    }

    // ---- no stale work after the user moved on

    @Test fun contactDeletedMeanwhileCannotBeEdited() {
        open(); hear("edit sara"); hear("phone number"); hear("03001112223")
        backend.contacts.remove(sara)
        val e = hear("yes")
        assertTrue(executed(e).isEmpty())
        assertNotNull(convo.snapshot.assistant)
    }

    @Test fun executionResultReturnsToTheCommandPrompt() {
        open(); hear("delete sara"); hear("yes")
        assertTrue(convo.state is VoiceState.ExecutingAction)
        assertFalse(convo.wantsInput) // not listening while the change runs
        convo.onExecutionResult(VoiceResult.ok())
        assertEquals(VoiceState.AwaitingCommand, convo.state)
        assertTrue(convo.wantsInput)
    }
}
