package com.contactwhisper.app;

import static com.contactwhisper.app.TestData.full;
import static org.junit.Assert.*;

import com.contactwhisper.app.dsa.ContactIndex;
import com.contactwhisper.app.dsa.ContactRecord;
import com.contactwhisper.app.dsa.DuplicateDetector;
import com.contactwhisper.app.dsa.DuplicateMatch;
import com.contactwhisper.app.dsa.SortMode;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class ContactIndexAndDuplicateTest {
    private ContactIndex index;

    private static ContactRecord rec(long id, String name, String phone, String email) {
        return full(id, name, phone, email, "", "", "", id);
    }

    @Before
    public void setUp() {
        index = new ContactIndex();
        index.rebuild(Arrays.asList(
                rec(1, "Ahmed Khan", "+92 300 1234567", "Ahmed@Example.com"),
                rec(2, "Fatima Ali", "0301 7654321", ""),
                rec(3, "Ahmed Khan", "0304 5550000", "")      // same name, different person
        ));
    }

    // ------------------------------------------------------------ index sync

    @Test
    public void rebuildAddUpdateRemoveKeepIndexesConsistent() {
        assertEquals(3, index.size());
        assertTrue(index.isConsistent());

        index.add(rec(4, "New One", "0305 111 2222", "new@x.com"));
        assertTrue(index.isConsistent());
        assertEquals(4, index.size());
        assertEquals(1, index.findByEmail("NEW@x.com").size());

        // update changes phone + email: old keys must disappear, new ones appear
        index.update(rec(4, "New One", "0306 999 8888", "other@x.com"));
        assertTrue(index.isConsistent());
        assertEquals(0, index.findByEmail("new@x.com").size());
        assertEquals(1, index.findByEmail("other@x.com").size());
        assertEquals(0, index.findByPhone("03051112222").size());
        assertEquals(1, index.findByPhone("0306 999 8888").size());

        assertEquals(4, index.remove(4).getId());
        assertEquals(0, index.findByEmail("other@x.com").size());
        assertNull(index.remove(4));
        assertTrue(index.isConsistent());
        assertEquals(3, index.size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void addingSameIdTwiceIsRejected() {
        index.add(rec(1, "Clone", "000", ""));
    }

    @Test
    public void updateOfUnknownIdReturnsFalse() {
        assertFalse(index.update(rec(99, "Ghost", "123", "")));
    }

    @Test
    public void searchAndSortGoThroughIndex() {
        ContactRecord[] res = index.search("ahmed", SortMode.A_Z);
        assertEquals(2, res.length);
        assertEquals(1, res[0].getId()); // tie on name -> lower id first
        assertEquals(3, res[1].getId());
    }


    // ------------------------------------------------------------ duplicates

    @Test
    public void phoneDuplicateIgnoresFormattingAndCountryCode() {
        ContactRecord cand = rec(0, "Different Name", "03001234567", "");
        List<DuplicateMatch> m = DuplicateDetector.detect(index, cand, -1);
        assertEquals(1, m.size());
        assertEquals(DuplicateMatch.Reason.PHONE, m.get(0).getReason());
        assertEquals(1, m.get(0).getExisting().getId());
        assertTrue(m.get(0).isStrong());
    }

    @Test
    public void emailDuplicateIsCaseInsensitive() {
        ContactRecord cand = rec(0, "X", "0399 000 0000", "AHMED@example.COM");
        List<DuplicateMatch> m = DuplicateDetector.detect(index, cand, -1);
        assertEquals(1, m.size());
        assertEquals(DuplicateMatch.Reason.EMAIL, m.get(0).getReason());
    }

    @Test
    public void nameMatchIsOnlyASoftWarning() {
        ContactRecord cand = rec(0, "  fatima   ALI ", "0399 000 0000", "");
        List<DuplicateMatch> m = DuplicateDetector.detect(index, cand, -1);
        assertEquals(1, m.size());
        assertEquals(DuplicateMatch.Reason.NAME, m.get(0).getReason());
        assertFalse(m.get(0).isStrong());
        assertFalse(DuplicateDetector.hasStrongMatch(m));
    }

    @Test
    public void sameNameTwiceReportsBothExistingPeople() {
        ContactRecord cand = rec(0, "Ahmed Khan", "0399 000 0000", "");
        assertEquals(2, DuplicateDetector.detect(index, cand, -1).size());
    }

    @Test
    public void editingExcludesItself() {
        ContactRecord self = index.get(1);
        List<DuplicateMatch> own = DuplicateDetector.detect(index, self, 1);
        assertFalse("must not match itself or flag anything strong", DuplicateDetector.hasStrongMatch(own));
        for (DuplicateMatch dm : own) assertNotEquals(1L, dm.getExisting().getId());
        // fatima has a unique name/phone: editing her must report nothing at all
        assertTrue(DuplicateDetector.detect(index, index.get(2), 2).isEmpty());
        // but it still collides with someone else's phone
        ContactRecord clash = self.withDetails("Ahmed Khan", "0301 7654321", "", "", "", "", 5);
        List<DuplicateMatch> m = DuplicateDetector.detect(index, clash, 1);
        assertTrue(DuplicateDetector.hasStrongMatch(m));
        assertEquals(2, m.get(0).getExisting().getId());
    }

    @Test
    public void noDuplicateForUniqueContact() {
        ContactRecord cand = rec(0, "Totally New", "0344 555 6666", "new@new.com");
        assertTrue(DuplicateDetector.detect(index, cand, -1).isEmpty());
    }
}
