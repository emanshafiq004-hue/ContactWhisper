package com.contactwhisper.app;

import static org.junit.Assert.*;

import com.contactwhisper.app.dsa.ContactHashTable;

import org.junit.Test;

public class ContactHashTableTest {

    @Test
    public void putGetRemove() {
        ContactHashTable t = new ContactHashTable();
        assertTrue(t.put("3001234567", 1));
        assertArrayEquals(new long[]{1}, t.get("3001234567"));
        assertTrue(t.containsKey("3001234567"));
        assertTrue(t.remove("3001234567", 1));
        assertFalse(t.containsKey("3001234567"));
        assertEquals(0, t.size());
    }

    @Test
    public void sameKeyHoldsMultipleIdsForNonUniqueNames() {
        ContactHashTable t = new ContactHashTable();
        assertTrue(t.put("john smith", 1));
        assertTrue(t.put("john smith", 2));
        assertFalse(t.put("john smith", 2)); // same pair twice is a no-op
        long[] ids = t.get("john smith");
        assertEquals(2, ids.length);
        assertEquals(1, t.size()); // one KEY, two ids
        assertTrue(t.remove("john smith", 1));
        assertArrayEquals(new long[]{2}, t.get("john smith"));
    }

    @Test
    public void collisionsAreChainedAndAllKeysStayReachable() {
        ContactHashTable t = new ContactHashTable(2);
        // Resize keeps load <= 0.75, but many keys in a 2-bucket start still collide on the way.
        for (int i = 0; i < 200; i++) t.put("key" + i, i);
        assertEquals(200, t.size());
        for (int i = 0; i < 200; i++) assertArrayEquals("key" + i, new long[]{i}, t.get("key" + i));
        assertTrue("table must have grown", t.bucketCount() >= 256);
    }

    @Test
    public void chainingHappensWhenKeysShareABucket() {
        // "Aa" and "BB" are a classic String.hashCode collision pair.
        assertEquals("Aa".hashCode(), "BB".hashCode());
        ContactHashTable t = new ContactHashTable(16);
        t.put("Aa", 1);
        t.put("BB", 2);
        assertEquals(2, t.longestChain());
        assertArrayEquals(new long[]{1}, t.get("Aa"));
        assertArrayEquals(new long[]{2}, t.get("BB"));
        assertTrue(t.remove("Aa", 1));
        assertArrayEquals(new long[]{2}, t.get("BB")); // removing one chain member keeps the other
    }

    @Test
    public void missingAndEmptyKeys() {
        ContactHashTable t = new ContactHashTable();
        assertEquals(0, t.get("nothing").length);
        assertFalse(t.put("", 1));
        assertFalse(t.put(null, 1));
        assertFalse(t.remove("nothing", 1));
        assertFalse(t.remove(null, 1));
    }

    @Test
    public void clearEmptiesTable() {
        ContactHashTable t = new ContactHashTable();
        t.put("a", 1);
        t.clear();
        assertEquals(0, t.size());
        assertFalse(t.containsKey("a"));
    }
}
