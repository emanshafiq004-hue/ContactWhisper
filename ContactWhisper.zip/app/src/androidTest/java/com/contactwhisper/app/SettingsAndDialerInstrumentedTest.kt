package com.contactwhisper.app

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.contactwhisper.app.data.AppTheme
import com.contactwhisper.app.data.LockMethod
import com.contactwhisper.app.data.SettingsStore
import com.contactwhisper.app.util.buildDialIntent
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SettingsAndDialerInstrumentedTest {
    private val context: Context = ApplicationProvider.getApplicationContext()

    @Test
    fun themeAndProfilePersist() = runBlocking {
        val store = SettingsStore(context)
        store.saveProfile("  Alex Carter ", "alex@example.com", "Hello")
        store.setTheme(AppTheme.EMERALD)
        val s = SettingsStore(context).settings.first() // a second instance reads the same DataStore file
        assertEquals("Alex Carter", s.name)
        assertEquals("alex@example.com", s.email)
        assertEquals(AppTheme.EMERALD, s.theme)
        assertTrue(s.profileDone)
        store.setTheme(AppTheme.CRIMSON)
        assertEquals(AppTheme.CRIMSON, store.settings.first().theme)
    }

    @Test
    fun pinIsHashedAndVerified() = runBlocking {
        val store = SettingsStore(context)
        store.setPin("2468")
        assertTrue(store.settings.first().hasPin)
        assertTrue(store.verifyPin("2468"))
        assertFalse(store.verifyPin("1111"))
        store.setLockMethod(LockMethod.PIN)
        store.clearPin()
        val after = store.settings.first()
        assertFalse(after.hasPin)
        assertEquals(LockMethod.BIOMETRIC, after.lockMethod) // PIN method can't survive without a PIN
        assertFalse(store.verifyPin("2468"))
    }

    @Test
    fun dialIntentIsActionDialWithTheNumberPrefilled() {
        val intent = buildDialIntent("+92 (300) 123-4567")!!
        assertEquals(Intent.ACTION_DIAL, intent.action) // ACTION_DIAL: the user confirms in the dialer, no CALL_PHONE
        assertEquals("tel", intent.data!!.scheme)
        assertEquals("+923001234567", intent.data!!.schemeSpecificPart)
    }

    @Test
    fun emptyNumberProducesNoIntent() {
        assertNull(buildDialIntent("   "))
        assertNull(buildDialIntent("abc"))
    }
}
