package com.contactwhisper.app

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.doubleClick
import androidx.compose.ui.test.click
import androidx.compose.ui.test.down
import androidx.compose.ui.test.moveBy
import androidx.compose.ui.test.up
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.contactwhisper.app.data.AppTheme
import com.contactwhisper.app.dsa.ContactRecord
import com.contactwhisper.app.ui.components.ContactCard
import com.contactwhisper.app.ui.theme.ContactWhisperTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Exercises the contact-card gesture arbitration (tap / double tap / horizontal swipe / hold-then-pull-to-call / scrolling-style drags that must NOT fire anything / the visible call button).
 */
@RunWith(AndroidJUnit4::class)
class ContactCardGestureTest {
    @get:Rule
    val rule = createComposeRule()

    private val contact = ContactRecord(1L, "Ahmed Khan", "+92 300 1234567", "", "", "", "", false, 1L, 1L)

    private class Counts {
        var open = 0; var edit = 0; var call = 0; var delete = 0; var fav = 0
    }

    private fun show(c: Counts) {
        rule.setContent {
            ContactWhisperTheme(AppTheme.CRIMSON) {
                ContactCard(
                    contact = contact,
                    onOpen = { c.open++ },
                    onEdit = { c.edit++ },
                    onCall = { c.call++ },
                    onDelete = { c.delete++ },
                    onToggleFavorite = { c.fav++ },
                    modifier = Modifier.testTag("card"),
                )
            }
        }
    }

    private val card get() = rule.onNodeWithTag("card")

    @Test
    fun singleTapOpensDetailsOnly() {
        val c = Counts(); show(c)
        card.performTouchInput { click(Offset(width * 0.4f, height / 2f)) }
        rule.waitUntil(2_000) { c.open == 1 }
        rule.mainClock.advanceTimeBy(1_000)
        assertEquals(0, c.delete)
    }

    @Test
    fun doubleTapMovesToBinWithoutOpening() {
        val c = Counts(); show(c)
        card.performTouchInput { doubleClick(Offset(width * 0.4f, height / 2f)) }
        rule.waitUntil(3_000) { c.delete == 1 }
        assertEquals(0, c.open)
    }

    @Test
    fun horizontalSwipeOpensEdit() {
        val c = Counts(); show(c)
        card.performTouchInput {
            down(Offset(width * 0.35f, height / 2f))
            moveBy(Offset(width * 0.35f, 0f), delayMillis = 200)
            up()
        }
        rule.waitUntil(2_000) { c.edit == 1 }
        assertEquals(0, c.call)
    }

    @Test
    fun holdThenPullBeyondThresholdCallsExactlyOnce() {
        val c = Counts(); show(c)
        card.performTouchInput {
            down(Offset(width * 0.5f, 12f))
            advanceEventTime(400) // hold > 250 ms: pull-ready
            moveBy(Offset(0f, 120.dp.toPx()), delayMillis = 200)
            up()
        }
        rule.waitUntil(2_000) { c.call == 1 }
        rule.mainClock.advanceTimeBy(1_500)
        assertEquals(1, c.call)
        assertEquals(0, c.open); assertEquals(0, c.edit); assertEquals(0, c.delete)
    }

    @Test
    fun holdThenShortPullDoesNotCall() {
        val c = Counts(); show(c)
        card.performTouchInput {
            down(Offset(width * 0.5f, 12f))
            advanceEventTime(400)
            moveBy(Offset(0f, 40.dp.toPx()), delayMillis = 200)
            up()
        }
        rule.mainClock.advanceTimeBy(1_000)
        assertEquals(0, c.call); assertEquals(0, c.open); assertEquals(0, c.edit); assertEquals(0, c.delete)
    }

    @Test
    fun holdWithoutMovingDoesNothing() {
        val c = Counts(); show(c)
        card.performTouchInput {
            down(Offset(width * 0.5f, 12f))
            advanceEventTime(500)
            up()
        }
        rule.mainClock.advanceTimeBy(1_000)
        assertEquals(0, c.call); assertEquals(0, c.open); assertEquals(0, c.delete)
    }

    @Test
    fun quickDownwardDragWithoutHoldNeverCalls() {
        val c = Counts(); show(c)
        card.performTouchInput {
            down(Offset(width * 0.5f, 12f))
            moveBy(Offset(0f, 150.dp.toPx()), delayMillis = 100) // scroll-style drag, hold never completes
            up()
        }
        rule.mainClock.advanceTimeBy(1_000)
        assertEquals(0, c.call); assertEquals(0, c.edit); assertEquals(0, c.delete)
    }

    @Test
    fun holdThenUpwardOrSidewaysDoesNotCallOrEdit() {
        val c = Counts(); show(c)
        card.performTouchInput {
            down(Offset(width * 0.5f, height / 2f))
            advanceEventTime(400)
            moveBy(Offset(0f, -60.dp.toPx()), delayMillis = 150)
            up()
        }
        card.performTouchInput {
            down(Offset(width * 0.3f, height / 2f))
            advanceEventTime(400)
            moveBy(Offset(width * 0.4f, 0f), delayMillis = 150)
            up()
        }
        rule.mainClock.advanceTimeBy(1_000)
        assertEquals(0, c.call); assertEquals(0, c.edit); assertEquals(0, c.delete)
    }

    @Test
    fun visibleCallAndStarButtonsWork() {
        val c = Counts(); show(c)
        rule.onNodeWithContentDescription("Call").performClick()
        rule.onNodeWithContentDescription("Add to favorites").performClick()
        assertEquals(1, c.call)
        assertEquals(1, c.fav)
        assertEquals(0, c.open)
    }
}
