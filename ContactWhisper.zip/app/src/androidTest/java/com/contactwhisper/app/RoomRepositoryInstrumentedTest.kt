package com.contactwhisper.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.contactwhisper.app.data.AppDatabase
import com.contactwhisper.app.data.CategoryResult
import com.contactwhisper.app.data.ContactDraft
import com.contactwhisper.app.data.ContactEntity
import com.contactwhisper.app.data.ContactRepository
import com.contactwhisper.app.data.RestoreResult
import com.contactwhisper.app.dsa.SortMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Runs the real repository against a real Room/SQLite database on the device or emulator:
 * persistence across "restarts", Bin retention/expiry, restore conflicts, search and Undo/Redo (including permanent deletion).
 */
@RunWith(AndroidJUnit4::class)
class RoomRepositoryInstrumentedTest {
    private val context: Context = ApplicationProvider.getApplicationContext()
    private val dbName = "cw-test.db"
    private var db: AppDatabase? = null
    private lateinit var repo: ContactRepository

    private fun open(): ContactRepository {
        db?.close()
        val fresh = Room.databaseBuilder(context, AppDatabase::class.java, dbName).build()
        db = fresh
        return ContactRepository(fresh).also { repo = it }
    }

    @Before
    fun setUp() = runBlocking {
        context.deleteDatabase(dbName)
        open()
        repo.ensureDefaultCategories()
        repo.load()
    }

    @After
    fun tearDown() {
        db?.close()
        context.deleteDatabase(dbName)
    }

    private fun draft(name: String, phone: String, email: String = "", category: String = "") =
        ContactDraft(name, phone, email, "", "", category)

    @Test
    fun contactsSurviveReopeningTheDatabase() = runBlocking {
        val added = repo.addContact(draft("Ahmed Khan", "+92 300 1234567", "a@x.com", "Friends"))
        repo.setFavorite(added.id, true)
        open().load() // simulates an app restart: new database handle, new in-memory DSA index
        val loaded = repo.getActive(added.id)
        assertNotNull(loaded)
        assertEquals("Ahmed Khan", loaded!!.name)
        assertTrue(loaded.isFavorite)
        assertEquals("Friends", loaded.category)
    }

    @Test
    fun universalSearchFindsByNamePhoneEmailAndCategory() = runBlocking {
        repo.addContact(draft("Visible Vera", "03111111111", "vera@x.com", "Work"))
        repo.addContact(draft("Hank Hill", "03222222222"))
        assertEquals(listOf("Hank Hill"), repo.search("hank", SortMode.A_Z).map { it.name })
        assertEquals(listOf("Visible Vera"), repo.search("vera@x", SortMode.A_Z).map { it.name })
        assertEquals(listOf("Visible Vera"), repo.search("work", SortMode.A_Z).map { it.name })
        assertEquals(2, repo.search("", SortMode.A_Z).size)
    }

    @Test
    fun restoreFromBinCanBeUndoneAndRedone() = runBlocking {
        val a = repo.addContact(draft("Ahmed", "03001234567"))
        repo.moveToBin(a.id)
        assertTrue(repo.restore(a.id) is RestoreResult.Restored)
        repo.undo() // undo the RESTORE: back in the Bin
        assertNull(repo.getActive(a.id))
        assertEquals(1, repo.binItems.first().size)
        repo.redo() // redo the restore
        assertNotNull(repo.getActive(a.id))
    }

    @Test
    fun permanentlyDeletedContactIsNeverResurrectedByUndoOrRedo() = runBlocking {
        val a = repo.addContact(draft("Ahmed", "03001234567"))
        repo.updateContact(a.id, draft("Ahmed K", "03001234567"))
        repo.moveToBin(a.id)
        assertEquals(1, repo.permanentlyDelete(listOf(a.id)))
        repeat(5) { repo.undo() }
        repeat(5) { repo.redo() }
        assertNull(repo.getActive(a.id))
        assertTrue(repo.binItems.first().isEmpty())
        assertTrue(repo.search("", SortMode.A_Z).isEmpty())
    }

    @Test
    fun deleteGoesToBinAndRestoreChecksConflicts() = runBlocking {
        val a = repo.addContact(draft("Ahmed", "+92 300 1234567"))
        repo.moveToBin(a.id)
        assertEquals(1, repo.binItems.first().size)
        repo.addContact(draft("Ahmed Two", "+92-300-1234567")) // same digits as the binned contact
        val result = repo.restore(a.id)
        // Same normalised phone => conflict; the entry must stay in the Bin.
        assertTrue(result is RestoreResult.Conflict)
        assertEquals(1, repo.binItems.first().size)
    }

    @Test
    fun binExpiryRemovesOnlyEntriesOlderThanThirtyDays() = runBlocking {
        val dao = db!!.contactDao()
        val day = 24L * 60 * 60 * 1000
        val now = System.currentTimeMillis()
        dao.insert(ContactEntity(name = "Old", phone = "1", createdAt = 1, updatedAt = 1, deletedAt = now - 31 * day))
        dao.insert(ContactEntity(name = "Recent", phone = "2", createdAt = 1, updatedAt = 1, deletedAt = now - 29 * day))
        val active = repo.addContact(draft("Active", "3"))
        assertEquals(1, repo.purgeExpired(now))
        assertEquals(listOf("Recent"), repo.binItems.first().map { it.name })
        assertNotNull(repo.getActive(active.id))
    }

    @Test
    fun undoRedoRoundTripAgainstRealDatabase() = runBlocking {
        val a = repo.addContact(draft("Fatima", "301"))
        repo.updateContact(a.id, draft("Fatima Ali", "301", category = "Family"))
        repo.moveToBin(a.id)
        assertNull(repo.getActive(a.id))

        assertTrue(repo.undo().performed) // delete
        assertEquals("Fatima Ali", repo.getActive(a.id)!!.name)
        assertTrue(repo.undo().performed) // edit
        assertEquals("Fatima", repo.getActive(a.id)!!.name)
        assertTrue(repo.undo().performed) // add
        assertNull(repo.getActive(a.id))
        assertNull(db!!.contactDao().getById(a.id))

        assertTrue(repo.redo().performed)
        assertEquals("Fatima", repo.getActive(a.id)!!.name)
        // a brand-new action clears Redo
        repo.addContact(draft("Other", "999"))
        assertFalse(repo.history.first().canRedo)
    }

    @Test
    fun deletingACustomCategoryMovesContactsToOther() = runBlocking {
        assertTrue(repo.addCategory("Gym") is CategoryResult.Ok)
        val gym = repo.categories.first().first { it.name == "Gym" }
        val c = repo.addContact(draft("Coach", "777", category = "Gym"))
        assertTrue(repo.deleteCategory(gym.id) is CategoryResult.Ok)
        assertEquals("Other", repo.getActive(c.id)!!.category)
    }
}
