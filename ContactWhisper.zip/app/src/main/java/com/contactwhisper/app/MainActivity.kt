package com.contactwhisper.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import com.contactwhisper.app.auth.AuthController
import com.contactwhisper.app.ui.CWRoot

/**
 * Single activity. It extends FragmentActivity (not just ComponentActivity) because AndroidX BiometricPrompt
 * needs a FragmentActivity host. Configuration changes are handled in the manifest, so rotating the phone
 * never recreates the activity; the ViewModel and navigation state survive process-level recreation too.
 */
class MainActivity : FragmentActivity() {

    private val viewModel: AppViewModel by viewModels()
    private lateinit var auth: AuthController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        auth = AuthController(this)
        setContent { CWRoot(viewModel, auth, lifecycle) }
    }

    override fun onStart() {
        super.onStart()
        viewModel.onForeground()
    }

    override fun onStop() {
        super.onStop()
        viewModel.voice.onStop() // never keep listening or speaking in the background
        // A biometric / device-credential prompt can cover this activity; that is not "leaving the app".
        if (!isChangingConfigurations) viewModel.onBackground(authInProgress = auth.isAuthenticating)
    }
}
