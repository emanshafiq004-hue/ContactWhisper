package com.contactwhisper.app.auth

import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.contactwhisper.app.data.AppSettings
import com.contactwhisper.app.data.LockMethod

/**
 * Real authentication (never simulated): AndroidX BiometricPrompt with device-credential fallback, or the
 * locally configured app PIN (verified against its salted PBKDF2 hash in [com.contactwhisper.app.data.SettingsStore]).
 *
 * Used by the optional App Lock. App Lock settings are touch-only: the voice assistant has no access to this class.
 */
class AuthController(private val activity: FragmentActivity) {

    class PinPrompt(val title: String, val onResult: (Boolean) -> Unit)

    /** Latest settings, kept in sync by the Activity. */
    @Volatile
    var settings: AppSettings = AppSettings()

    /** When non-null the UI shows the PIN entry dialog. */
    var pinPrompt by mutableStateOf<PinPrompt?>(null)
        private set

    private var biometricBusy = false

    /** True while a biometric/credential prompt or the PIN dialog is on screen (used to avoid re-locking mid-auth). */
    val isAuthenticating: Boolean get() = biometricBusy || pinPrompt != null

    private val authenticators =
        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    /** True when the device has biometrics enrolled or a screen lock (PIN/pattern/password) configured. */
    fun systemAuthAvailable(): Boolean =
        BiometricManager.from(activity).canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS

    /**
     * Asks the user to authenticate using the configured method. [onResult] is called on the main thread
     * with true only after a genuine success.
     */
    fun authenticate(title: String, onResult: (Boolean) -> Unit) {
        val s = settings
        when {
            s.lockMethod == LockMethod.PIN && s.hasPin -> pinPrompt = PinPrompt(title, onResult)
            systemAuthAvailable() -> showBiometric(title, onResult)
            s.hasPin -> pinPrompt = PinPrompt(title, onResult)
            else -> {
                Toast.makeText(
                    activity,
                    "No fingerprint or screen lock is set up. Add one in Android settings, or create an App PIN in Settings > App Lock.",
                    Toast.LENGTH_LONG,
                ).show()
                onResult(false)
            }
        }
    }

    /**
     * Authenticates with fingerprint / face / the device screen lock only (never the app PIN). Used as the
     * recovery path on the lock screen when the app PIN has been forgotten.
     */
    fun authenticateWithSystem(title: String, onResult: (Boolean) -> Unit) {
        if (systemAuthAvailable()) showBiometric(title, onResult) else onResult(false)
    }

    fun finishPin(success: Boolean) {
        val prompt = pinPrompt
        pinPrompt = null
        prompt?.onResult?.invoke(success)
    }

    private fun showBiometric(title: String, onResult: (Boolean) -> Unit) {
        if (biometricBusy) return
        biometricBusy = true
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                biometricBusy = false
                onResult(true)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                biometricBusy = false
                onResult(false)
            }
            // onAuthenticationFailed (one bad fingerprint attempt): the prompt stays open, nothing to do.
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("ContactWhisper")
            .setAllowedAuthenticators(authenticators) // with DEVICE_CREDENTIAL no negative button may be set
            .build()
        BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), callback).authenticate(info)
    }
}

val LocalAuth = staticCompositionLocalOf<AuthController> { error("AuthController not provided") }
