package com.contactwhisper.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [ContactEntity::class, CategoryEntity::class, EmergencyEntity::class],
    version = 2,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun categoryDao(): CategoryDao
    abstract fun emergencyDao(): EmergencyDao

    companion object {
        const val NAME = "contactwhisper.db"

        /**
         * v1 -> v2
         *  - contacts: the Hidden-contacts feature was removed, so the `isHidden` column is dropped. SQLite on
         *    API 26 cannot DROP COLUMN, so the table is rebuilt. EVERY row is copied (formerly hidden contacts
         *    simply become ordinary contacts) and the AUTOINCREMENT counter is carried over so ids of deleted
         *    contacts are never reused.
         *  - emergency_services: gains a nullable `deletedAt` so entries can live in the Recycle Bin.
         */
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                for (sql in MIGRATION_1_2_SQL) db.execSQL(sql)
            }
        }

        /** Kept as plain SQL strings so the same statements can be replayed in a JVM test against a v1 database. */
        val MIGRATION_1_2_SQL: List<String> = listOf(
            "ALTER TABLE `contacts` RENAME TO `contacts_v1`",
            "CREATE TABLE IF NOT EXISTS `contacts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`name` TEXT NOT NULL, `phone` TEXT NOT NULL, `email` TEXT NOT NULL, `address` TEXT NOT NULL, " +
                "`notes` TEXT NOT NULL, `category` TEXT NOT NULL, `isFavorite` INTEGER NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `deletedAt` INTEGER)",
            "INSERT INTO `contacts` (`id`, `name`, `phone`, `email`, `address`, `notes`, `category`, `isFavorite`, " +
                "`createdAt`, `updatedAt`, `deletedAt`) SELECT `id`, `name`, `phone`, `email`, `address`, `notes`, " +
                "`category`, `isFavorite`, `createdAt`, `updatedAt`, `deletedAt` FROM `contacts_v1`",
            "DELETE FROM `sqlite_sequence` WHERE `name` = 'contacts'",
            "INSERT INTO `sqlite_sequence` (`name`, `seq`) SELECT 'contacts', MAX(" +
                "COALESCE((SELECT `seq` FROM `sqlite_sequence` WHERE `name` = 'contacts_v1'), 0), " +
                "COALESCE((SELECT MAX(`id`) FROM `contacts`), 0))",
            "DROP TABLE `contacts_v1`",
            "CREATE INDEX IF NOT EXISTS `index_contacts_deletedAt` ON `contacts` (`deletedAt`)",
            "ALTER TABLE `emergency_services` ADD COLUMN `deletedAt` INTEGER",
        )

        /** No destructive-migration fallback: user contacts must never be wiped silently. */
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, NAME)
                .addMigrations(MIGRATION_1_2)
                .build()
    }
}
