package com.contactwhisper.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.contactwhisper.app.R
import com.contactwhisper.app.SnackEvent
import com.contactwhisper.app.ui.theme.CW
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlin.math.abs
import kotlin.math.roundToInt

/** How long a notification stays up. */
const val SNACKBAR_MS = 2000L

private fun iconFor(message: String): Int = when {
    message.contains("Bin", ignoreCase = true) && message.contains("moved", ignoreCase = true) -> R.drawable.ic_delete
    message.startsWith("Action undone") -> R.drawable.ic_undo
    message.startsWith("Action redone") -> R.drawable.ic_redo
    message.contains("deleted permanently", ignoreCase = true) -> R.drawable.ic_delete
    message.startsWith("Changes saved") || message.contains("restored", ignoreCase = true) ||
        message.contains("added", ignoreCase = true) -> R.drawable.ic_check
    else -> R.drawable.ic_info
}

/**
 * The app's only transient notification. A rounded charcoal card with a supplied icon and the theme accent.
 *
 *  - dismisses itself after [SNACKBAR_MS] (2 s); a newer message replaces it and restarts the timer
 *  - can be swiped away sideways
 *  - occupies only the card's own area: no full-width layer, so it can never block touches elsewhere, and when
 *    nothing is showing nothing is composed at all (no invisible touch targets)
 */
@Composable
fun CWSnackbarHost(events: Flow<SnackEvent>, modifier: Modifier = Modifier) {
    val c = CW.colors
    var current by remember { mutableStateOf<SnackEvent?>(null) }
    var serial by remember { mutableIntStateOf(0) }
    var dragX by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(events) {
        events.collect {
            dragX = 0f
            current = it
            serial++
        }
    }
    // The timer is keyed on the serial number, so it restarts for every new message and is cancelled when replaced.
    LaunchedEffect(serial) {
        if (serial > 0) {
            delay(SNACKBAR_MS)
            current = null
        }
    }

    val shape = RoundedCornerShape(14.dp)
    Box(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), contentAlignment = Alignment.BottomCenter) {
        AnimatedVisibility(
            visible = current != null,
            enter = fadeIn(tween(120)) + slideInVertically(tween(160)) { it / 2 },
            exit = fadeOut(tween(120)) + slideOutVertically(tween(120)) { it / 2 },
        ) {
            val e = current
            if (e != null) {
                Row(
                    Modifier
                        .offset { IntOffset(dragX.roundToInt(), 0) }
                        .graphicsLayer { alpha = (1f - abs(dragX) / 600f).coerceIn(0.2f, 1f) }
                        .clip(shape)
                        .background(c.surface)
                        .border(1.dp, c.accent, shape)
                        .draggable(
                            orientation = Orientation.Horizontal,
                            state = rememberDraggableState { dragX += it },
                            onDragStopped = { velocity ->
                                if (abs(dragX) > 90f || abs(velocity) > 1200f) current = null else dragX = 0f
                            },
                        )
                        .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CWIcon(iconFor(e.message), null, size = 24.dp, tint = c.ivory)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        e.message,
                        color = c.ivory,
                        fontSize = 14.sp,
                        modifier = Modifier.weight(1f, fill = false).padding(vertical = 8.dp),
                    )
                    if (e.actionLabel != null) {
                        Text(
                            e.actionLabel,
                            color = c.ring,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    current = null
                                    e.onAction?.invoke()
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                        )
                    } else {
                        Spacer(Modifier.width(10.dp))
                    }
                }
            }
        }
    }
}
