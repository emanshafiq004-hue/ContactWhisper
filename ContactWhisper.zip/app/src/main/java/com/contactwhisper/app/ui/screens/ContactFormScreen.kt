package com.contactwhisper.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.data.ContactDraft
import com.contactwhisper.app.domain.ContactValidator
import com.contactwhisper.app.dsa.DuplicateMatch
import com.contactwhisper.app.ui.components.CWButton
import com.contactwhisper.app.ui.components.CWTextField
import com.contactwhisper.app.ui.components.ConfirmDialog
import com.contactwhisper.app.ui.components.DropdownField
import com.contactwhisper.app.ui.components.EmptyState
import com.contactwhisper.app.ui.components.ScreenHeader
import kotlinx.coroutines.launch

private const val NO_CATEGORY = "None"

/**
 * Add ([editId] < 0) or Edit a contact. Name and phone are compulsory; everything else is optional.
 * Saving an edit updates the same record (same id). Possible duplicates are explained and never merged or deleted.
 */
@Composable
fun ContactFormScreen(vm: AppViewModel, editId: Long, onBack: () -> Unit) {
    val isEdit = editId >= 0
    val existing = remember(editId) { if (isEdit) vm.findVisible(editId) else null }
    val categories by vm.categories.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    if (isEdit && existing == null) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("Edit Contact", onBack)
            EmptyState("Contact not found", "It may have been deleted.")
        }
        return
    }

    // An untouched stored (e.g. imported) number stays acceptable until the user edits it.
    val originalPhone = existing?.phone
    var name by rememberSaveable(editId) { mutableStateOf(existing?.name ?: "") }
    var phone by rememberSaveable(editId) { mutableStateOf(existing?.phone ?: "") }
    var email by rememberSaveable(editId) { mutableStateOf(existing?.email ?: "") }
    var address by rememberSaveable(editId) { mutableStateOf(existing?.address ?: "") }
    var notes by rememberSaveable(editId) { mutableStateOf(existing?.notes ?: "") }
    var category by rememberSaveable(editId) { mutableStateOf(existing?.category ?: "") }
    var submitted by rememberSaveable(editId) { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var pendingDraft by remember { mutableStateOf<ContactDraft?>(null) }
    var duplicates by remember { mutableStateOf<List<DuplicateMatch>>(emptyList()) }

    // Field-level errors appear after the first Save attempt and then update as the user types.
    val result = if (submitted) ContactValidator.validate(name, phone, email, address, notes, originalPhone) else null

    fun commit(draft: ContactDraft) {
        vm.saveContact(editId, draft) { onBack() }
    }

    fun trySave() {
        submitted = true
        if (!ContactValidator.validate(name, phone, email, address, notes, originalPhone).isValid) return
        val draft = ContactDraft(
            name = name.trim(), phone = ContactValidator.phoneForSave(phone.trim()), email = email.trim(), address = address.trim(),
            notes = notes.trim(), category = category,
        )
        saving = true
        scope.launch {
            val matches = vm.findDuplicates(draft, editId)
            saving = false
            if (matches.isEmpty()) {
                commit(draft)
            } else {
                pendingDraft = draft
                duplicates = matches
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(if (isEdit) "Edit Contact" else "Add Contact", onBack)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            CWTextField(name, { name = it }, "Name *", error = result?.nameError)
            CWTextField(phone, { phone = it }, "Phone *", error = result?.phoneError, keyboardType = KeyboardType.Phone, placeholder = "03XX XXXXXXX")
            CWTextField(email, { email = it }, "Email (optional)", error = result?.emailError, keyboardType = KeyboardType.Email)
            CWTextField(address, { address = it }, "Address (optional)", error = result?.addressError, singleLine = false)
            CWTextField(notes, { notes = it }, "Notes (optional)", error = result?.notesError, singleLine = false, minLines = 3)

            val names = listOf(NO_CATEGORY) + categories.map { it.name }
            DropdownField(
                label = "Category (optional)",
                valueText = category.ifBlank { NO_CATEGORY },
                options = names,
                optionLabel = { it },
                onSelect = { category = if (it == NO_CATEGORY) "" else it },
            )


            Spacer(Modifier.height(6.dp))
            CWButton(
                text = if (saving) "Checking…" else "Save",
                onClick = ::trySave,
                enabled = !saving,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
        }
    }

    val draft = pendingDraft
    if (draft != null) {
        val strong = duplicates.any { it.isStrong }
        ConfirmDialog(
            title = if (strong) "Possible duplicate contact" else "Similar contact found",
            text = duplicates.joinToString("\n") { "• " + describe(it) } +
                "\n\nNothing will be merged or deleted. Save this contact anyway?",
            confirmLabel = "Save anyway",
            dismissLabel = "Cancel",
            onConfirm = {
                pendingDraft = null
                commit(draft)
            },
            onDismiss = { pendingDraft = null },
        )
    }
}

private fun describe(match: DuplicateMatch): String {
    val other = match.existing
    return when (match.reason) {
        DuplicateMatch.Reason.PHONE -> "Same phone number as ${other.name} (${other.phone})"
        DuplicateMatch.Reason.EMAIL -> "Same email address as ${other.name}"
        DuplicateMatch.Reason.NAME -> "A contact named ${other.name} already exists (${other.phone})"
    }
}
