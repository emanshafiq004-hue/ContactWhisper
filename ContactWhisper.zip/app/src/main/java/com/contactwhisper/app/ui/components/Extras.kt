package com.contactwhisper.app.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.contactwhisper.app.R
import com.contactwhisper.app.ui.theme.CW
import com.contactwhisper.app.ui.theme.GlowCrimson
import com.contactwhisper.app.ui.theme.GlowEmerald
import java.text.DateFormat
import java.util.Date

/**
 * Very soft crimson glow (top-left) AND emerald glow (bottom-right) at the same time, confined to the corners.
 * Used ONLY on the splash screen and the first-launch profile setup. The radius is half the screen width and the
 * peak alpha about 0.13, so the charcoal base stays clearly dominant (the earlier version was ~0.34 over 0.8 of the
 * screen diagonal).
 */
fun Modifier.cornerGlows(): Modifier = drawBehind {
    val radius = size.width * 0.5f
    drawRect(
        Brush.radialGradient(
            colors = listOf(GlowCrimson.copy(alpha = 0.14f), Color.Transparent),
            center = Offset(0f, 0f),
            radius = radius,
        ),
    )
    drawRect(
        Brush.radialGradient(
            colors = listOf(GlowEmerald.copy(alpha = 0.12f), Color.Transparent),
            center = Offset(size.width, size.height),
            radius = radius,
        ),
    )
}

/**
 * Working screens: only a faint ambient accent in the ACTIVE theme colour at two opposite corners
 * (crimson in Crimson, emerald in Emerald). Never a background gradient, never behind cards' own colour.
 */
fun Modifier.edgeAccent(color: Color): Modifier = drawBehind {
    val radius = size.width * 0.45f
    drawRect(
        Brush.radialGradient(
            colors = listOf(color.copy(alpha = 0.10f), Color.Transparent),
            center = Offset(0f, 0f),
            radius = radius,
        ),
    )
    drawRect(
        Brush.radialGradient(
            colors = listOf(color.copy(alpha = 0.08f), Color.Transparent),
            center = Offset(size.width, size.height),
            radius = radius,
        ),
    )
}

fun formatDate(millis: Long): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(millis))

/** Pick-one field in the same recessed input style as every text field; the supplied arrow sits at the far right. */
@Composable
fun <T> DropdownField(
    label: String,
    valueText: String,
    options: List<T>,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = CW.colors
    var expanded by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        FieldLabel(label)
        Box(Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .clip(shape)
                    .background(c.inputWell)
                    .border(1.dp, c.accent.copy(alpha = 0.7f), shape)
                    .bevelIn(10.dp)
                    .clickable { expanded = true }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    valueText,
                    color = c.ivory,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                CWIcon(R.drawable.ic_expand_more, "Open $label options", size = 20.dp)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(optionLabel(option), color = c.ivory) },
                        onClick = {
                            expanded = false
                            onSelect(option)
                        },
                    )
                }
            }
        }
    }
}

/**
 * A whole-card switch: pressing anywhere on the card raises it slightly (bevel-out, same theme) and toggles.
 * The Switch itself is display-only so there is one touch target and one consistent press state.
 */
@Composable
fun SwitchCard(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
) {
    val c = CW.colors
    PanelCard(modifier = modifier, onClick = { onCheckedChange(!checked) }) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = c.ivory, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                if (subtitle != null) Text(subtitle, color = c.muted, fontSize = 13.sp)
            }
            Spacer(Modifier.width(12.dp))
            Switch(
                checked = checked,
                onCheckedChange = null,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = c.ivory,
                    checkedTrackColor = c.ring,
                    checkedBorderColor = c.ring,
                    uncheckedThumbColor = c.muted,
                    uncheckedTrackColor = c.field,
                    uncheckedBorderColor = c.accent.copy(alpha = 0.6f),
                ),
            )
        }
    }
}

/** A tappable row on the Settings screen. The trailing arrow is the supplied "go to" chevron. */
@Composable
fun SettingsRow(
    @DrawableRes icon: Int,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = CW.colors
    PanelCard(modifier = modifier, onClick = onClick) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CWIcon(icon, null, size = 28.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = c.ivory, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text(subtitle, color = c.muted, fontSize = 12.sp)
            }
            CWIcon(R.drawable.ic_chevron_right, null, size = 16.dp)
        }
    }
}

/** Title + body card used on the About screen. */
@Composable
fun InfoSection(title: String, body: String, modifier: Modifier = Modifier) {
    val c = CW.colors
    PanelCard(modifier = modifier) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(title, color = c.ivory, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(body, color = c.ivory.copy(alpha = 0.82f), fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
fun SmallIconTile(@DrawableRes icon: Int, modifier: Modifier = Modifier, size: Dp = 40.dp) {
    val c = CW.colors
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(c.surface.copy(alpha = 0.55f))
            .border(1.dp, c.ivory.copy(alpha = 0.25f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center,
    ) {
        CWIcon(icon, null, size = size * 0.6f)
    }
}

/** Title text filled with the crimson-to-emerald brand gradient (splash and About). */
@Composable
fun GradientText(
    text: String,
    fontSize: androidx.compose.ui.unit.TextUnit,
    modifier: Modifier = Modifier,
    fontWeight: androidx.compose.ui.text.font.FontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
) {
    androidx.compose.material3.Text(
        text = text,
        modifier = modifier,
        style = androidx.compose.ui.text.TextStyle(
            brush = com.contactwhisper.app.ui.theme.BrandGradient,
            fontSize = fontSize,
            fontWeight = fontWeight,
            letterSpacing = 0.4.sp,
            fontFamily = com.contactwhisper.app.ui.theme.LocalRoboto.current,
        ),
    )
}

/** Circular two-colour badge used for the camera button (crimson + emerald), never stretches its icon. */
@Composable
fun CameraBadge(modifier: Modifier = Modifier, size: Dp = 34.dp) {
    Box(
        modifier = modifier
            .size(size)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(
                Brush.linearGradient(
                    listOf(
                        com.contactwhisper.app.ui.theme.SetupCrimson,
                        com.contactwhisper.app.ui.theme.SetupEmerald,
                    ),
                ),
            )
            .border(1.dp, CW.colors.ivory.copy(alpha = 0.35f), androidx.compose.foundation.shape.CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        CWIcon(R.drawable.ic_camera, "Change photo", size = size * 0.56f)
    }
}
