package com.contactwhisper.app.data

/**
 * The ONE place that defines the initial Emergency Services list.
 *
 * DEVELOPMENT NOTE: these four entries mirror the sample values in the supplied design reference
 * (Police 100, Ambulance 102, Fire Brigade 112, Rescue 1122). They are placeholders, NOT verified
 * official numbers. Verify every number for the user's country/region before any public release.
 * Users can edit, delete and add entries on the Emergency Services screen at any time.
 */
object EmergencySeed {
    val entries: List<EmergencyEntity> = listOf(
        EmergencyEntity(name = "Police", number = "100", sortOrder = 0),
        EmergencyEntity(name = "Ambulance", number = "102", sortOrder = 1),
        EmergencyEntity(name = "Fire Brigade", number = "112", sortOrder = 2),
        EmergencyEntity(name = "Rescue", number = "1122", sortOrder = 3),
    )

    /** Category names created on first run. These can't be renamed or deleted. */
    val defaultCategories: List<String> = listOf("Family", "Friends", "Work", "Other")

    const val FALLBACK_CATEGORY = "Other"
}
