package com.contactwhisper.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts WHERE deletedAt IS NULL")
    suspend fun getActive(): List<ContactEntity>

    @Query("SELECT * FROM contacts WHERE deletedAt IS NOT NULL ORDER BY deletedAt DESC")
    fun observeBin(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE id = :id")
    suspend fun getById(id: Long): ContactEntity?

    @Query("SELECT * FROM contacts WHERE deletedAt IS NOT NULL")
    suspend fun getBin(): List<ContactEntity>

    /** Inserting an entity with a non-zero id keeps that id (used by Undo/Redo of add). */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ContactEntity): Long

    @Update
    suspend fun update(entity: ContactEntity)

    @Query("UPDATE contacts SET deletedAt = :deletedAt WHERE id = :id")
    suspend fun softDelete(id: Long, deletedAt: Long)

    @Query("UPDATE contacts SET deletedAt = NULL WHERE id = :id")
    suspend fun clearDeleted(id: Long)

    @Query("DELETE FROM contacts WHERE id = :id")
    suspend fun hardDelete(id: Long): Int

    @Query("DELETE FROM contacts WHERE id IN (:ids) AND deletedAt IS NOT NULL")
    suspend fun hardDeleteBinItems(ids: List<Long>): Int

    /** Ids of the Bin entries that are due for automatic purge (so their history can be invalidated first). */
    @Query("SELECT id FROM contacts WHERE deletedAt IS NOT NULL AND deletedAt < :cutoff")
    suspend fun expiredIds(cutoff: Long): List<Long>

    @Query("SELECT id FROM contacts WHERE deletedAt IS NOT NULL AND id IN (:ids)")
    suspend fun binIdsAmong(ids: List<Long>): List<Long>

    /** Permanently removes Bin entries deleted before [cutoff] (epoch millis). */
    @Query("DELETE FROM contacts WHERE deletedAt IS NOT NULL AND deletedAt < :cutoff")
    suspend fun purgeBefore(cutoff: Long): Int

    @Query("UPDATE contacts SET category = :newName WHERE category = :oldName")
    suspend fun renameCategory(oldName: String, newName: String)

    @Query("SELECT COUNT(*) FROM contacts WHERE deletedAt IS NOT NULL")
    suspend fun binCount(): Int
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY isDefault DESC, id ASC")
    fun observeAll(): Flow<List<CategoryEntity>>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun count(): Int

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getById(id: Long): CategoryEntity?

    @Query("SELECT * FROM categories WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun findByName(name: String): CategoryEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: CategoryEntity): Long

    @Query("UPDATE categories SET name = :newName WHERE id = :id")
    suspend fun rename(id: Long, newName: String)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface EmergencyDao {
    @Query("SELECT * FROM emergency_services WHERE deletedAt IS NULL ORDER BY sortOrder ASC, id ASC")
    fun observeAll(): Flow<List<EmergencyEntity>>

    @Query("SELECT * FROM emergency_services WHERE deletedAt IS NOT NULL ORDER BY deletedAt DESC")
    fun observeBin(): Flow<List<EmergencyEntity>>

    /** Counts every row (active or binned) so a seeded list is never re-created after the user deleted it. */
    @Query("SELECT COUNT(*) FROM emergency_services")
    suspend fun count(): Int

    @Query("SELECT COALESCE(MAX(sortOrder), -1) FROM emergency_services")
    suspend fun maxOrder(): Int

    @Query("SELECT * FROM emergency_services WHERE id = :id")
    suspend fun getById(id: Long): EmergencyEntity?

    @Insert
    suspend fun insert(entity: EmergencyEntity): Long

    @Update
    suspend fun update(entity: EmergencyEntity)

    @Query("UPDATE emergency_services SET deletedAt = :deletedAt WHERE id = :id AND deletedAt IS NULL")
    suspend fun softDelete(id: Long, deletedAt: Long): Int

    @Query("UPDATE emergency_services SET deletedAt = NULL WHERE id = :id AND deletedAt IS NOT NULL")
    suspend fun clearDeleted(id: Long): Int

    @Query("DELETE FROM emergency_services WHERE id IN (:ids) AND deletedAt IS NOT NULL")
    suspend fun hardDeleteBinItems(ids: List<Long>): Int

    @Query("DELETE FROM emergency_services WHERE deletedAt IS NOT NULL AND deletedAt < :cutoff")
    suspend fun purgeBefore(cutoff: Long): Int
}
