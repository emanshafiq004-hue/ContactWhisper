package com.contactwhisper.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.auth.LocalAuth
import com.contactwhisper.app.data.AppTheme
import com.contactwhisper.app.data.LockMethod
import com.contactwhisper.app.domain.ContactValidator
import com.contactwhisper.app.ui.Routes
import com.contactwhisper.app.ui.components.CWButton
import com.contactwhisper.app.ui.components.CWIcon
import com.contactwhisper.app.ui.components.CWTextButton
import com.contactwhisper.app.ui.components.CWTextField
import com.contactwhisper.app.ui.components.ConfirmDialog
import com.contactwhisper.app.ui.components.InitialAvatar
import com.contactwhisper.app.ui.components.PanelCard
import com.contactwhisper.app.ui.components.PinSetupDialog
import com.contactwhisper.app.ui.components.ProfileAvatar
import com.contactwhisper.app.ui.components.ScreenHeader
import com.contactwhisper.app.ui.components.SectionLabel
import com.contactwhisper.app.ui.components.SettingsRow
import com.contactwhisper.app.ui.components.SwitchCard
import com.contactwhisper.app.ui.components.removePinTextColor
import com.contactwhisper.app.ui.theme.CW
import com.contactwhisper.app.ui.theme.paletteFor

// ====================================================================== Settings (exactly four entries, in this order)

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = "Settings", onBack = onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SettingsRow(R.drawable.ic_person, "Profile Customization", "Manage your profile", { onOpen(Routes.PROFILE) })
            SettingsRow(R.drawable.ic_palette, "Appearance", "Theme & display settings", { onOpen(Routes.APPEARANCE) })
            SettingsRow(R.drawable.ic_lock, "App Lock", "Security settings", { onOpen(Routes.APP_LOCK) })
            SettingsRow(R.drawable.ic_info, "About", "App information", { onOpen(Routes.ABOUT) })
        }
    }
}

// ====================================================================== Profile customization

@Composable
fun ProfileScreen(vm: AppViewModel, onBack: () -> Unit) {
    val c = CW.colors
    val settings by vm.settings.collectAsStateWithLifecycle()
    var name by rememberSaveable { mutableStateOf(settings.name) }
    var email by rememberSaveable { mutableStateOf(settings.email) }
    var about by rememberSaveable { mutableStateOf(settings.about) }
    var submitted by rememberSaveable { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.pickProfilePhoto(uri)
    }
    val nameError = if (submitted && name.isBlank()) "Display name is required" else null
    val emailError = if (submitted) ContactValidator.validateEmail(email) else null

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = "Profile Customization", onBack = onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                Modifier
                    .size(112.dp)
                    .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                contentAlignment = Alignment.BottomEnd,
            ) {
                // solid outline in the active theme colour (crimson / emerald)
                ProfileAvatar(settings.photoPath, settings.photoVersion, name, 108.dp, Modifier.align(Alignment.Center), ringWidth = 3.dp)
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(c.panel)
                        .border(1.5.dp, c.ring, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { CWIcon(R.drawable.ic_camera, "Change profile picture", size = 20.dp) }
            }
            Spacer(Modifier.height(4.dp))
            CWTextField(name, { name = it.take(40) }, "Display name *", error = nameError, chipLabel = true)
            CWTextField(email, { email = it }, "Email (optional)", error = emailError, keyboardType = KeyboardType.Email, chipLabel = true)
            CWTextField(about, { about = it.take(160) }, "About you (optional)", singleLine = false, minLines = 2, chipLabel = true)
            SettingsRow(R.drawable.ic_person, "Import phone contacts", "Add contacts stored on this phone", { vm.requestImport() })
            CWButton(
                text = "Save Changes",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    submitted = true
                    if (name.isNotBlank() && ContactValidator.validateEmail(email) == null) {
                        vm.saveProfile(name, email, about) {
                            vm.snack("Changes saved.")
                            onBack()
                        }
                    }
                },
            )
        }
    }
}

// ====================================================================== Appearance

@Composable
fun AppearanceScreen(vm: AppViewModel, onBack: () -> Unit) {
    val c = CW.colors
    val settings by vm.settings.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = "Appearance", onBack = onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column {
                Text("Choose a theme", color = c.ivory, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("It is applied to every screen.", color = c.muted, fontSize = 13.sp)
            }
            // Tapping a card applies that theme straight away (stored in DataStore; navigation and data are untouched).
            ThemeCard(AppTheme.CRIMSON, "Crimson", settings.theme == AppTheme.CRIMSON) { vm.setTheme(AppTheme.CRIMSON) }
            ThemeCard(AppTheme.EMERALD, "Emerald", settings.theme == AppTheme.EMERALD) { vm.setTheme(AppTheme.EMERALD) }
        }
    }
}

/**
 * A realistic miniature of the real interface drawn with THAT theme's own palette (not the active one): header, smoky
 * search field with the supplied Search and Mic icons, two solid contact cards with the supplied Call and Favorite
 * icons, and the four-tab navigation bar with the supplied icons.
 */
@Composable
private fun ThemeCard(theme: AppTheme, title: String, selected: Boolean, onSelect: () -> Unit) {
    val p = paletteFor(theme)
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(p.background)
            .border(if (selected) 2.5.dp else 1.dp, if (selected) p.ring else p.accent.copy(alpha = 0.5f), shape)
            .clickable(onClick = onSelect)
            .padding(top = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = p.ivory, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (selected) {
                Box(Modifier.size(26.dp).clip(CircleShape).background(p.ring), contentAlignment = Alignment.Center) {
                    CWIcon(R.drawable.ic_check, "Selected", tint = p.ivory, size = 16.dp)
                }
            }
        }
        // search field
        Row(
            Modifier
                .padding(horizontal = 14.dp)
                .fillMaxWidth()
                .height(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(p.field)
                .border(1.dp, p.accent.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CWIcon(R.drawable.ic_search, null, size = 20.dp)
            Spacer(Modifier.width(8.dp))
            Text("Search contacts", color = p.ivory.copy(alpha = 0.6f), fontSize = 13.sp, modifier = Modifier.weight(1f))
            CWIcon(R.drawable.ic_mic, null, size = 20.dp)
        }
        // two solid contact cards
        listOf("Ahmed Khan" to "0300 1234567", "Sara Ali" to "0321 7654321").forEachIndexed { i, (name, phone) ->
            Row(
                Modifier
                    .padding(horizontal = 14.dp)
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.panel)
                    .border(1.dp, p.accent.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                InitialAvatar(name, 34.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = p.ivory, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(phone, color = p.ivory.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                CWIcon(R.drawable.ic_phone_3d, null, size = 22.dp)
                Spacer(Modifier.width(12.dp))
                CWIcon(if (i == 0) R.drawable.ic_star else R.drawable.ic_star_outline, null, size = 22.dp)
            }
        }
        // bottom navigation
        Row(
            Modifier
                .fillMaxWidth()
                .background(p.surface)
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            listOf(
                R.drawable.ic_home to "Home",
                R.drawable.ic_category to "Categories",
                R.drawable.ic_star to "Favorites",
                R.drawable.ic_delete to "Bin",
            ).forEachIndexed { i, (icon, label) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CWIcon(icon, null, size = 22.dp, tint = p.ivory.copy(alpha = if (i == 0) 1f else 0.6f))
                    Text(label, color = if (i == 0) p.ivory else p.muted, fontSize = 10.sp)
                }
            }
        }
    }
}

// ====================================================================== App Lock

@Composable
fun AppLockScreen(vm: AppViewModel, onBack: () -> Unit) {
    val c = CW.colors
    val auth = LocalAuth.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val systemOk = auth.systemAuthAvailable()
    var showPinSetup by remember { mutableStateOf(false) }
    var switchToPinAfterSave by remember { mutableStateOf(false) }
    var confirmRemovePin by remember { mutableStateOf(false) }

    /** Changes to an already-protected setup first ask for the current credential. */
    fun guarded(title: String, action: () -> Unit) {
        if (settings.appLockEnabled || settings.hasPin) {
            auth.authenticate(title) { ok -> if (ok) action() else vm.snack("No changes made") }
        } else {
            action()
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = "App Lock", onBack = onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SwitchCard(
                title = "Enable App Lock",
                subtitle = "Anyone who unlocks the app can see your contacts.",
                checked = settings.appLockEnabled,
                onCheckedChange = { wantOn ->
                    if (wantOn) {
                        if (!systemOk && !settings.hasPin) {
                            vm.snack("Create an App PIN below first, or set a screen lock in Android settings.")
                        } else {
                            auth.authenticate("Turn on App Lock") { ok ->
                                if (ok) vm.setAppLockEnabled(true) else vm.snack("App Lock was not turned on")
                            }
                        }
                    } else {
                        auth.authenticate("Turn off App Lock") { ok ->
                            if (ok) vm.setAppLockEnabled(false) else vm.snack("App Lock stays on")
                        }
                    }
                },
            )

            SectionLabel("UNLOCK METHOD")
            PanelCard {
                Column(Modifier.fillMaxWidth().padding(8.dp)) {
                    MethodRow(
                        selected = settings.lockMethod == LockMethod.BIOMETRIC,
                        title = "Fingerprint / device screen lock",
                        subtitle = if (systemOk) "Uses your phone's biometrics or its PIN / pattern / password." else "Not available: this phone has no fingerprint or screen lock set up.",
                        enabled = systemOk,
                        onSelect = { guarded("Change unlock method") { vm.setLockMethod(LockMethod.BIOMETRIC) } },
                    )
                    MethodRow(
                        selected = settings.lockMethod == LockMethod.PIN && settings.hasPin,
                        title = "App PIN",
                        subtitle = if (settings.hasPin) "A 4–12 digit PIN only this app knows." else "Create a PIN first (below).",
                        enabled = true,
                        onSelect = {
                            if (settings.hasPin) {
                                guarded("Change unlock method") { vm.setLockMethod(LockMethod.PIN) }
                            } else {
                                switchToPinAfterSave = true
                                showPinSetup = true
                            }
                        },
                    )
                }
            }

            SectionLabel("APP PIN")
            CWButton(
                text = if (settings.hasPin) "Change App PIN" else "Set App PIN",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    guarded("Change App PIN") {
                        switchToPinAfterSave = false
                        showPinSetup = true
                    }
                },
            )
            if (settings.hasPin) {
                CWButton(
                    text = "Remove App PIN",
                    modifier = Modifier.fillMaxWidth(),
                    textColor = removePinTextColor(),
                    onClick = {
                        if (settings.appLockEnabled && !systemOk) {
                            vm.snack("Can't remove the PIN: it is the only way to unlock. Turn App Lock off first.")
                        } else {
                            guarded("Remove App PIN") { confirmRemovePin = true }
                        }
                    },
                )
            }
            SectionLabel("WHEN IT LOCKS")
            Text(
                "• When the app is opened from a closed state.\n" +
                    "• When you return after 30 seconds or more away from the app.",
                color = c.muted,
                fontSize = 13.sp,
                lineHeight = 19.sp,
            )
        }
    }

    if (showPinSetup) {
        PinSetupDialog(
            onSave = { pin ->
                showPinSetup = false
                vm.setPin(pin) {
                    if (switchToPinAfterSave) vm.setLockMethod(LockMethod.PIN)
                    switchToPinAfterSave = false
                    vm.snack("App PIN saved")
                }
            },
            onCancel = {
                showPinSetup = false
                switchToPinAfterSave = false
            },
        )
    }
    if (confirmRemovePin) {
        ConfirmDialog(
            title = "Remove App PIN?",
            text = "The unlock method switches back to fingerprint / device screen lock.",
            confirmLabel = "Remove",
            danger = true,
            onConfirm = {
                confirmRemovePin = false
                vm.clearPin()
            },
            onDismiss = { confirmRemovePin = false },
        )
    }
}

@Composable
private fun MethodRow(selected: Boolean, title: String, subtitle: String, enabled: Boolean, onSelect: () -> Unit) {
    val c = CW.colors
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(enabled = enabled, onClick = onSelect)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(
            selected = selected,
            onClick = if (enabled) onSelect else null,
            enabled = enabled,
            colors = RadioButtonDefaults.colors(
                selectedColor = c.ivory,
                unselectedColor = c.muted,
                disabledSelectedColor = c.muted,
                disabledUnselectedColor = c.muted.copy(alpha = 0.5f),
            ),
        )
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = if (enabled) c.ivory else c.muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = c.muted, fontSize = 12.sp)
        }
    }
}
