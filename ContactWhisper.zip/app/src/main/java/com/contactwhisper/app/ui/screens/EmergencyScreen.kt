package com.contactwhisper.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.data.EmergencyEntity
import com.contactwhisper.app.domain.ContactValidator
import com.contactwhisper.app.ui.components.CWIconButton
import com.contactwhisper.app.ui.components.CWTextButton
import com.contactwhisper.app.ui.components.CWTextField
import com.contactwhisper.app.ui.components.CardAction
import com.contactwhisper.app.ui.components.GestureCard
import com.contactwhisper.app.ui.components.LocalCaller
import com.contactwhisper.app.ui.components.EmptyState
import com.contactwhisper.app.ui.components.PhoneIcon
import com.contactwhisper.app.ui.components.ScreenHeader
import com.contactwhisper.app.ui.components.SmallIconTile
import com.contactwhisper.app.ui.theme.CW

private sealed interface EmergencyDialog {
    data object Add : EmergencyDialog
    data class Details(val entry: EmergencyEntity) : EmergencyDialog
    data class Edit(val entry: EmergencyEntity) : EmergencyDialog
}

/**
 * Emergency Services: a vertical list of solid cards with the same gestures as contacts:
 * tap = details, horizontal swipe = edit, double tap = move to the Bin (restorable, returns here), drag down from the
 * leading icon and release = call. There are deliberately no Edit/Delete icons on the cards.
 * Emergency numbers always open the system dialer (Android restricts direct emergency calling by apps).
 */
@Composable
fun EmergencyScreen(vm: AppViewModel, onBack: () -> Unit) {
    val c = CW.colors
    val caller = LocalCaller.current
    val entries by vm.emergencyEntries.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<EmergencyDialog?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Emergency Services",
            onBack = onBack,
            actions = { CWIconButton(R.drawable.ic_add, "Add emergency entry", { dialog = EmergencyDialog.Add }) },
        )
        if (entries.isEmpty()) {
            EmptyState(
                "No emergency entries",
                "Tap + to add one, for example Police or Ambulance.",
                icon = R.drawable.ic_emergency,
                modifier = Modifier.weight(1f),
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(entries, key = { it.id }) { entry ->
                    val call = { caller.call(entry.number, true) }
                    GestureCard(
                        seed = entry.id.toInt() + 7919,
                        onOpen = { dialog = EmergencyDialog.Details(entry) },
                        onEdit = { dialog = EmergencyDialog.Edit(entry) },
                        onCall = call,
                        onDelete = { vm.deleteEmergency(entry) },
                        actions = listOf(
                            CardAction("Call ${entry.name}", call),
                            CardAction("Edit ${entry.name}", { dialog = EmergencyDialog.Edit(entry) }),
                            CardAction("Move ${entry.name} to Bin", { vm.deleteEmergency(entry) }),
                        ),
                        modifier = Modifier.animateItem(),
                        rightExclusion = 64.dp,
                        leading = { SmallIconTile(R.drawable.ic_emergency, size = 44.dp) },
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                entry.name,
                                color = c.ivory,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(entry.number, color = c.ivory.copy(alpha = 0.7f), fontSize = 14.sp)
                        }
                        IconButton(onClick = call) { PhoneIcon(size = 26.dp) }
                    }
                }
            }
        }
    }

    when (val d = dialog) {
        null -> Unit
        EmergencyDialog.Add -> EntryDialog(
            title = "Add emergency service",
            initialName = "",
            initialNumber = "",
            onSave = { name, number ->
                vm.addEmergency(name, number)
                dialog = null
            },
            onDismiss = { dialog = null },
        )
        is EmergencyDialog.Edit -> EntryDialog(
            title = "Edit emergency service",
            initialName = d.entry.name,
            initialNumber = d.entry.number,
            onSave = { name, number ->
                vm.updateEmergency(d.entry, name, number)
                dialog = null
            },
            onDismiss = { dialog = null },
        )
        is EmergencyDialog.Details -> AlertDialog(
            onDismissRequest = { dialog = null },
            containerColor = c.surface,
            titleContentColor = c.ivory,
            textContentColor = c.muted,
            title = { Text(d.entry.name) },
            text = { Text(d.entry.number, color = c.ivory, fontSize = 20.sp) },
            confirmButton = { CWTextButton("Call", { caller.call(d.entry.number, true); dialog = null }) },
            dismissButton = {
                Row {
                    CWTextButton("Edit", { dialog = EmergencyDialog.Edit(d.entry) })
                    CWTextButton("Close", { dialog = null })
                }
            },
        )
    }
}

@Composable
private fun EntryDialog(
    title: String,
    initialName: String,
    initialNumber: String,
    onSave: (String, String) -> Unit,
    onDismiss: () -> Unit,
) {
    val c = CW.colors
    var name by remember { mutableStateOf(initialName) }
    var number by remember { mutableStateOf(initialNumber) }
    var submitted by remember { mutableStateOf(false) }
    val nameError = if (submitted && name.isBlank()) "Name is required" else null
    val numberError = if (submitted) ContactValidator.validateEmergencyNumber(number) else null

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        titleContentColor = c.ivory,
        textContentColor = c.muted,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CWTextField(name, { name = it.take(40) }, "Service name", error = nameError)
                CWTextField(number, { number = it }, "Number", error = numberError, keyboardType = KeyboardType.Phone)
            }
        },
        confirmButton = {
            CWTextButton("Save", {
                submitted = true
                if (name.isNotBlank() && ContactValidator.validateEmergencyNumber(number) == null) onSave(name, number)
            })
        },
        dismissButton = { CWTextButton("Cancel", onDismiss) },
    )
}
