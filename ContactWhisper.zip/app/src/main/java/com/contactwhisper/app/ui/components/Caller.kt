package com.contactwhisper.app.ui.components

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.util.dialNumber
import com.contactwhisper.app.util.hasCallPermission
import com.contactwhisper.app.util.placeCallDirect

/**
 * THE call entry point for every call button and for drag-to-call.
 *
 *  - Emergency Services numbers always open the dialer (Android restricts direct emergency calling by apps).
 *  - Personal contacts: if CALL_PHONE is granted the call is placed directly (ACTION_CALL); otherwise the dialer is
 *    opened with the number filled in (ACTION_DIAL).
 *  - The CALL_PHONE permission is requested ONCE, on the first call attempt. If the user refuses, the dialer is used
 *    from then on and the app never nags. Direct calling is not permission-free.
 */
@Stable
class Caller(val call: (number: String, emergency: Boolean) -> Unit)

val LocalCaller = compositionLocalOf<Caller> { Caller { _, _ -> } }

@Composable
fun rememberCaller(vm: AppViewModel): Caller {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val askedState = rememberUpdatedState(settings.callPermAsked)
    var askedHere by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val number = pending
        pending = null
        if (number != null) {
            if (granted) placeCallDirect(context, number) else dialNumber(context, number)
        }
    }
    return remember(context) {
        Caller { number, emergency ->
            when {
                emergency -> dialNumber(context, number)
                hasCallPermission(context) -> placeCallDirect(context, number)
                !askedState.value && !askedHere -> {
                    askedHere = true
                    vm.markCallPermissionAsked()
                    pending = number
                    launcher.launch(Manifest.permission.CALL_PHONE)
                }
                else -> dialNumber(context, number)
            }
        }
    }
}
