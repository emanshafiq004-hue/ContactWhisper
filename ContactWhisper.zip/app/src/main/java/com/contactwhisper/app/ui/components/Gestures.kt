package com.contactwhisper.app.ui.components

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Stable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.contactwhisper.app.dsa.ContactRecord
import kotlin.math.abs

/** What a contact row can do. One instance is shared by Home, Favorites and Categories so they behave identically. */
@Stable
class ContactActions(
    val open: (ContactRecord) -> Unit,
    val edit: (ContactRecord) -> Unit,
    val call: (ContactRecord) -> Unit,
    val delete: (ContactRecord) -> Unit,
    val toggleFavorite: (ContactRecord) -> Unit,
)

/**
 * App-wide two-finger horizontal swipe:
 *   left -> right = Undo, right -> left = Redo.
 *
 * It watches the Initial pointer pass and NEVER consumes anything, so scrolling, text fields and the
 * per-card gestures keep working. It only reacts when two fingers are down together and their centre moves
 * mostly horizontally by at least 72dp; one trigger per touch sequence.
 * (Contact cards cancel their own gesture the moment a second finger lands, see ContactCard.)
 */
fun Modifier.twoFingerUndoRedo(onUndo: () -> Unit, onRedo: () -> Unit): Modifier =
    pointerInput(onUndo, onRedo) {
        val threshold = 72.dp.toPx()
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var startX = Float.NaN
            var startY = Float.NaN
            var fired = false
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val pressed = event.changes.filter { it.pressed }
                if (pressed.size >= 2) {
                    var cx = 0f
                    var cy = 0f
                    for (p in pressed) {
                        cx += p.position.x
                        cy += p.position.y
                    }
                    cx /= pressed.size
                    cy /= pressed.size
                    if (startX.isNaN()) {
                        startX = cx
                        startY = cy
                    } else if (!fired) {
                        val dx = cx - startX
                        val dy = cy - startY
                        if (abs(dx) > threshold && abs(dx) > abs(dy) * 1.5f) {
                            fired = true
                            if (dx > 0f) onUndo() else onRedo()
                        }
                    }
                } else {
                    startX = Float.NaN
                    startY = Float.NaN
                }
            } while (event.changes.any { it.pressed })
        }
    }

/**
 * Voice-assistant gesture for the Home search bar: ONE finger swiping left -> right across the bar.
 *
 *  - Watches the Initial pass and never consumes anything, so tapping, placing the cursor, typing, selecting and the mic
 *    button keep working exactly as before.
 *  - Fires once per touch sequence when the finger has moved at least [MIN_SWIPE_DP] to the right, mostly horizontally
 *    (vertical drift under half the horizontal distance), within [MAX_SWIPE_MS]. The time limit also rules out the
 *    long-press-then-drag that selects text. A second finger cancels it.
 */
fun Modifier.searchBarSwipeToVoice(enabled: Boolean = true, onTrigger: () -> Unit): Modifier =
    pointerInput(enabled, onTrigger) {
        if (!enabled) return@pointerInput
        val minDx = MIN_SWIPE_DP.dp.toPx()
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val start = down.position
            val t0 = down.uptimeMillis
            var fired = false
            var dead = false
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                if (event.changes.count { it.pressed } > 1) dead = true
                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                if (!dead && !fired) {
                    val dx = change.position.x - start.x
                    val dy = abs(change.position.y - start.y)
                    if (change.uptimeMillis - t0 > MAX_SWIPE_MS) dead = true
                    else if (dx < -minDx / 3f || dy > maxOf(dx, minDx / 2f)) dead = true // wrong direction / too vertical
                    else if (dx >= minDx && dy <= dx * 0.5f) {
                        fired = true
                        onTrigger()
                    }
                }
            } while (event.changes.any { it.pressed })
        }
    }

private const val MIN_SWIPE_DP = 96
private const val MAX_SWIPE_MS = 700L
