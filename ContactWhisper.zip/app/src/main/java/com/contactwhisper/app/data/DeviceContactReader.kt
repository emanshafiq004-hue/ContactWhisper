package com.contactwhisper.app.data

import android.content.Context
import android.provider.ContactsContract

/**
 * Reads the phone's own contacts (Android Contacts Provider) so they can be imported into ContactWhisper's LOCAL
 * Room database. Nothing leaves the device. Requires READ_CONTACTS; callers must check the permission first.
 *
 * Entries the user labelled ICE / Emergency in the phonebook are ordinary contact rows here and are imported like
 * any other contact. (Android's separate emergency-information / SOS settings are not exposed through this
 * interface, so they are not read.)
 *
 * Must be called from a background dispatcher: it runs two content-provider queries.
 */
object DeviceContactReader {

    fun read(context: Context): List<ImportedContact> {
        val resolver = context.contentResolver
        val names = LinkedHashMap<Long, String>()
        val phones = HashMap<Long, MutableList<String>>()
        val emails = HashMap<Long, MutableList<String>>()

        resolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY),
            null, null,
            ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " COLLATE NOCASE ASC",
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
            val nameCol = c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
            while (c.moveToNext()) names[c.getLong(idCol)] = c.getString(nameCol).orEmpty()
        }

        resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null,
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val numCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val n = c.getString(numCol).orEmpty().trim()
                if (n.isNotEmpty()) phones.getOrPut(c.getLong(idCol)) { mutableListOf() }.add(n)
            }
        }

        resolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Email.CONTACT_ID, ContactsContract.CommonDataKinds.Email.ADDRESS),
            null, null, null,
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.CONTACT_ID)
            val addrCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.ADDRESS)
            while (c.moveToNext()) {
                val a = c.getString(addrCol).orEmpty().trim()
                if (a.isNotEmpty()) emails.getOrPut(c.getLong(idCol)) { mutableListOf() }.add(a)
            }
        }

        return names.map { (id, name) ->
            ImportedContact(name, phones[id].orEmpty(), emails[id].orEmpty())
        }
    }
}
