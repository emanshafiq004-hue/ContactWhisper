package com.contactwhisper.app.voice

import com.contactwhisper.app.data.AppTheme
import com.contactwhisper.app.data.ContactDraft
import com.contactwhisper.app.dsa.ContactRecord
import com.contactwhisper.app.dsa.SortMode
import java.util.Locale

/** What the assistant can do with a found contact. */
enum class VoiceAction { VIEW, EDIT, DELETE, CALL, FAVORITE, UNFAVORITE }

/** The contact fields that can be changed by voice (same set as the visual Edit form). */
enum class EditField(val label: String) {
    NAME("name"),
    PHONE("phone number"),
    EMAIL("email"),
    ADDRESS("address"),
    NOTES("notes"),
    CATEGORY("category"),
}

enum class EmergencyField(val label: String) { NAME("name"), NUMBER("number") }

enum class YesNo { YES, NO }

/** Screens the assistant may open. There is deliberately NO App Lock entry here: security settings are touch-only. */
enum class VoiceScreen { HOME, CATEGORIES, FAVORITES, BIN, EMERGENCY, SETTINGS, PROFILE, APPEARANCE, ABOUT }

enum class BinScope { ALL, SELECTED }

/** What a top-level utterance means. */
sealed interface VoiceCommand {
    /** [action] == null means "look it up and ask me what to do". A blank [query] means "which contact?". */
    data class Find(val query: String, val action: VoiceAction?) : VoiceCommand
    data object AddContact : VoiceCommand
    data class Open(val screen: VoiceScreen) : VoiceCommand
    data object Back : VoiceCommand
    data object Close : VoiceCommand
    data object Cancel : VoiceCommand
    data object Undo : VoiceCommand
    data object Redo : VoiceCommand
    data class Sort(val mode: SortMode) : VoiceCommand
    /** [theme] == null: "change theme" without a colour, so the assistant asks which one. */
    data class Theme(val theme: AppTheme?) : VoiceCommand
    data class Favorite(val query: String, val add: Boolean) : VoiceCommand
    data class ExpandCategory(val name: String, val expand: Boolean) : VoiceCommand
    data class CreateCategory(val name: String) : VoiceCommand
    data class RenameCategory(val oldName: String, val newName: String) : VoiceCommand
    data class RemoveCategory(val name: String) : VoiceCommand
    data object BinSelectAll : VoiceCommand
    data object BinClearSelection : VoiceCommand
    data object BinRestoreAll : VoiceCommand
    data object BinRestoreSelected : VoiceCommand
    data class BinRestore(val query: String) : VoiceCommand
    /** Only ever built from an explicit "permanently" / "forever" / "empty the bin" phrase. */
    data class BinDeletePermanently(val scope: BinScope?, val query: String) : VoiceCommand
    /** "delete all" without the word permanently: never acted on, the assistant explains how to be explicit. */
    data object BinDeleteAmbiguous : VoiceCommand
    data object AddEmergency : VoiceCommand
    data class EditEmergency(val query: String) : VoiceCommand
    data class RemoveEmergency(val query: String) : VoiceCommand
    data class ProfileName(val name: String) : VoiceCommand
    /** Anything aimed at App Lock / PIN / biometrics / authentication: refused, never executed. */
    data object SecurityRefused : VoiceCommand
    data object Unknown : VoiceCommand
}

fun ContactDraft.withField(field: EditField, value: String): ContactDraft = when (field) {
    EditField.NAME -> copy(name = value)
    EditField.PHONE -> copy(phone = value)
    EditField.EMAIL -> copy(email = value)
    EditField.ADDRESS -> copy(address = value)
    EditField.NOTES -> copy(notes = value)
    EditField.CATEGORY -> copy(category = value)
}

fun ContactRecord.toDraft(): ContactDraft = ContactDraft(name, phone, email, address, notes, category)

fun ContactRecord.valueOf(field: EditField): String = when (field) {
    EditField.NAME -> name
    EditField.PHONE -> phone
    EditField.EMAIL -> email
    EditField.ADDRESS -> address
    EditField.NOTES -> notes
    EditField.CATEGORY -> category
}

/**
 * Deterministic command parser: no network, no model, no guessing. Everything is a keyword/pattern match on the
 * recognised text, so behaviour is predictable and unit-testable with plain strings.
 */
object VoiceCommandParser {

    private val CALL_WORDS = setOf("call", "dial", "phone", "ring")
    private val EDIT_WORDS = setOf("edit", "change", "update", "modify")
    private val DELETE_WORDS = setOf("delete", "remove", "erase", "bin", "trash")
    private val VIEW_WORDS = setOf("view", "views", "open", "details", "detail", "see", "display", "info", "information")
    private val SEARCH_WORDS = setOf("find", "search", "show", "look", "lookup", "locate", "get")
    private val DETAIL_WORDS = setOf("details", "detail", "info", "information")

    /** The recogniser sometimes hears "view" as one of these. Accepted ONLY as the whole answer to "what would you like to do?". */
    private val VIEW_HOMOPHONES = setOf("you", "few", "vu", "view's")

    private val LEADING_FILLERS = setOf("my", "the", "a", "an", "for", "me", "contact", "contacts", "up", "to", "person", "of")
    private val TRAILING_FILLERS = setOf("contact", "contacts", "please", "now", "list", "number")
    private val NAME_FILLERS = setOf(
        "the", "a", "an", "this", "that", "it", "him", "her", "contact", "contacts", "please", "now", "number", "one", "for", "of", "me", "my", "to",
    )

    private val CLOSE_PHRASES = setOf(
        "close", "close it", "close assistant", "close the assistant", "close voice assistant", "close the voice assistant",
        "exit", "quit", "stop listening", "goodbye", "good bye", "bye", "that's all", "thats all", "that is all",
        "i'm done", "im done", "i am done", "done", "dismiss", "turn off", "close voice",
    )
    private val CANCEL_PHRASES = setOf("cancel", "cancel that", "never mind", "nevermind", "forget it", "abort", "stop", "cancel it")
    private val BACK_PHRASES = setOf("back", "go back", "navigate back", "previous", "previous screen", "go to the previous screen", "go to previous screen")
    private val SKIP_WORDS = setOf("skip", "no", "none", "nope", "nothing", "pass", "no email", "skip it", "not now")

    private val YES_WORDS = setOf(
        "yes", "yeah", "yep", "yup", "confirm", "confirmed", "sure", "correct", "affirmative", "absolutely", "ok", "okay",
    )
    private val YES_PHRASES = setOf("go ahead", "do it", "that is right", "that's right")
    private val NO_WORDS = setOf("no", "nope", "nah", "cancel", "stop", "dont", "don't", "never", "negative", "not", "wait")
    private val CLEAR_WORDS = setOf("clear", "empty", "remove", "none", "nothing", "blank", "delete")

    private val SECURITY_WORDS = setOf(
        "lock", "locks", "locked", "unlock", "unlocked", "applock", "pin", "passcode", "password", "passwords",
        "fingerprint", "biometric", "biometrics", "authentication", "authenticate", "security",
    )
    private val SECURITY_VERBS = setOf(
        "enable", "disable", "turn", "set", "change", "remove", "reset", "switch", "activate", "deactivate", "open", "show", "go",
        "use", "add", "create", "update", "edit", "modify", "bypass", "skip", "unlock", "lock", "clear", "delete", "make", "toggle", "configure",
    )

    // ------------------------------------------------------------------ normalisation

    /** Lower-case, punctuation removed except apostrophes, hyphens and '+', single spaces. */
    fun normalize(text: String): String =
        text.lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N}\\s'+-]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun tokens(text: String): List<String> = normalize(text).split(' ').filter { it.isNotEmpty() }

    fun titleCase(text: String): String =
        text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            .joinToString(" ") { w -> w.replaceFirstChar { it.titlecase(Locale.ROOT) } }

    // ------------------------------------------------------------------ top-level command

    fun parseCommand(text: String): VoiceCommand {
        val t = tokens(text)
        if (t.isEmpty()) return VoiceCommand.Unknown
        val j = t.joinToString(" ")

        if (isSecurityRequest(t, j)) return VoiceCommand.SecurityRefused
        if (j in CLOSE_PHRASES) return VoiceCommand.Close
        if (j in CANCEL_PHRASES) return VoiceCommand.Cancel
        if (j in BACK_PHRASES) return VoiceCommand.Back
        if (j == "undo" || j == "undo that" || j == "undo last action") return VoiceCommand.Undo
        if (j == "redo" || j == "redo that" || j == "redo last action") return VoiceCommand.Redo

        parseBin(t, j)?.let { return it }
        parseEmergency(t)?.let { return it }
        parseCategory(t, text)?.let { return it }
        parseSort(t, j)?.let { return it }
        parseTheme(t)?.let { return it }
        parseProfile(t, text)?.let { return it }
        parseNavigation(t)?.let { return it }
        parseFavorite(t)?.let { return it }
        if (isAddIntent(t)) return VoiceCommand.AddContact
        return parseFind(t)
    }

    private fun isSecurityRequest(t: List<String>, j: String): Boolean {
        if (j.contains("app lock") || j.contains("applock")) return true
        if (t.none { it in SECURITY_WORDS }) return false
        return t[0] in SECURITY_VERBS || t[0] in SECURITY_WORDS
    }

    // ---- bin

    private val PERMANENT_WORDS = setOf("permanently", "permanent", "forever")
    private val BIN_FILLERS = setOf(
        "the", "my", "contact", "contacts", "from", "bin", "recycle", "trash", "entry", "entries", "please", "back", "items", "item", "in",
        "permanently", "permanent", "forever", "for", "good", "a", "of",
    )
    private val ALL_WORDS = setOf("all", "everything")
    private val SELECTED_WORDS = setOf("selected", "selection", "these", "them", "those", "checked")

    private fun parseBin(t: List<String>, j: String): VoiceCommand? {
        when (j) {
            "select all", "select everything", "select all entries", "select all items", "select all contacts", "select all in bin" ->
                return VoiceCommand.BinSelectAll
            "clear selection", "deselect all", "unselect all", "select none", "clear the selection" -> return VoiceCommand.BinClearSelection
            "empty bin", "empty the bin", "empty recycle bin", "empty the recycle bin", "empty trash", "empty the trash",
            "clear bin", "clear the bin", "clear the recycle bin", "clear recycle bin" ->
                return VoiceCommand.BinDeletePermanently(BinScope.ALL, "")
        }
        val first = t[0]
        val permanent = t.any { it in PERMANENT_WORDS } || j.contains("for good")
        if (first == "restore" || first == "recover" || first == "undelete") {
            val rest = t.drop(1).filter { it !in BIN_FILLERS }
            return when {
                rest.isEmpty() && t.drop(1).any { it in ALL_WORDS } -> VoiceCommand.BinRestoreAll
                rest.isNotEmpty() && rest.all { it in ALL_WORDS } -> VoiceCommand.BinRestoreAll
                rest.isNotEmpty() && rest.all { it in SELECTED_WORDS } -> VoiceCommand.BinRestoreSelected
                rest.isEmpty() -> VoiceCommand.BinRestore("")
                else -> VoiceCommand.BinRestore(rest.joinToString(" "))
            }
        }
        val deleteVerb = first in setOf("delete", "remove", "erase", "purge", "destroy", "permanently")
        if (permanent && (deleteVerb || t.any { it in setOf("delete", "remove", "erase", "purge", "destroy") })) {
            val rest = t.filter { it !in BIN_FILLERS && it !in setOf("delete", "remove", "erase", "purge", "destroy") }
            return when {
                rest.isEmpty() -> VoiceCommand.BinDeletePermanently(null, "")
                rest.all { it in ALL_WORDS } -> VoiceCommand.BinDeletePermanently(BinScope.ALL, "")
                rest.all { it in SELECTED_WORDS } -> VoiceCommand.BinDeletePermanently(BinScope.SELECTED, "")
                else -> VoiceCommand.BinDeletePermanently(null, rest.joinToString(" "))
            }
        }
        if (deleteVerb) {
            val rest = t.drop(1).filter { it !in BIN_FILLERS }
            if (rest.isNotEmpty() && rest.all { it in ALL_WORDS || it in SELECTED_WORDS }) return VoiceCommand.BinDeleteAmbiguous
        }
        return null
    }

    // ---- emergency services

    private val EMERGENCY_FILLERS = setOf("emergency", "emergencies", "service", "services", "number", "numbers", "entry", "entries", "the", "my", "for", "to", "a", "an", "of", "please")

    private fun parseEmergency(t: List<String>): VoiceCommand? {
        if (t.none { it == "emergency" || it == "emergencies" }) return null
        val first = t[0]
        val rest = t.filter { it !in EMERGENCY_FILLERS && it != first }.joinToString(" ")
        return when (first) {
            "add", "create", "new" -> VoiceCommand.AddEmergency
            "edit", "change", "update", "modify", "rename" -> VoiceCommand.EditEmergency(rest)
            "delete", "remove", "erase" -> VoiceCommand.RemoveEmergency(rest)
            else -> null
        }
    }

    // ---- categories

    private val CATEGORY_FILLERS = setOf(
        "category", "categories", "a", "an", "the", "new", "called", "named", "name", "to", "my", "please", "group", "folder", "of",
    )

    private fun parseCategory(t: List<String>, original: String): VoiceCommand? {
        val hasCategory = t.any { it == "category" || it == "categories" }
        val first = t[0]
        if (first == "expand" || first == "collapse") {
            val name = t.drop(1).filter { it !in CATEGORY_FILLERS }.joinToString(" ")
            return if (name.isEmpty()) null else VoiceCommand.ExpandCategory(name, first == "expand")
        }
        if (!hasCategory) return null
        when (first) {
            "add", "create", "new", "make" ->
                return VoiceCommand.CreateCategory(t.drop(1).filter { it !in CATEGORY_FILLERS }.joinToString(" "))
            "delete", "remove", "erase" ->
                return VoiceCommand.RemoveCategory(t.drop(1).filter { it !in CATEGORY_FILLERS }.joinToString(" "))
            "rename" -> {
                val toIdx = t.indexOf("to")
                if (toIdx < 0) return VoiceCommand.RenameCategory(t.drop(1).filter { it !in CATEGORY_FILLERS }.joinToString(" "), "")
                val old = t.subList(1, toIdx).filter { it !in CATEGORY_FILLERS }.joinToString(" ")
                val new = t.drop(toIdx + 1).filter { it !in CATEGORY_FILLERS }.joinToString(" ")
                return VoiceCommand.RenameCategory(old, new)
            }
            "open", "show", "go", "view", "see" -> {
                val name = t.drop(1).filter { it !in CATEGORY_FILLERS && it !in setOf("go", "tab", "screen", "page") }.joinToString(" ")
                return if (name.isEmpty()) null else VoiceCommand.ExpandCategory(name, true)
            }
            "close", "hide" -> {
                val name = t.drop(1).filter { it !in CATEGORY_FILLERS }.joinToString(" ")
                return if (name.isEmpty()) null else VoiceCommand.ExpandCategory(name, false)
            }
        }
        return null
    }

    // ---- sort

    private fun parseSort(t: List<String>, j: String): VoiceCommand? {
        val sortWord = t.any { it == "sort" || it == "sorted" || it == "order" || it == "arrange" }
        val exact = j in setOf(
            "a to z", "z to a", "a z", "z a", "a-z", "z-a", "recently added", "newest first", "latest first", "by category", "alphabetical",
            "alphabetically",
        )
        if (!sortWord && !exact) return null
        val padded = " $j "
        return when {
            padded.contains(" z to a ") || padded.contains(" z a ") || padded.contains(" z-a ") ||
                t.any { it == "reverse" || it == "descending" || it == "backwards" } -> VoiceCommand.Sort(SortMode.Z_A)
            padded.contains(" a to z ") || padded.contains(" a z ") || padded.contains(" a-z ") ||
                t.any { it == "alphabetical" || it == "alphabetically" || it == "ascending" || it == "name" || it == "names" } ->
                VoiceCommand.Sort(SortMode.A_Z)
            t.any { it == "recent" || it == "recently" || it == "newest" || it == "latest" || it == "added" || it == "new" } ->
                VoiceCommand.Sort(SortMode.RECENTLY_ADDED)
            t.any { it == "category" || it == "categories" || it == "group" } -> VoiceCommand.Sort(SortMode.BY_CATEGORY)
            else -> null
        }
    }

    // ---- theme

    private val THEME_VERBS = setOf("switch", "change", "set", "use", "make", "apply", "choose", "select", "pick")

    private fun parseTheme(t: List<String>): VoiceCommand? {
        val themeWord = t.any { it == "theme" || it == "themes" || it == "appearance" || it == "colour" || it == "color" || it == "colors" || it == "colours" }
        val emerald = "emerald" in t
        val crimson = "crimson" in t
        if ((emerald || crimson) && (themeWord || t[0] in THEME_VERBS)) {
            return VoiceCommand.Theme(if (emerald && !crimson) AppTheme.EMERALD else if (crimson && !emerald) AppTheme.CRIMSON else null)
        }
        if (themeWord && t[0] in THEME_VERBS) return VoiceCommand.Theme(null)
        return null
    }

    // ---- profile

    private fun parseProfile(t: List<String>, original: String): VoiceCommand? {
        val first = t[0]
        if (first in setOf("change", "set", "update", "edit", "rename") && "name" in t && "to" in t && ("my" in t || "profile" in t)) {
            val after = Regex("(?i)\\bto\\b\\s+(.+)$").find(original.trim())?.groupValues?.get(1)?.let { cleanFreeText(it) }.orEmpty()
            return VoiceCommand.ProfileName(after)
        }
        if ("profile" in t && first in setOf("open", "edit", "change", "update", "show", "go", "view", "take", "see", "customize", "customise")) {
            return VoiceCommand.Open(VoiceScreen.PROFILE)
        }
        return null
    }

    // ---- navigation

    private val NAV_VERBS = setOf("open", "go", "show", "take", "switch", "navigate", "visit", "see", "view", "display", "bring")
    private val NAV_FILLERS = setOf("to", "the", "my", "me", "screen", "page", "tab", "section", "list", "please", "up", "of", "all")
    private val DESTINATIONS: Map<String, VoiceScreen> = mapOf(
        "home" to VoiceScreen.HOME, "main" to VoiceScreen.HOME, "dashboard" to VoiceScreen.HOME, "contacts" to VoiceScreen.HOME,
        "home screen" to VoiceScreen.HOME,
        "categories" to VoiceScreen.CATEGORIES, "category" to VoiceScreen.CATEGORIES, "groups" to VoiceScreen.CATEGORIES,
        "favorites" to VoiceScreen.FAVORITES, "favourites" to VoiceScreen.FAVORITES, "favorite" to VoiceScreen.FAVORITES,
        "favourite" to VoiceScreen.FAVORITES, "starred" to VoiceScreen.FAVORITES,
        "bin" to VoiceScreen.BIN, "recycle bin" to VoiceScreen.BIN, "trash" to VoiceScreen.BIN, "recycle" to VoiceScreen.BIN,
        "deleted" to VoiceScreen.BIN, "deleted contacts" to VoiceScreen.BIN,
        "emergency" to VoiceScreen.EMERGENCY, "emergency services" to VoiceScreen.EMERGENCY, "emergency service" to VoiceScreen.EMERGENCY,
        "emergency numbers" to VoiceScreen.EMERGENCY, "emergencies" to VoiceScreen.EMERGENCY,
        "settings" to VoiceScreen.SETTINGS, "setting" to VoiceScreen.SETTINGS, "preferences" to VoiceScreen.SETTINGS,
        "profile" to VoiceScreen.PROFILE,
        "appearance" to VoiceScreen.APPEARANCE, "themes" to VoiceScreen.APPEARANCE, "theme" to VoiceScreen.APPEARANCE,
        "about" to VoiceScreen.ABOUT, "about the app" to VoiceScreen.ABOUT, "about app" to VoiceScreen.ABOUT,
    )

    private fun parseNavigation(t: List<String>): VoiceCommand? {
        val rest = t.filter { it !in NAV_FILLERS && it !in NAV_VERBS && it != "back" }
        if (rest.isEmpty()) return null
        val phrase = rest.joinToString(" ")
        val screen = DESTINATIONS[phrase] ?: return null
        // "back home" / "back to categories" are navigation too
        return VoiceCommand.Open(screen)
    }

    // ---- favourites

    private val FAVORITE_WORDS = setOf("favorite", "favorites", "favourite", "favourites", "favorited", "unfavorite", "unfavourite", "star", "unstar")
    private val FAVORITE_REMOVE = setOf("remove", "unfavorite", "unfavourite", "unstar", "unmark", "delete", "off", "take")
    private val FAVORITE_FILLERS = setOf(
        "add", "remove", "mark", "make", "set", "put", "take", "off", "from", "to", "as", "in", "my", "the", "list", "contact", "contacts", "a",
        "please", "unmark", "delete", "star", "unstar", "unfavorite", "unfavourite", "favorite", "favorites", "favourite", "favourites", "favorited",
    )

    private fun parseFavorite(t: List<String>): VoiceCommand? {
        if (t.none { it in FAVORITE_WORDS }) return null
        val remove = t.any { it in FAVORITE_REMOVE }
        val query = t.filter { it !in FAVORITE_FILLERS }.joinToString(" ")
        return VoiceCommand.Favorite(query, add = !remove)
    }

    // ---- add contact

    private fun isAddIntent(t: List<String>): Boolean {
        val first = t[0]
        if (first != "add" && first != "create" && first != "new") return false
        return t.size == 1 || t.any { it == "contact" || it == "person" || it == "number" }
    }

    // ---- find / call / edit / delete / view

    private fun parseFind(t: List<String>): VoiceCommand {
        val first = t[0]
        val action: VoiceAction?
        val hasVerb: Boolean
        when {
            first in CALL_WORDS -> { action = VoiceAction.CALL; hasVerb = true }
            first in EDIT_WORDS -> { action = VoiceAction.EDIT; hasVerb = true }
            first in DELETE_WORDS -> { action = VoiceAction.DELETE; hasVerb = true }
            first in VIEW_WORDS -> { action = VoiceAction.VIEW; hasVerb = true }
            first in SEARCH_WORDS -> { action = null; hasVerb = true }
            else -> { action = null; hasVerb = false }
        }
        var rest = if (hasVerb) t.drop(1) else t
        var act = action
        // "show details", "view details of Ahmed": a details word turns a plain search into View
        if (hasVerb && rest.any { it in DETAIL_WORDS }) {
            act = VoiceAction.VIEW
            rest = rest.filter { it !in DETAIL_WORDS }
        }
        // "view this contact", "open it": pronouns refer to the current contact, they are not a name
        val query = cleanQuery(rest)
        val pronounOnly = rest.isNotEmpty() && rest.all { it in NAME_FILLERS }
        return VoiceCommand.Find(if (pronounOnly) "" else query, act)
    }

    private fun cleanQuery(words: List<String>): String {
        var list = words
        while (list.isNotEmpty() && list.first() in LEADING_FILLERS) list = list.drop(1)
        while (list.isNotEmpty() && list.last() in TRAILING_FILLERS) list = list.dropLast(1)
        return list.joinToString(" ")
    }

    // ------------------------------------------------------------------ follow-up replies

    fun isClose(text: String): Boolean = normalize(text) in CLOSE_PHRASES
    fun isCancel(text: String): Boolean = normalize(text) in CANCEL_PHRASES || normalize(text) in BACK_PHRASES

    fun isSkip(text: String): Boolean {
        val n = normalize(text)
        return n in SKIP_WORDS || (n.isNotEmpty() && tokens(text).all { it in SKIP_WORDS })
    }

    fun isClear(text: String): Boolean {
        val t = tokens(text)
        return t.isNotEmpty() && t.size <= 2 && t.all { it in CLEAR_WORDS || it == "it" || it == "this" }
    }

    fun isSecurityRequest(text: String): Boolean {
        val t = tokens(text)
        return t.isNotEmpty() && isSecurityRequest(t, t.joinToString(" "))
    }

    /**
     * Exactly one kind of action word means that action; none or conflicting ones mean "not understood". Used for
     * the "what would you like to do?" question, so natural forms all work: "View", "View this contact",
     * "Open contact", "Show details", "Show Ahmed Khan". [allowHomophones] additionally accepts "you"/"few"
     * (how recognisers often hear "view") when it is the entire answer.
     */
    /** True when the whole utterance is a known mis-hearing of "view" (only meaningful as the answer to "what next?"). */
    fun isViewHomophone(text: String): Boolean = tokens(text).let { it.size == 1 && it[0] in VIEW_HOMOPHONES }

    fun parseAction(text: String, allowHomophones: Boolean = false): VoiceAction? {
        val t = tokens(text)
        if (t.isEmpty()) return null
        val found = HashSet<VoiceAction>()
        val favorite = t.any { it in FAVORITE_WORDS }
        if (favorite) {
            found += if (t.any { it in FAVORITE_REMOVE }) VoiceAction.UNFAVORITE else VoiceAction.FAVORITE
        } else {
            for (tok in t) {
                when (tok) {
                    in CALL_WORDS -> found += VoiceAction.CALL
                    in EDIT_WORDS -> found += VoiceAction.EDIT
                    in DELETE_WORDS -> found += VoiceAction.DELETE
                    in VIEW_WORDS, "show" -> found += VoiceAction.VIEW
                }
            }
            if (found.isEmpty() && allowHomophones && t.size == 1 && t[0] in VIEW_HOMOPHONES) found += VoiceAction.VIEW
        }
        return if (found.size == 1) found.first() else null
    }

    /** The words of [text] that are neither action words nor fillers: the part that may name a contact. */
    fun nameWords(text: String): List<String> {
        val skip = CALL_WORDS + EDIT_WORDS + DELETE_WORDS + VIEW_WORDS + SEARCH_WORDS + NAME_FILLERS + FAVORITE_WORDS + FAVORITE_FILLERS +
            setOf("show", "details", "this", "that")
        return tokens(text).filter { it !in skip }
    }

    /**
     * Strict confirmation reading. A NO word always wins (safer), long rambling answers are not accepted as YES,
     * and anything unclear returns null so the caller asks again instead of acting.
     */
    fun parseYesNo(text: String): YesNo? {
        val t = tokens(text)
        if (t.isEmpty()) return null
        if (t.any { it in NO_WORDS }) return YesNo.NO
        val joined = t.joinToString(" ")
        if (t.size <= 4 && (t.any { it in YES_WORDS } || YES_PHRASES.any { joined.contains(it) })) return YesNo.YES
        return null
    }

    /**
     * Stricter reading for IRREVERSIBLE actions (permanent deletion): only an explicit "yes" / "confirm" / "delete"
     * counts. "ok", "sure" and "yeah" are deliberately not enough. Any NO word wins.
     */
    fun parseStrictYesNo(text: String): YesNo? {
        val t = tokens(text)
        if (t.isEmpty()) return null
        if (t.any { it in NO_WORDS }) return YesNo.NO
        if (t.size <= 4 && t.any { it == "yes" || it == "confirm" || it == "confirmed" || it == "delete" || it == "permanently" }) return YesNo.YES
        return null
    }

    fun parseEditField(text: String): EditField? {
        val found = HashSet<EditField>()
        for (tok in tokens(text)) {
            when (tok) {
                "name" -> found += EditField.NAME
                "phone", "number", "mobile", "cell", "telephone" -> found += EditField.PHONE
                "email", "mail", "e-mail" -> found += EditField.EMAIL
                "address", "location", "street" -> found += EditField.ADDRESS
                "notes", "note", "memo" -> found += EditField.NOTES
                "category", "categories", "group" -> found += EditField.CATEGORY
            }
        }
        return if (found.size == 1) found.first() else null
    }

    fun parseEmergencyField(text: String): EmergencyField? {
        val found = HashSet<EmergencyField>()
        for (tok in tokens(text)) {
            when (tok) {
                "name", "title", "service" -> found += EmergencyField.NAME
                "number", "phone", "digits" -> found += EmergencyField.NUMBER
            }
        }
        return if (found.size == 1) found.first() else null
    }

    fun parseTheme(text: String): AppTheme? {
        val t = tokens(text)
        val e = "emerald" in t
        val c = "crimson" in t
        return when {
            e && !c -> AppTheme.EMERALD
            c && !e -> AppTheme.CRIMSON
            else -> null
        }
    }

    private val ORDINALS = mapOf(
        "first" to 0, "1st" to 0, "second" to 1, "2nd" to 1, "third" to 2, "3rd" to 2,
        "fourth" to 3, "4th" to 3, "fifth" to 4, "5th" to 4,
    )
    private val NUMBER_WORDS = mapOf(
        "one" to 0, "1" to 0, "two" to 1, "2" to 1, "three" to 2, "3" to 2, "four" to 3, "4" to 3, "five" to 4, "5" to 4,
    )
    private val CHOICE_FILLERS = setOf("number", "option", "contact", "choice", "the", "one", "please", "pick", "choose", "select")

    /** "the second one", "number two", "2" -> 0-based index; null when the utterance is not a pick by position. */
    fun parseOrdinal(text: String): Int? {
        val t = tokens(text)
        for (tok in t) ORDINALS[tok]?.let { return it }
        if (t.isEmpty() || t.size > 3) return null
        if (!t.all { it in NUMBER_WORDS || it in CHOICE_FILLERS }) return null
        for (tok in t) NUMBER_WORDS[tok]?.let { return it }
        return null
    }

    // ------------------------------------------------------------------ spoken value clean-up

    private val DIGIT_WORDS = mapOf(
        "zero" to '0', "oh" to '0', "o" to '0', "one" to '1', "two" to '2', "three" to '3', "four" to '4',
        "five" to '5', "six" to '6', "seven" to '7', "eight" to '8', "nine" to '9',
    )
    private val PHONE_IGNORED = setOf("dash", "hyphen", "space", "and")

    /**
     * "zero three double zero one two three" -> "0300123", "plus nine two ..." -> "+92...". Already-numeric text
     * ("0300 1234567") is kept. If any word is not a number word the original text is returned unchanged so the
     * validator rejects it instead of the app guessing.
     */
    fun normalizeSpokenPhone(text: String): String {
        val sb = StringBuilder()
        var times = 1
        for (tok in tokens(text)) {
            when {
                tok == "double" -> times = 2
                tok == "triple" -> times = 3
                tok == "plus" -> sb.append('+')
                tok in PHONE_IGNORED -> Unit
                tok.matches(Regex("\\+?[0-9-]+")) -> { sb.append(tok.replace("-", "")); times = 1 }
                DIGIT_WORDS.containsKey(tok) -> { for (i in 0 until times) sb.append(DIGIT_WORDS.getValue(tok)); times = 1 }
                else -> return text.trim()
            }
        }
        return if (sb.isEmpty()) text.trim() else sb.toString()
    }

    /** "ahmed at example dot com" -> "ahmed@example.com". Text that already looks like an address is left alone. */
    fun normalizeSpokenEmail(text: String): String {
        var s = " " + text.lowercase(Locale.ROOT).trim() + " "
        s = s.replace(" at the rate of ", " @ ").replace(" at ", " @ ")
            .replace(" dot ", " . ").replace(" underscore ", " _ ")
            .replace(" dash ", " - ").replace(" hyphen ", " - ")
        return s.replace(" ", "")
    }

    /** Free text (name, address, notes): trimmed, single spaces, no trailing full stop added by the recogniser. */
    fun cleanFreeText(text: String): String =
        text.trim().replace(Regex("\\s+"), " ").trimEnd('.', ',', '!', '?').trim()
}
