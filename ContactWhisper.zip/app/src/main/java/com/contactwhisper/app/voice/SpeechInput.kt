package com.contactwhisper.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Why a recognition request ended without a transcript. */
enum class FailureKind { NO_SPEECH, NOT_UNDERSTOOD, PERMISSION, NETWORK, BUSY, UNAVAILABLE, OTHER }

/**
 * Thin wrapper over Android's [SpeechRecognizer]. Main thread only.
 *
 *  - Listening only ever starts from [start], called by [VoiceAssistant] while a voice session is open (the session
 *    ends when the user closes it or the app leaves the foreground). Android's recogniser works in sequential
 *    requests, so continuous listening is a series of back-to-back requests; each ends at the user's pause.
 *  - One recognizer per listening request, destroyed as soon as that request ends, so nothing keeps the
 *    microphone open after the session is closed.
 *  - Every callback is bound to the request's token; late, duplicate or cancelled callbacks are dropped here
 *    (and again, independently, inside [VoiceConversation]).
 *  - A watchdog ends a request that never produces a callback.
 *  - No offline/online preference is forced: the device's speech service decides, and the app never claims
 *    offline support.
 */
class SpeechInput(
    context: Context,
    private val listener: Listener,
) {
    interface Listener {
        fun onPartial(token: Int, text: String)
        fun onResults(token: Int, alternatives: List<String>)
        fun onFailure(token: Int, kind: FailureKind)
    }

    private val context = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var activeToken = 0
    private var watchdog: Runnable? = null

    /** True once the recogniser reported the start of speech for the current request. */
    private var began = false

    fun isAvailable(): Boolean = try {
        SpeechRecognizer.isRecognitionAvailable(context)
    } catch (e: Exception) {
        false
    }

    fun start(token: Int) {
        cancel()
        if (!isAvailable()) {
            listener.onFailure(token, FailureKind.UNAVAILABLE)
            return
        }
        val created = try {
            SpeechRecognizer.createSpeechRecognizer(context)
        } catch (e: Exception) {
            null
        }
        if (created == null) {
            listener.onFailure(token, FailureKind.UNAVAILABLE)
            return
        }
        activeToken = token
        recognizer = created
        began = false
        created.setRecognitionListener(Callbacks(token))
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            created.startListening(intent)
        } catch (e: Exception) {
            finish(token) { listener.onFailure(token, FailureKind.OTHER) }
            return
        }
        val dog = Runnable { finish(token) { listener.onFailure(token, FailureKind.NO_SPEECH) } }
        watchdog = dog
        handler.postDelayed(dog, WATCHDOG_MS)
    }

    /** Stops the current request without reporting anything (the conversation already moved on). */
    fun cancel() {
        activeToken = 0
        clearWatchdog()
        releaseRecognizer()
    }

    fun release() = cancel()

    private fun clearWatchdog() {
        watchdog?.let { handler.removeCallbacks(it) }
        watchdog = null
    }

    private fun releaseRecognizer() {
        val r = recognizer ?: return
        recognizer = null
        try {
            r.cancel()
        } catch (_: Exception) {
        }
        try {
            r.destroy()
        } catch (_: Exception) {
        }
    }

    /** Ends request [token] exactly once: tears the recognizer down, then runs [report]. */
    private fun finish(token: Int, report: () -> Unit) {
        if (token == 0 || token != activeToken) return
        activeToken = 0
        clearWatchdog()
        releaseRecognizer()
        report()
    }

    private inner class Callbacks(private val token: Int) : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = Unit
        override fun onBeginningOfSpeech() {
            if (token == activeToken) began = true
        }

        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onEvent(eventType: Int, params: Bundle?) = Unit

        override fun onPartialResults(partialResults: Bundle?) {
            if (token != activeToken) return
            val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) listener.onPartial(token, text)
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            finish(token) { listener.onResults(token, list) }
        }

        override fun onError(error: Int) {
            val heardSpeech = began
            finish(token) { listener.onFailure(token, mapError(error, heardSpeech)) }
        }
    }

    companion object {
        /** Own safety net; the recognizer normally reports silence/timeouts itself well before this. */
        const val WATCHDOG_MS = 20_000L

        /** SpeechRecognizer.ERROR_* values, by number (some constants are newer than minSdk). */
        fun mapError(code: Int, heardSpeech: Boolean = false): FailureKind = when (code) {
            // ERROR_NO_MATCH: if speech began it was real speech that could not be recognised ("I didn't catch that");
            // otherwise it is just silence / noise, which is NOT a command and is ignored.
            7 -> if (heardSpeech) FailureKind.NOT_UNDERSTOOD else FailureKind.NO_SPEECH
            6 -> FailureKind.NO_SPEECH                 // ERROR_SPEECH_TIMEOUT
            1, 2, 4 -> FailureKind.NETWORK             // NETWORK_TIMEOUT, NETWORK, SERVER
            8, 10 -> FailureKind.BUSY                  // RECOGNIZER_BUSY, TOO_MANY_REQUESTS
            9 -> FailureKind.PERMISSION                // INSUFFICIENT_PERMISSIONS
            11, 12, 13 -> FailureKind.UNAVAILABLE      // SERVER_DISCONNECTED, LANGUAGE_NOT_SUPPORTED, LANGUAGE_UNAVAILABLE
            else -> FailureKind.OTHER                  // CLIENT, AUDIO, unknown
        }
    }
}
