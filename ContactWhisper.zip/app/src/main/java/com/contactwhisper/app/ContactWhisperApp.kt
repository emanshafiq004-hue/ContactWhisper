package com.contactwhisper.app

import android.app.Application
import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.contactwhisper.app.data.AppDatabase
import com.contactwhisper.app.data.ContactRepository
import com.contactwhisper.app.data.EmergencyRepository
import com.contactwhisper.app.data.EmergencySeed
import com.contactwhisper.app.data.SettingsStore
import com.contactwhisper.app.work.BinCleanupWorker
import java.util.concurrent.TimeUnit

/** Hand-rolled dependency container (no DI framework needed for an app this size). */
class AppContainer(context: Context) {
    val database: AppDatabase = AppDatabase.build(context)
    val settings = SettingsStore(context.applicationContext)
    val contacts = ContactRepository(database)
    val emergency = EmergencyRepository(database)

    /**
     * Startup sequence: default categories, first-run emergency seed (once), purge expired Bin
     * entries, then build the Java DSA index from Room.
     */
    suspend fun initialize() {
        contacts.ensureDefaultCategories()
        if (!settings.isEmergencySeeded()) {
            if (emergency.isEmpty()) emergency.seed(EmergencySeed.entries)
            settings.markEmergencySeeded()
        }
        contacts.purgeExpired()
        emergency.purgeExpired()
        contacts.load()
    }
}

class ContactWhisperApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        scheduleBinCleanup()
    }

    /** Daily best-effort cleanup. Android decides the exact run time; the app also purges at startup. */
    private fun scheduleBinCleanup() {
        val request = PeriodicWorkRequestBuilder<BinCleanupWorker>(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork(BinCleanupWorker.UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
    }
}
