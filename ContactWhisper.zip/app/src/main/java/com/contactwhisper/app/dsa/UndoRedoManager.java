package com.contactwhisper.app.dsa;

/**
 * Undo/Redo built on TWO custom stacks.
 *
 *  undoStack: actions that can be undone (top = most recent)
 *  redoStack: actions that were undone and can be re-applied
 *
 * Protocol (kept two-phase so the caller can apply the change to Room first, and only then commit):
 *   record(a)                    -> push on undo, CLEAR redo (a new action invalidates the redo history)
 *   peekUndo() ... commitUndo()  -> pop undo, push on redo      (or discardUndo() if the change failed)
 *   peekRedo() ... commitRedo()  -> pop redo, push on undo, redo history otherwise preserved
 *
 * All operations are O(1) except record() when redo is non-empty (clear is O(r)).
 * The history lives in memory only: it resets when the app process restarts.
 */
public final class UndoRedoManager {
    private final CustomStack<UndoableAction> undoStack = new CustomStack<>();
    private final CustomStack<UndoableAction> redoStack = new CustomStack<>();

    public void record(UndoableAction action) {
        undoStack.push(action);
        redoStack.clear();
    }

    public boolean canUndo() {
        return !undoStack.isEmpty();
    }

    public boolean canRedo() {
        return !redoStack.isEmpty();
    }

    public UndoableAction peekUndo() {
        return undoStack.isEmpty() ? null : undoStack.peek();
    }

    public UndoableAction peekRedo() {
        return redoStack.isEmpty() ? null : redoStack.peek();
    }

    /** The undo was applied successfully: move the action to the redo stack. */
    public void commitUndo() {
        redoStack.push(undoStack.pop());
    }

    /** The undo could not be applied (e.g. the data is gone): drop the action. */
    public void discardUndo() {
        undoStack.pop();
    }

    /** The redo was applied successfully: move the action back to the undo stack (redo history stays). */
    public void commitRedo() {
        undoStack.push(redoStack.pop());
    }

    public void discardRedo() {
        redoStack.pop();
    }

    /**
     * Permanent deletion is irreversible: drops EVERY entry (Add, Edit, Delete, Restore, Favorite, Category)
     * about the given contact ids from BOTH stacks so no Undo or Redo can ever re-create them.
     * @return number of history entries removed
     */
    public int purgeContacts(java.util.Collection<Long> contactIds) {
        if (contactIds == null || contactIds.isEmpty()) return 0;
        java.util.HashSet<Long> ids = new java.util.HashSet<>(contactIds);
        java.util.function.Predicate<UndoableAction> matches = a -> ids.contains(a.getContactId());
        return undoStack.removeIf(matches) + redoStack.removeIf(matches);
    }

    /** True when any history entry (either stack) concerns the contact id. */
    public boolean mentions(long contactId) {
        for (UndoableAction a : undoStack.toListTopFirst()) if (a.getContactId() == contactId) return true;
        for (UndoableAction a : redoStack.toListTopFirst()) if (a.getContactId() == contactId) return true;
        return false;
    }

    public int undoSize() {
        return undoStack.size();
    }

    public int redoSize() {
        return redoStack.size();
    }

    public void clear() {
        undoStack.clear();
        redoStack.clear();
    }
}
