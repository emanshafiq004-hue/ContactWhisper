package com.contactwhisper.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Keeps only what a dialer understands (digits, a leading +, * and #) so "+92 (300) 123-4567" dials as "+923001234567".
 * Returns an empty string when nothing dialable is left.
 */
fun dialableNumber(number: String): String = number.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }

/** The ACTION_DIAL intent for [number] (pre-filled, not placed), or null when there is nothing to dial. */
fun buildDialIntent(number: String): Intent? {
    val cleaned = dialableNumber(number)
    if (cleaned.isEmpty()) return null
    return Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", cleaned, null))
}

/**
 * Opens the system dialer with the number pre-filled (ACTION_DIAL); the user confirms the call there, so this path needs
 * no permission. It is the fallback for every call button / drag-to-call when CALL_PHONE is not granted, and the only
 * path for Emergency Services numbers. The decision between this and [placeCallDirect] lives in `ui/components/Caller.kt`.
 */
fun dialNumber(context: Context, number: String): Boolean {
    val intent = buildDialIntent(number)
    if (intent == null) {
        Toast.makeText(context, "No phone number to dial", Toast.LENGTH_SHORT).show()
        return false
    }
    return try {
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No dialer app available on this device", Toast.LENGTH_LONG).show()
        false
    }
}

/** True when CALL_PHONE has been granted (direct calling). */
fun hasCallPermission(context: Context): Boolean =
    androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.CALL_PHONE) ==
        android.content.pm.PackageManager.PERMISSION_GRANTED

/**
 * Places the call directly with ACTION_CALL. Only valid when [hasCallPermission] is true; a SecurityException (the
 * permission was revoked meanwhile) falls back to the dialer so the user can still call. Direct calling is NOT
 * permission-free: without CALL_PHONE the app can only open the dialer.
 */
fun placeCallDirect(context: Context, number: String): Boolean {
    val cleaned = dialableNumber(number)
    if (cleaned.isEmpty()) return dialNumber(context, number)
    return try {
        context.startActivity(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", cleaned, null)))
        true
    } catch (e: SecurityException) {
        dialNumber(context, number)
    } catch (e: ActivityNotFoundException) {
        dialNumber(context, number)
    }
}
