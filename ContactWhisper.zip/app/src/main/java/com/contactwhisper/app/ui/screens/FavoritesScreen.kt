package com.contactwhisper.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.ui.components.ContactActions
import com.contactwhisper.app.ui.components.ContactCard
import com.contactwhisper.app.ui.components.EmptyState
import com.contactwhisper.app.ui.components.ScreenHeader

/** Only starred contacts, with the same cards and gestures as Home. Removing a star updates every screen at once. */
@Composable
fun FavoritesScreen(vm: AppViewModel, actions: ContactActions) {
    val favorites by vm.favorites.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = "Favorites", onBack = null)
        if (favorites.isEmpty()) {
            EmptyState(
                title = "No favorites yet",
                message = "Tap the star on any contact to keep it here.",
                icon = R.drawable.ic_star_outline,
                modifier = Modifier.weight(1f),
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(favorites, key = { it.id }) { contact ->
                    ContactCard(
                        contact = contact,
                        onOpen = { actions.open(contact) },
                        onEdit = { actions.edit(contact) },
                        onCall = { actions.call(contact) },
                        onDelete = { actions.delete(contact) },
                        onToggleFavorite = { actions.toggleFavorite(contact) },
                        modifier = Modifier.animateItem(),
                    )
                }
            }
        }
    }
}
