package com.contactwhisper.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Emergency Services entries (Room). The list is separate from personal contacts: entries are not in the DSA
 * contact index and are not subject to the 11-digit Pakistani mobile rule. A deleted entry goes to the Recycle
 * Bin (soft delete) and is restored to THIS list; it follows the same 30-day retention as contacts.
 */
class EmergencyRepository(private val db: AppDatabase) {
    private val dao = db.emergencyDao()

    val entries: Flow<List<EmergencyEntity>> = dao.observeAll()
    val binItems: Flow<List<EmergencyEntity>> = dao.observeBin()

    suspend fun isEmpty(): Boolean = withContext(Dispatchers.IO) { dao.count() == 0 }

    suspend fun seed(list: List<EmergencyEntity>) = withContext(Dispatchers.IO) {
        list.forEach { dao.insert(it) }
    }

    suspend fun add(name: String, number: String): Long = withContext(Dispatchers.IO) {
        dao.insert(EmergencyEntity(name = name.trim(), number = number.trim(), sortOrder = dao.maxOrder() + 1))
    }

    suspend fun update(entity: EmergencyEntity, name: String, number: String) = withContext(Dispatchers.IO) {
        dao.update(entity.copy(name = name.trim(), number = number.trim()))
    }

    suspend fun get(id: Long): EmergencyEntity? = withContext(Dispatchers.IO) { dao.getById(id) }

    /** Moves the entry to the Recycle Bin. Returns the entry (as it was) or null when it was not active. */
    suspend fun moveToBin(id: Long, nowMillis: Long = System.currentTimeMillis()): EmergencyEntity? =
        withContext(Dispatchers.IO) {
            val row = dao.getById(id)
            if (row != null && row.deletedAt == null && dao.softDelete(id, nowMillis) > 0) row else null
        }

    /** Brings a binned entry back to the Emergency Services list (type and number preserved). */
    suspend fun restore(id: Long): Boolean = withContext(Dispatchers.IO) { dao.clearDeleted(id) > 0 }

    suspend fun restoreAll(ids: List<Long>): Int = withContext(Dispatchers.IO) {
        ids.count { dao.clearDeleted(it) > 0 }
    }

    /** Irreversible. Callers must have explicit confirmation. Only Bin entries can be removed this way. */
    suspend fun permanentlyDelete(ids: List<Long>): Int = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) 0 else dao.hardDeleteBinItems(ids)
    }

    suspend fun purgeExpired(nowMillis: Long = System.currentTimeMillis()): Int = withContext(Dispatchers.IO) {
        dao.purgeBefore(nowMillis - ContactRepository.RETENTION_MS)
    }
}
