package com.contactwhisper.app.dsa;

/**
 * Custom hash table with separate chaining. Maps a normalized String key (phone key, lower-cased
 * email, lower-cased name) to the ids of the contacts that have that key.
 *
 * Because each key owns a small id list, the same structure serves unique indexes (phone, email)
 * and the non-unique name index.
 *
 * Complexity (average, load factor kept <= 0.75 by doubling the bucket array):
 *  - put / get / remove / containsKey : O(1) average, O(chain) worst case
 *  - resize (rehash)                  : O(k) amortised over inserts, k = number of keys
 *
 * Collisions: keys that land in the same bucket are chained as a linked list of {@link Entry}.
 */
public final class ContactHashTable {
    private static final int DEFAULT_CAPACITY = 16;
    private static final double MAX_LOAD = 0.75;
    private static final long[] NO_IDS = new long[0];

    private static final class Entry {
        final String key;
        long[] ids = new long[2];
        int count;
        Entry next;

        Entry(String key) {
            this.key = key;
        }

        boolean add(long id) {
            for (int i = 0; i < count; i++) if (ids[i] == id) return false;
            if (count == ids.length) {
                long[] bigger = new long[ids.length * 2];
                System.arraycopy(ids, 0, bigger, 0, count);
                ids = bigger;
            }
            ids[count++] = id;
            return true;
        }

        boolean removeId(long id) {
            for (int i = 0; i < count; i++) {
                if (ids[i] == id) {
                    ids[i] = ids[count - 1];
                    count--;
                    return true;
                }
            }
            return false;
        }
    }

    private Entry[] buckets;
    private int keyCount;

    public ContactHashTable() {
        this(DEFAULT_CAPACITY);
    }

    /** Capacity is rounded up to a power of two (minimum 2). A tiny capacity forces collisions in tests. */
    public ContactHashTable(int initialCapacity) {
        int cap = 2;
        while (cap < initialCapacity) cap <<= 1;
        buckets = new Entry[cap];
    }

    private static int indexFor(String key, int length) {
        int h = key.hashCode();
        h ^= (h >>> 16);
        return h & (length - 1);
    }

    /** Adds id under key. Null/empty keys are ignored. Returns true if the pair was newly added. */
    public boolean put(String key, long id) {
        if (key == null || key.isEmpty()) return false;
        int idx = indexFor(key, buckets.length);
        for (Entry e = buckets[idx]; e != null; e = e.next) {
            if (e.key.equals(key)) return e.add(id);
        }
        Entry fresh = new Entry(key);
        fresh.add(id);
        fresh.next = buckets[idx];
        buckets[idx] = fresh;
        keyCount++;
        if (keyCount > buckets.length * MAX_LOAD) resize();
        return true;
    }

    /** Returns a copy of the ids stored under key (empty array when absent). */
    public long[] get(String key) {
        if (key == null || key.isEmpty()) return NO_IDS;
        int idx = indexFor(key, buckets.length);
        for (Entry e = buckets[idx]; e != null; e = e.next) {
            if (e.key.equals(key)) {
                long[] copy = new long[e.count];
                System.arraycopy(e.ids, 0, copy, 0, e.count);
                return copy;
            }
        }
        return NO_IDS;
    }

    public boolean containsKey(String key) {
        return get(key).length > 0;
    }

    /** Removes one id from key; drops the key entirely when its id list becomes empty. */
    public boolean remove(String key, long id) {
        if (key == null || key.isEmpty()) return false;
        int idx = indexFor(key, buckets.length);
        Entry prev = null;
        for (Entry e = buckets[idx]; e != null; prev = e, e = e.next) {
            if (e.key.equals(key)) {
                boolean removed = e.removeId(id);
                if (removed && e.count == 0) {
                    if (prev == null) buckets[idx] = e.next; else prev.next = e.next;
                    keyCount--;
                }
                return removed;
            }
        }
        return false;
    }

    /** Number of distinct keys. */
    public int size() {
        return keyCount;
    }

    public int bucketCount() {
        return buckets.length;
    }

    /** Longest collision chain, exposed so tests can prove chaining really happens. */
    public int longestChain() {
        int best = 0;
        for (Entry head : buckets) {
            int len = 0;
            for (Entry e = head; e != null; e = e.next) len++;
            if (len > best) best = len;
        }
        return best;
    }

    public void clear() {
        buckets = new Entry[DEFAULT_CAPACITY];
        keyCount = 0;
    }

    private void resize() {
        Entry[] old = buckets;
        Entry[] bigger = new Entry[old.length * 2];
        for (Entry head : old) {
            Entry e = head;
            while (e != null) {
                Entry next = e.next;
                int idx = indexFor(e.key, bigger.length);
                e.next = bigger[idx];
                bigger[idx] = e;
                e = next;
            }
        }
        buckets = bigger;
    }
}
