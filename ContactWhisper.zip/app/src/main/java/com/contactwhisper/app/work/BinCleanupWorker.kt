package com.contactwhisper.app.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.contactwhisper.app.ContactWhisperApp

/** Permanently removes Recycle Bin entries (contacts and Emergency entries) older than 30 days. Does not touch active entries. */
class BinCleanupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? ContactWhisperApp ?: return Result.failure()
        return try {
            app.container.contacts.purgeExpired()
            app.container.emergency.purgeExpired()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val UNIQUE_NAME = "bin_cleanup"
    }
}
