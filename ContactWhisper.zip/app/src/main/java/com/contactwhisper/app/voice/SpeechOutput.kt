package com.contactwhisper.app.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.ArrayDeque
import java.util.Locale

/**
 * Serialized text-to-speech. Main thread only.
 *
 *  - ONE utterance is handed to the engine at a time; the next one starts from the engine's own
 *    [UtteranceProgressListener] completion callback. Two lines therefore can never overlap, and there are no
 *    timing delays anywhere.
 *  - [onBusy] fires when speech starts after being idle and [onIdle] when the last queued line has finished. The
 *    assistant uses them to pause recognition while it talks (so it never transcribes itself) and to resume
 *    listening afterwards.
 *  - [dropQueued] discards lines that have not started yet but lets the sentence being spoken finish (used when the
 *    user cancels or a new screen replaces the question: no stale line is spoken later, none is cut in half).
 *  - [stop] is the hard stop, only for the app leaving the foreground / the assistant being released.
 *  - A safety timeout ends an utterance whose completion callback never arrives (broken engines).
 *  - The engine is created lazily on the first line. If it (or the language) is unavailable nothing is spoken; every
 *    response is also shown as text, so the assistant stays fully usable, and [onIdle] still fires.
 */
class SpeechOutput(
    context: Context,
    private val onBusy: () -> Unit,
    private val onIdle: () -> Unit,
) {
    private val context = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private var initializing = false

    private val queue = ArrayDeque<String>()
    private var currentId: String? = null
    private var counter = 0
    private var watchdog: Runnable? = null
    private var announcedBusy = false

    val isBusy: Boolean get() = currentId != null || queue.isNotEmpty() || (initializing && !failed)

    fun speak(text: String) {
        if (text.isBlank()) return
        if (failed) return // text is on screen; nothing to wait for
        queue.add(text)
        if (!announcedBusy) {
            announcedBusy = true
            onBusy()
        }
        if (!ready) {
            ensureEngine()
        } else if (currentId == null) {
            next()
        }
    }

    private fun ensureEngine() {
        if (tts != null || failed) return
        initializing = true
        tts = try {
            TextToSpeech(context) { status -> handler.post { onInit(status) } }
        } catch (e: Exception) {
            null
        }
        if (tts == null) fail()
    }

    private fun onInit(status: Int) {
        initializing = false
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            fail()
            return
        }
        val result = try {
            engine.setLanguage(Locale.getDefault())
        } catch (e: Exception) {
            TextToSpeech.LANG_NOT_SUPPORTED
        }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            fail()
            return
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) {
                handler.post { finished(utteranceId) }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { finished(utteranceId) }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                handler.post { finished(utteranceId) }
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                handler.post { finished(utteranceId) }
            }
        })
        ready = true
        if (currentId == null) next()
    }

    private fun fail() {
        failed = true
        initializing = false
        queue.clear()
        currentId = null
        clearWatchdog()
        if (announcedBusy) {
            announcedBusy = false
            onIdle()
        }
    }

    private fun next() {
        val text = queue.poll()
        if (text == null) {
            currentId = null
            if (announcedBusy) {
                announcedBusy = false
                onIdle()
            }
            return
        }
        val id = "cw-${++counter}"
        currentId = id
        val ok = try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.SUCCESS
        } catch (e: Exception) {
            false
        }
        if (!ok) {
            finished(id)
            return
        }
        // Safety net only: normal completion always comes from the progress listener.
        val dog = Runnable { finished(id) }
        watchdog = dog
        handler.postDelayed(dog, 4_000L + text.length * 90L)
    }

    private fun finished(id: String?) {
        if (id == null || id != currentId) return // a stale or duplicate callback
        clearWatchdog()
        currentId = null
        next()
    }

    private fun clearWatchdog() {
        watchdog?.let { handler.removeCallbacks(it) }
        watchdog = null
    }

    /** Forgets lines that have not started. The sentence being spoken right now finishes normally. */
    fun dropQueued() {
        queue.clear()
        if (currentId == null && announcedBusy && !initializing) {
            announcedBusy = false
            onIdle()
        }
    }

    /** Hard stop: nothing is spoken any more (app in the background, assistant released). */
    fun stop() {
        queue.clear()
        clearWatchdog()
        currentId = null
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        if (announcedBusy) {
            announcedBusy = false
            onIdle()
        }
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
        ready = false
    }
}
