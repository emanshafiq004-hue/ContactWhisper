package com.contactwhisper.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.contactwhisper.app.dsa.ContactRecord

/**
 * Durable contact row. A row with deletedAt == null is ACTIVE (mirrored in the Java DSA index);
 * a row with deletedAt != null lives in the Recycle Bin until restored or purged after 30 days.
 */
@Entity(tableName = "contacts", indices = [Index("deletedAt")])
data class ContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val category: String = "",
    val isFavorite: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null,
)

@Entity(tableName = "categories", indices = [Index(value = ["name"], unique = true)])
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isDefault: Boolean = false,
)

/**
 * Emergency Services entry. These are public-service numbers kept in their own table (never mixed with personal
 * contacts, never in the contact DSA index). A soft-deleted entry shows in the Bin tagged as an Emergency entry,
 * and restoring it puts it back on the Emergency Services list.
 */
@Entity(tableName = "emergency_services")
data class EmergencyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val number: String,
    val sortOrder: Int = 0,
    /** null = listed on the Emergency Services screen; otherwise the entry sits in the Recycle Bin. */
    val deletedAt: Long? = null,
)

fun ContactEntity.toRecord(): ContactRecord = ContactRecord(
    id, name, phone, email, address, notes, category, isFavorite, createdAt, updatedAt,
)

fun ContactRecord.toEntity(deletedAt: Long? = null): ContactEntity = ContactEntity(
    id = id,
    name = name,
    phone = phone,
    email = email,
    address = address,
    notes = notes,
    category = category,
    isFavorite = isFavorite,
    createdAt = createdAt,
    updatedAt = updatedAt,
    deletedAt = deletedAt,
)
