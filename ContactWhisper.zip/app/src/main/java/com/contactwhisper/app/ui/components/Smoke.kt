package com.contactwhisper.app.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Procedural smoke burst for the double-tap delete (about 500 ms).
 *
 * HONEST NOTE: the supplied reference clip (crimson ink burst on solid black, 10 s) cannot be composited over a card
 * without a black rectangle, and no transparent frame sequence was supplied, so the effect is approximated in code:
 * a puff = a stack of soft radial-gradient blobs (opaque core, transparent rim) laid along a short CURVED trail, with
 * per-puff size, speed, curl and opacity, plus a slight upward buoyancy. It reads as soft wisps rather than discs,
 * but it is not the video's fluid-dynamics smoke. A transparent PNG sequence dropped into the project could replace
 * [drawSmokeBurst] later without touching the gesture code.
 *
 * Timeline (t = 0..1 over 500 ms): puffs launch from the card centre, expand fast (ease-out), the core briefly
 * covers the card (t ~ 0.15-0.5), then everything thins out and is gone at t = 1. Allocation: the particle table is
 * built once per delete ([SmokeField]) and released afterwards; per frame only Brush objects are created.
 */
const val SMOKE_DURATION_MS = 500

class SmokeField(seed: Int) {
    val count = 13
    /** per puff: angle(rad), speed(0..1), size(0..1), curl(-1..1), delay(0..0.12), tone(0..1), stretch(1.5..2.3) */
    val angle = FloatArray(count)
    val speed = FloatArray(count)
    val size = FloatArray(count)
    val curl = FloatArray(count)
    val delay = FloatArray(count)
    val tone = FloatArray(count)
    val stretch = FloatArray(count)

    init {
        var h = seed * 747796405 + 2891336453L.toInt()
        fun next(): Float {
            h = h * 1664525 + 1013904223
            return ((h ushr 8) and 0xFFFF) / 65535f
        }
        for (i in 0 until count) {
            angle[i] = ((i + next() * 0.8f) / count) * (2f * PI.toFloat())
            speed[i] = 0.45f + next() * 0.55f
            size[i] = 0.35f + next() * 0.65f
            curl[i] = (next() - 0.5f) * 2f
            delay[i] = next() * 0.12f
            tone[i] = next()
            stretch[i] = 1.5f + next() * 0.8f
        }
    }
}

private fun smooth(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

private fun easeOut(x: Float): Float {
    val t = 1f - x.coerceIn(0f, 1f)
    return 1f - t * t * t
}

/** Draws one frame of the burst centred on the card centre. [progress] 0..1. Safe to call with progress <= 0. */
fun DrawScope.drawSmokeBurst(progress: Float, base: Color, field: SmokeField) {
    if (progress <= 0f || progress >= 1f) return
    val cx = size.width / 2f
    val cy = size.height / 2f
    // reach: wisps travel mostly sideways (cards are wide) but also above and below the card
    val reachX = size.width * 0.46f
    val reachY = size.height * 1.15f
    val unit = size.height * 0.62f
    val pale = lerp(base, Color(0xFFE8D8C4), 0.14f)
    val deep = lerp(base, Color.Black, 0.25f)

    // dense core: briefly obscures the card centre, then thins
    run {
        val coreIn = smooth(progress / 0.22f)
        val coreOut = 1f - smooth((progress - 0.35f) / 0.5f)
        val a = 0.62f * coreIn * coreOut
        if (a > 0.01f) {
            val r = unit * (0.9f + 1.4f * easeOut(progress))
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(lerp(base, pale, 0.4f).copy(alpha = a), base.copy(alpha = a * 0.55f), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = r,
                ),
                radius = r,
                center = Offset(cx, cy),
            )
        }
    }

    for (i in 0 until field.count) {
        val t = ((progress - field.delay[i]) / (1f - field.delay[i])).coerceIn(0f, 1f)
        if (t <= 0f) continue
        val dirX = cos(field.angle[i])
        val dirY = sin(field.angle[i])
        val fadeIn = smooth(t / 0.12f)
        val fadeOut = 1f - smooth((t - 0.30f) / 0.70f)
        val alpha = 0.50f * fadeIn * fadeOut
        if (alpha < 0.012f) continue
        val color = lerp(lerp(deep, base, field.tone[i]), pale, field.tone[i] * 0.35f)
        // a trail of soft blobs along a curved path: the perpendicular curl grows with distance, plus a slow upward drift
        val trail = 3
        for (k in 0 until trail) {
            val lag = k / trail.toFloat() * 0.34f
            val tt = (t - lag).coerceAtLeast(0f)
            val tr = easeOut(tt) * field.speed[i]
            val bx = dirX * tr - dirY * field.curl[i] * 0.9f * tr * tr
            val by = dirY * tr + dirX * field.curl[i] * 0.9f * tr * tr - 0.35f * tt * tt
            val px = cx + bx * reachX
            val py = cy + by * reachY
            val grow = 0.55f + 0.9f * easeOut(tt)
            val r = unit * (0.26f + 0.34f * field.size[i]) * grow * (1f - k * 0.18f)
            val a = alpha * (1f - k * 0.28f)
            // stretch each blob along its direction of travel so the puffs read as wisps / streaks, not discs
            val heading = atan2(by * reachY, bx * reachX) * (180f / PI.toFloat())
            val c = Offset(px, py)
            withTransform({
                rotate(heading, c)
                scale(field.stretch[i] - k * 0.2f, 0.74f, c)
            }) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(color.copy(alpha = a), color.copy(alpha = a * 0.45f), Color.Transparent),
                        center = c,
                        radius = r,
                    ),
                    radius = r,
                    center = c,
                )
            }
        }
    }
}
