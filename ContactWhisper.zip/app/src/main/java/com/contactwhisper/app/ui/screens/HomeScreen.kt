package com.contactwhisper.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.dsa.SortMode
import com.contactwhisper.app.ui.components.CWIcon
import com.contactwhisper.app.ui.components.CWIconButton
import com.contactwhisper.app.ui.components.ContactActions
import com.contactwhisper.app.ui.components.ContactCard
import com.contactwhisper.app.ui.components.EmptyState
import com.contactwhisper.app.ui.components.GearIcon
import com.contactwhisper.app.ui.components.PanelCard
import com.contactwhisper.app.ui.components.ProfileAvatar
import com.contactwhisper.app.ui.components.SmallIconTile
import com.contactwhisper.app.ui.components.bevelOut
import com.contactwhisper.app.ui.components.searchBarSwipeToVoice
import com.contactwhisper.app.ui.theme.CW
import kotlinx.coroutines.delay

/**
 * Home dashboard: profile + Undo / Redo / Settings header, universal search (supplied search + mic icons inside the
 * field), "Contacts" heading with the "Sort by:" dropdown, the Emergency Services panel above the contact list.
 */
@Composable
fun HomeScreen(
    vm: AppViewModel,
    actions: ContactActions,
    onAdd: () -> Unit,
    onSettings: () -> Unit,
    onVoice: () -> Unit,
    onEmergency: () -> Unit,
    onProfile: () -> Unit,
) {
    val c = CW.colors
    val settings by vm.settings.collectAsStateWithLifecycle()
    val contacts by vm.homeList.collectAsStateWithLifecycle()
    val everyone by vm.visibleAll.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val sort by vm.sortMode.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // ---- header: profile (left); Undo, Redo and the Settings gear (right). Compact 40dp targets.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onProfile)
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ProfileAvatar(settings.photoPath, settings.photoVersion, settings.name, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            settings.name.ifBlank { "Contact Whisper" },
                            color = c.ivory,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            if (everyone.size == 1) "1 contact" else "${everyone.size} contacts",
                            color = c.muted,
                            fontSize = 12.sp,
                        )
                    }
                }
                HeaderIcon(R.drawable.ic_undo, "Undo", enabled = history.canUndo) { vm.undo() }
                HeaderIcon(R.drawable.ic_redo, "Redo", enabled = history.canRedo) { vm.redo() }
                IconButton(onClick = onSettings, modifier = Modifier.size(44.dp)) { GearIcon(size = 26.dp) }
            }

            SearchField(query = query, onChange = { vm.query.value = it }, onMic = onVoice)

            // ---- "Contacts" heading + sort dropdown
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Contacts", color = c.ivory, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                SortDropdown(sort) { vm.sortMode.value = it }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item(key = "emergency") { EmergencyPanel(onEmergency) }

                if (contacts.isEmpty()) {
                    item(key = "empty") {
                        if (query.isBlank()) {
                            EmptyState("No contacts yet", "Tap + to add your first contact.")
                        } else {
                            EmptyState("No results", "Nothing matches \"${query.trim()}\". Try part of a name, number, email or category.")
                        }
                    }
                }
                items(contacts, key = { it.id }) { contact ->
                    ContactCard(
                        contact = contact,
                        onOpen = { actions.open(contact) },
                        onEdit = { actions.edit(contact) },
                        onCall = { actions.call(contact) },
                        onDelete = { actions.delete(contact) },
                        onToggleFavorite = { actions.toggleFavorite(contact) },
                        // remaining cards glide into place when one is removed
                        modifier = Modifier.animateItem(),
                    )
                }
            }
        }

        AddButton(onAdd, Modifier.align(Alignment.BottomEnd).padding(16.dp))
    }
}

@Composable
private fun HeaderIcon(icon: Int, label: String, enabled: Boolean, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(40.dp)) {
        CWIcon(icon, label, size = 24.dp, tint = CW.colors.ivory.copy(alpha = if (enabled) 1f else 0.35f))
    }
}

/** The supplied Add icon on a solid, restrained raised button in the theme colour. */
@Composable
private fun AddButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = CW.colors
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier = modifier
            .size(58.dp)
            .clip(shape)
            .background(if (pressed) c.panelPressed else c.panel)
            .border(1.dp, c.accent, shape)
            .bevelOut(16.dp, if (pressed) 1f else 0.6f)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        CWIcon(R.drawable.ic_add, "Add contact", size = 30.dp)
    }
}

/** One universal search box (name, phone, email, address, notes, category): supplied search icon left, mic right. */
@Composable
private fun SearchField(query: String, onChange: (String) -> Unit, onMic: () -> Unit) {
    val c = CW.colors
    val focus: FocusManager = LocalFocusManager.current
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(50.dp)
            .clip(shape)
            .background(c.field)
            .border(1.dp, c.accent.copy(alpha = 0.65f), shape)
            // one-finger left-to-right swipe across the bar opens the voice assistant (observes only, never consumes)
            .searchBarSwipeToVoice(onTrigger = onMic)
            .padding(start = 12.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CWIcon(R.drawable.ic_search, null, size = 22.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (query.isEmpty()) Text("Search contacts", color = c.muted, fontSize = 15.sp, maxLines = 1)
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = c.ivory, fontSize = 15.sp),
                cursorBrush = SolidColor(c.ivory),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (query.isNotEmpty()) {
            CWIconButton(R.drawable.ic_close, "Clear search", { onChange("") }, tint = c.muted, size = 20.dp)
        }
        // opens the voice assistant; the microphone permission is requested only now, when the user taps this
        IconButton(onClick = onMic) { CWIcon(R.drawable.ic_mic, "Voice assistant", size = 24.dp) }
    }
}

/**
 * "Sort by:" (slightly bolder) + current mode + the supplied arrow. The menu is a short popup that appears directly
 * under the control: one separate solid gray card per option with a thin ivory outline, revealed in a quick
 * top-to-bottom cascade. It is a small popup, not a full-screen layer, so it never covers the whole screen.
 */
@Composable
private fun SortDropdown(current: SortMode, onSelect: (SortMode) -> Unit) {
    val c = CW.colors
    var expanded by remember { mutableStateOf(false) }
    var anchorHeight by remember { mutableStateOf(0) }
    val shape = RoundedCornerShape(10.dp)
    Box {
        Row(
            modifier = Modifier
                .onSizeChanged { anchorHeight = it.height }
                .clip(shape)
                .background(c.field)
                .border(1.dp, c.accent.copy(alpha = 0.65f), shape)
                .clickable { expanded = true }
                .padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Sort by:", color = c.ivory, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Text(current.label, color = c.ivory, fontSize = 13.sp, fontWeight = FontWeight.Normal)
            Spacer(Modifier.width(4.dp))
            CWIcon(R.drawable.ic_expand_more, "Change sort order", size = 20.dp, rotation = if (expanded) 180f else 0f)
        }
        if (expanded) {
            val gap = with(LocalDensity.current) { 6.dp.roundToPx() }
            Popup(
                alignment = Alignment.TopEnd,
                offset = IntOffset(0, anchorHeight + gap),
                onDismissRequest = { expanded = false },
                properties = PopupProperties(focusable = true),
            ) {
                Column(
                    modifier = Modifier.widthIn(min = 180.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    SortMode.values().forEachIndexed { index, mode ->
                        CascadeCard(index = index, text = mode.label, selected = mode == current) {
                            expanded = false
                            onSelect(mode)
                        }
                    }
                }
            }
        }
    }
}

/** One option card; appears [index] * 45 ms after the menu opens, sliding down a few dp while fading in. */
@Composable
private fun CascadeCard(index: Int, text: String, selected: Boolean, onClick: () -> Unit) {
    val c = CW.colors
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * 45L)
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(120)) + slideInVertically(tween(140)) { -it / 2 },
    ) {
        val source = remember { MutableInteractionSource() }
        val pressed by source.collectIsPressedAsState()
        val shape = RoundedCornerShape(10.dp)
        Box(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(if (pressed) lerp(c.field, c.ivory, 0.10f) else c.field)
                .border(1.dp, c.ivory.copy(alpha = 0.75f), shape)
                .bevelOut(10.dp, if (pressed) 0.8f else 0f)
                .clickable(interactionSource = source, indication = null, onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            Text(
                text,
                color = c.ivory,
                fontSize = 14.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            )
        }
    }
}

/** Always sits above the ordinary contacts. It is an emergency-services shortcut, not a recent-calls list. */
@Composable
private fun EmergencyPanel(onClick: () -> Unit) {
    val c = CW.colors
    PanelCard(onClick = onClick) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SmallIconTile(R.drawable.ic_emergency)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Emergency Services", color = c.ivory, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Police, Ambulance, Fire & more", color = c.muted, fontSize = 12.sp)
            }
            CWIcon(R.drawable.ic_chevron_right, null, size = 16.dp)
        }
    }
}
