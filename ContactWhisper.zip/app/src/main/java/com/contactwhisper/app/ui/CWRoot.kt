package com.contactwhisper.app.ui

import android.app.Activity
import android.view.WindowManager
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.draw.alpha
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.auth.AuthController
import com.contactwhisper.app.auth.LocalAuth
import com.contactwhisper.app.ui.components.CWIcon
import com.contactwhisper.app.ui.components.CWSnackbarHost
import com.contactwhisper.app.ui.components.ImportHost
import com.contactwhisper.app.ui.components.LocalCaller
import com.contactwhisper.app.ui.components.rememberCaller
import com.contactwhisper.app.ui.components.ContactActions
import com.contactwhisper.app.ui.components.FullScreenBackground
import com.contactwhisper.app.ui.components.MessageDialog
import com.contactwhisper.app.ui.components.PinEntryDialog
import com.contactwhisper.app.ui.components.twoFingerUndoRedo
import com.contactwhisper.app.ui.screens.AboutScreen
import com.contactwhisper.app.ui.screens.AppLockScreen
import com.contactwhisper.app.ui.screens.AppearanceScreen
import com.contactwhisper.app.ui.screens.BinScreen
import com.contactwhisper.app.ui.screens.CategoriesScreen
import com.contactwhisper.app.ui.screens.ContactDetailsScreen
import com.contactwhisper.app.ui.screens.ContactFormScreen
import com.contactwhisper.app.ui.screens.EmergencyScreen
import com.contactwhisper.app.ui.screens.FavoritesScreen
import com.contactwhisper.app.ui.screens.HomeScreen
import com.contactwhisper.app.ui.screens.LockScreen
import com.contactwhisper.app.ui.screens.ProfileScreen
import com.contactwhisper.app.ui.screens.ProfileSetupScreen
import com.contactwhisper.app.ui.screens.SettingsScreen
import com.contactwhisper.app.ui.screens.SplashScreen
import com.contactwhisper.app.ui.voice.VoiceHost
import com.contactwhisper.app.ui.theme.CW
import com.contactwhisper.app.ui.theme.ContactWhisperTheme
import com.contactwhisper.app.voice.VoiceScreen

/**
 * Root of the UI: theme, App Lock gate, snackbar host, bottom navigation (exactly 4 tabs) and the NavHost.
 * The theme is read from persisted settings, so switching it recolours every screen without touching navigation or data.
 */
@Composable
fun CWRoot(vm: AppViewModel, auth: AuthController, lifecycle: Lifecycle) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val appUnlocked by vm.appUnlocked.collectAsStateWithLifecycle()
    val initError by vm.initError.collectAsStateWithLifecycle()

    // AuthController (not a Compose object) reads the latest lock settings from here.
    SideEffect { auth.settings = settings }

    // Keep contacts out of screenshots and the recent-apps thumbnail while App Lock is on.
    val activity = LocalContext.current as? Activity
    val secure = settings.appLockEnabled
    SideEffect {
        val window = activity?.window
        if (window != null) {
            if (secure) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    // Hoisted above the lock gate so the back stack survives a re-lock.
    val navController = rememberNavController()

    val caller = rememberCaller(vm)

    ContactWhisperTheme(settings.theme) {
        CompositionLocalProvider(LocalAuth provides auth, LocalCaller provides caller) {
            FullScreenBackground {
                val locked = settings.loaded && settings.appLockEnabled && !appUnlocked
                if (locked) {
                    LockScreen(vm, lifecycle)
                } else {
                    AppScaffold(vm, navController)
                }

                auth.pinPrompt?.let { prompt ->
                    PinEntryDialog(
                        title = prompt.title,
                        verify = vm::verifyPin,
                        onSuccess = { auth.finishPin(true) },
                        onCancel = { auth.finishPin(false) },
                    )
                }
                initError?.let { message ->
                    MessageDialog(
                        title = "Storage problem",
                        text = "ContactWhisper couldn't open its local database: $message",
                        onDismiss = vm::clearInitError,
                    )
                }
            }
        }
    }
}

private class TabSpec(val route: String, val label: String, val icon: Int)

private val tabSpecs = listOf(
    TabSpec(Routes.HOME, "Home", R.drawable.ic_home),
    TabSpec(Routes.CATEGORIES, "Categories", R.drawable.ic_category),
    TabSpec(Routes.FAVORITES, "Favorites", R.drawable.ic_star),
    TabSpec(Routes.BIN, "Bin", R.drawable.ic_delete),
)

private fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(Routes.HOME) { inclusive = false }
        launchSingleTop = true
    }
}

@Composable
private fun AppScaffold(vm: AppViewModel, nav: NavHostController) {
    val c = CW.colors
    val settings by vm.settings.collectAsStateWithLifecycle()

    val backStackEntry by nav.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route

    // First launch only: after the profile exists and Home is showing, offer the phonebook import (once).
    LaunchedEffect(settings.loaded, settings.profileDone, settings.contactImport, route) {
        if (route != null && route in Routes.tabs) vm.offerFirstLaunchImport()
    }

    val onUndo = remember(vm) { { vm.undo() } }
    val onRedo = remember(vm) { { vm.redo() } }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = c.background,
            bottomBar = {
                if (route != null && route in Routes.tabs) {
                    NavigationBar(containerColor = c.surface, contentColor = c.ivory) {
                        tabSpecs.forEach { tab ->
                            val selected = route == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { nav.goTab(tab.route) },
                                icon = { CWIcon(tab.icon, tab.label, size = 26.dp, modifier = Modifier.alpha(if (selected) 1f else 0.6f)) },
                                label = { Text(tab.label, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = c.ivory,
                                    selectedTextColor = c.ivory,
                                    unselectedIconColor = c.muted,
                                    unselectedTextColor = c.muted,
                                    indicatorColor = c.panel,
                                ),
                            )
                        }
                    }
                }
            },
        ) { padding ->
            Box(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .twoFingerUndoRedo(onUndo, onRedo),
            ) {
                AppNavHost(vm, nav)
                // Notifications sit above the bottom bar and never cover the whole screen.
                CWSnackbarHost(vm.events, Modifier.align(Alignment.BottomCenter))
            }
        }
        ImportHost(vm)
        // Voice assistant: continuous session (listening panel + follow-up overlay) above everything.
        VoiceHost(
            vm = vm,
            onNavigate = { screen -> nav.voiceNavigate(screen) },
            onBack = { if (!nav.popBackStack()) nav.goTab(Routes.HOME) },
            onOpenDetails = { id -> nav.navigate(Routes.details(id)) { launchSingleTop = true } },
        )
    }
}

private fun NavHostController.voiceNavigate(screen: VoiceScreen) {
    when (screen) {
        VoiceScreen.HOME -> goTab(Routes.HOME)
        VoiceScreen.CATEGORIES -> goTab(Routes.CATEGORIES)
        VoiceScreen.FAVORITES -> goTab(Routes.FAVORITES)
        VoiceScreen.BIN -> goTab(Routes.BIN)
        VoiceScreen.EMERGENCY -> navigate(Routes.EMERGENCY) { launchSingleTop = true }
        VoiceScreen.SETTINGS -> navigate(Routes.SETTINGS) { launchSingleTop = true }
        VoiceScreen.PROFILE -> navigate(Routes.PROFILE) { launchSingleTop = true }
        VoiceScreen.APPEARANCE -> navigate(Routes.APPEARANCE) { launchSingleTop = true }
        VoiceScreen.ABOUT -> navigate(Routes.ABOUT) { launchSingleTop = true }
    }
}

@Composable
private fun rememberContactActions(vm: AppViewModel, nav: NavHostController): ContactActions {
    val caller = LocalCaller.current
    return remember(vm, nav, caller) {
        ContactActions(
            open = { nav.navigate(Routes.details(it.id)) { launchSingleTop = true } },
            edit = { nav.navigate(Routes.form(it.id)) { launchSingleTop = true } },
            call = { caller.call(it.phone, false) },
            delete = { vm.deleteContact(it.id) },
            toggleFavorite = { vm.toggleFavorite(it) },
        )
    }
}

@Composable
private fun AppNavHost(vm: AppViewModel, nav: NavHostController) {
    val caller = LocalCaller.current
    val actions = rememberContactActions(vm, nav)
    val idArg = listOf(navArgument("id") { type = NavType.LongType })

    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        enterTransition = { fadeIn(tween(140)) },
        exitTransition = { fadeOut(tween(100)) },
        popEnterTransition = { fadeIn(tween(140)) },
        popExitTransition = { fadeOut(tween(100)) },
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(vm) { profileDone ->
                nav.navigate(if (profileDone) Routes.HOME else Routes.SETUP) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            }
        }
        composable(Routes.SETUP) {
            FullScreenBackground {
                ProfileSetupScreen(vm) {
                    nav.navigate(Routes.HOME) { popUpTo(Routes.SETUP) { inclusive = true } }
                }
            }
        }

        // ---- the four bottom-navigation destinations
        composable(Routes.HOME) {
            FullScreenBackground {
                HomeScreen(
                    vm = vm,
                    actions = actions,
                    onAdd = { nav.navigate(Routes.form(Routes.NEW_CONTACT)) { launchSingleTop = true } },
                    onSettings = { nav.navigate(Routes.SETTINGS) { launchSingleTop = true } },
                    onVoice = { vm.voice.open() },
                    onEmergency = { nav.navigate(Routes.EMERGENCY) { launchSingleTop = true } },
                    onProfile = { nav.navigate(Routes.PROFILE) { launchSingleTop = true } },
                )
            }
        }
        composable(Routes.CATEGORIES) { FullScreenBackground { CategoriesScreen(vm, actions) } }
        composable(Routes.FAVORITES) { FullScreenBackground { FavoritesScreen(vm, actions) } }
        composable(Routes.BIN) { FullScreenBackground { BinScreen(vm, onBack = { nav.goTab(Routes.HOME) }) } }

        // ---- contacts
        composable(Routes.DETAILS, arguments = idArg) { entry ->
            val id = entry.arguments?.getLong("id") ?: Routes.NEW_CONTACT
            FullScreenBackground {
                ContactDetailsScreen(
                    vm = vm,
                    contactId = id,
                    onBack = { nav.popBackStack() },
                    onEdit = { nav.navigate(Routes.form(id)) { launchSingleTop = true } },
                    onCall = { number -> caller.call(number, false) },
                )
            }
        }
        composable(Routes.FORM, arguments = idArg) { entry ->
            val id = entry.arguments?.getLong("id") ?: Routes.NEW_CONTACT
            FullScreenBackground {
                ContactFormScreen(vm = vm, editId = id, onBack = { nav.popBackStack() })
            }
        }
        composable(Routes.EMERGENCY) {
            FullScreenBackground {
                EmergencyScreen(vm, onBack = { nav.popBackStack() })
            }
        }

        // ---- settings area
        composable(Routes.SETTINGS) {
            FullScreenBackground {
                SettingsScreen(
                    onBack = { nav.popBackStack() },
                    onOpen = { route -> nav.navigate(route) { launchSingleTop = true } },
                )
            }
        }
        composable(Routes.PROFILE) { FullScreenBackground { ProfileScreen(vm) { nav.popBackStack() } } }
        composable(Routes.APPEARANCE) { FullScreenBackground { AppearanceScreen(vm) { nav.popBackStack() } } }
        composable(Routes.APP_LOCK) { FullScreenBackground { AppLockScreen(vm) { nav.popBackStack() } } }
        composable(Routes.ABOUT) { FullScreenBackground { AboutScreen { nav.popBackStack() } } }
    }
}
