package com.contactwhisper.app.dsa;

import java.util.Comparator;
import java.util.Locale;

/**
 * Searching, sorting and text-normalisation algorithms used by the domain layer.
 *
 * Complexity (n = contacts, m = longest field length):
 *  - search            : O(n * m) single linear pass over the linked list; each field is checked with the custom
 *                        containsIgnoreCase scan (no String.contains)
 *  - mergeSort         : O(n log n) time, O(n) extra space, STABLE (equal keys keep their relative order)
 *  - normalizePhone    : O(m)
 *
 * Why merge sort: it is stable, has a guaranteed O(n log n) bound (no bad pivot case), and is the
 * natural algorithm for linked data. All four sort modes are the same algorithm with a different comparator.
 */
public final class ContactAlgorithms {
    private ContactAlgorithms() {
    }

    // ------------------------------------------------------------------ normalisation

    /** Keeps only the digits of a phone number: "+92 (300) 123-4567" -> "923001234567". */
    public static String normalizePhone(String phone) {
        if (phone == null) return "";
        StringBuilder sb = new StringBuilder(phone.length());
        for (int i = 0; i < phone.length(); i++) {
            char c = phone.charAt(i);
            if (c >= '0' && c <= '9') sb.append(c);
        }
        return sb.toString();
    }

    /**
     * Key used to compare phone numbers for duplicate detection and hashing: the digits, trimmed to the
     * last 10 so "0300 1234567" and "+92 300 1234567" collide. Shorter numbers (e.g. 112) compare in full.
     */
    public static String phoneKey(String phone) {
        String digits = normalizePhone(phone);
        return digits.length() > 10 ? digits.substring(digits.length() - 10) : digits;
    }

    public static String emailKey(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }

    /** Lower-cases, trims and collapses inner whitespace. */
    public static String nameKey(String name) {
        if (name == null) return "";
        return name.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    // ------------------------------------------------------------------ searching

    /** True when the (already trimmed) query matches any searchable field of the record. */
    public static boolean matches(ContactRecord r, String query) {
        if (query == null) return true;
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return true;
        if (contains(r.getName(), q) || contains(r.getEmail(), q) || contains(r.getAddress(), q)
                || contains(r.getNotes(), q) || contains(r.getCategory(), q) || contains(r.getPhone(), q)) {
            return true;
        }
        String digitsQuery = normalizePhone(q);
        return !digitsQuery.isEmpty() && containsIgnoreCase(normalizePhone(r.getPhone()), digitsQuery);
    }

    private static boolean contains(String field, String lowerQuery) {
        return field != null && containsIgnoreCase(field, lowerQuery);
    }

    /**
     * Custom substring search (naive left-to-right scan, no String.contains): true when {@code lowerPattern}
     * occurs anywhere in {@code text}, ignoring case. {@code lowerPattern} must already be lower-case.
     * O(n * m) worst case for text length n and pattern length m; practically near O(n) on contact-sized fields.
     */
    public static boolean containsIgnoreCase(String text, String lowerPattern) {
        int n = text.length();
        int m = lowerPattern.length();
        if (m == 0) return true;
        for (int i = 0; i + m <= n; i++) {
            int j = 0;
            while (j < m && Character.toLowerCase(text.charAt(i + j)) == lowerPattern.charAt(j)) j++;
            if (j == m) return true;
        }
        return false;
    }

    /**
     * Universal search: one pass over the linked list, matching name, phone (digits-normalised),
     * email, address, notes and category.
     * Results keep list order; sort them afterwards with {@link #sort}.
     */
    public static ContactRecord[] search(ContactLinkedList list, String query) {
        ContactRecord[] buffer = new ContactRecord[list.size()];
        int count = 0;
        for (ContactRecord r : list) {
            if (matches(r, query)) buffer[count++] = r;
        }
        ContactRecord[] out = new ContactRecord[count];
        System.arraycopy(buffer, 0, out, 0, count);
        return out;
    }

    // ------------------------------------------------------------------ sorting

    private static int compareText(String a, String b) {
        return a.compareToIgnoreCase(b);
    }

    private static int compareIdAsc(ContactRecord a, ContactRecord b) {
        return Long.compare(a.getId(), b.getId());
    }

    /** A–Z by name, case-insensitive; id breaks ties so the order is fully deterministic. */
    public static final Comparator<ContactRecord> NAME_ASC = (a, b) -> {
        int c = compareText(a.getName(), b.getName());
        return c != 0 ? c : compareIdAsc(a, b);
    };

    /** Z–A is exactly the reverse of A–Z, including the tie-break. */
    public static final Comparator<ContactRecord> NAME_DESC = (a, b) -> NAME_ASC.compare(b, a);

    /** Newest first by creation timestamp; ties fall back to the higher id (inserted later). */
    public static final Comparator<ContactRecord> NEWEST_FIRST = (a, b) -> {
        int c = Long.compare(b.getCreatedAt(), a.getCreatedAt());
        return c != 0 ? c : Long.compare(b.getId(), a.getId());
    };

    /** Category name (uncategorised last), then name, then id. */
    public static final Comparator<ContactRecord> CATEGORY_THEN_NAME = (a, b) -> {
        boolean aEmpty = a.getCategory().isEmpty();
        boolean bEmpty = b.getCategory().isEmpty();
        if (aEmpty != bEmpty) return aEmpty ? 1 : -1;
        int c = compareText(a.getCategory(), b.getCategory());
        return c != 0 ? c : NAME_ASC.compare(a, b);
    };

    public static Comparator<ContactRecord> comparatorFor(SortMode mode) {
        switch (mode) {
            case Z_A: return NAME_DESC;
            case RECENTLY_ADDED: return NEWEST_FIRST;
            case BY_CATEGORY: return CATEGORY_THEN_NAME;
            case A_Z:
            default: return NAME_ASC;
        }
    }

    public static ContactRecord[] sort(ContactRecord[] input, SortMode mode) {
        return mergeSort(input, comparatorFor(mode));
    }

    /** Top-down merge sort. Returns a NEW sorted array; the input is not modified. */
    public static ContactRecord[] mergeSort(ContactRecord[] input, Comparator<ContactRecord> cmp) {
        ContactRecord[] work = input.clone();
        if (work.length < 2) return work;
        ContactRecord[] scratch = new ContactRecord[work.length];
        mergeSortRange(work, scratch, 0, work.length, cmp);
        return work;
    }

    private static void mergeSortRange(ContactRecord[] a, ContactRecord[] tmp, int from, int to,
                                       Comparator<ContactRecord> cmp) {
        if (to - from < 2) return;
        int mid = (from + to) >>> 1;
        mergeSortRange(a, tmp, from, mid, cmp);
        mergeSortRange(a, tmp, mid, to, cmp);
        int i = from, j = mid, k = from;
        while (i < mid && j < to) {
            // <= keeps the sort stable: on ties the left element goes first
            if (cmp.compare(a[i], a[j]) <= 0) tmp[k++] = a[i++]; else tmp[k++] = a[j++];
        }
        while (i < mid) tmp[k++] = a[i++];
        while (j < to) tmp[k++] = a[j++];
        System.arraycopy(tmp, from, a, from, to - from);
    }
}
