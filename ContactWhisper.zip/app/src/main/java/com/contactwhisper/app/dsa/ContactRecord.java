package com.contactwhisper.app.dsa;

import java.util.Objects;

/**
 * Immutable in-memory view of one ACTIVE contact. Room is the durable source of truth;
 * instances of this class are what the custom DSA structures store.
 *
 * The identifier is a stable numeric id (never the name).
 * Optional text fields are never null: "no value" is the empty string.
 */
public final class ContactRecord {
    private final long id;
    private final String name;
    private final String phone;
    private final String email;
    private final String address;
    private final String notes;
    private final String category;
    private final boolean favorite;
    private final long createdAt;
    private final long updatedAt;

    public ContactRecord(long id, String name, String phone, String email, String address,
                         String notes, String category, boolean favorite,
                         long createdAt, long updatedAt) {
        this.id = id;
        this.name = nz(name);
        this.phone = nz(phone);
        this.email = nz(email);
        this.address = nz(address);
        this.notes = nz(notes);
        this.category = nz(category);
        this.favorite = favorite;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public String getAddress() { return address; }
    public String getNotes() { return notes; }
    public String getCategory() { return category; }
    public boolean isFavorite() { return favorite; }
    public long getCreatedAt() { return createdAt; }
    public long getUpdatedAt() { return updatedAt; }

    // ---- "wither" helpers: records are immutable, edits produce a new record ----

    public ContactRecord withId(long newId) {
        return new ContactRecord(newId, name, phone, email, address, notes, category, favorite, createdAt, updatedAt);
    }

    public ContactRecord withFavorite(boolean value) {
        return new ContactRecord(id, name, phone, email, address, notes, category, value, createdAt, updatedAt);
    }

    public ContactRecord withCategory(String value) {
        return new ContactRecord(id, name, phone, email, address, notes, value, favorite, createdAt, updatedAt);
    }

    public ContactRecord withUpdatedAt(long value) {
        return new ContactRecord(id, name, phone, email, address, notes, category, favorite, createdAt, value);
    }

    /** Replaces the user-editable text fields, keeping id, favorite flag and createdAt. */
    public ContactRecord withDetails(String newName, String newPhone, String newEmail, String newAddress,
                                     String newNotes, String newCategory, long newUpdatedAt) {
        return new ContactRecord(id, newName, newPhone, newEmail, newAddress, newNotes, newCategory,
                favorite, createdAt, newUpdatedAt);
    }

    /** True when only the category differs from {@code other} (used to label undo actions). */
    public boolean differsOnlyInCategory(ContactRecord other) {
        return other != null
                && id == other.id
                && !category.equals(other.category)
                && name.equals(other.name) && phone.equals(other.phone) && email.equals(other.email)
                && address.equals(other.address) && notes.equals(other.notes)
                && favorite == other.favorite;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ContactRecord)) return false;
        ContactRecord r = (ContactRecord) o;
        return id == r.id && favorite == r.favorite
                && createdAt == r.createdAt && updatedAt == r.updatedAt
                && name.equals(r.name) && phone.equals(r.phone) && email.equals(r.email)
                && address.equals(r.address) && notes.equals(r.notes) && category.equals(r.category);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, phone, email, address, notes, category, favorite, createdAt, updatedAt);
    }

    @Override
    public String toString() {
        return "ContactRecord{id=" + id + ", name='" + name + "'}";
    }
}
