package com.contactwhisper.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.BinEntry
import com.contactwhisper.app.R
import com.contactwhisper.app.data.ContactRepository
import com.contactwhisper.app.ui.components.CWButton
import com.contactwhisper.app.ui.components.CWIconButton
import com.contactwhisper.app.ui.components.CWTextButton
import com.contactwhisper.app.ui.components.ConfirmDialog
import com.contactwhisper.app.ui.components.EmptyState
import com.contactwhisper.app.ui.components.MessageDialog
import com.contactwhisper.app.ui.components.PanelCard
import com.contactwhisper.app.ui.components.ScreenHeader
import com.contactwhisper.app.ui.components.formatDate
import com.contactwhisper.app.ui.theme.CW

private enum class BinConfirm { DELETE_SELECTED, DELETE_ALL, DELETE_ONE }

/**
 * Bin: deleted contacts AND deleted Emergency Services entries stay here for 30 days. Restoring an Emergency entry
 * returns it to the Emergency list. Restore never creates a duplicate. Permanent deletion always needs a confirmation
 * and erases the entry from storage, the search index and the Undo/Redo history.
 * The selection lives in the ViewModel so the voice assistant can drive the same screen.
 */
@Composable
fun BinScreen(vm: AppViewModel, onBack: () -> Unit) {
    val c = CW.colors
    val bin by vm.binEntries.collectAsStateWithLifecycle()
    val selected by vm.binSelection.collectAsStateWithLifecycle()
    val report by vm.binReport.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf<BinConfirm?>(null) }
    var single by remember { mutableStateOf<BinEntry?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = "Bin", onBack = onBack)

        if (bin.isEmpty()) {
            EmptyState(
                title = "Bin is empty",
                message = "Deleted items will appear here.",
                icon = R.drawable.ic_delete,
                modifier = Modifier.weight(1f),
            )
        } else {
            val allSelected = selected.size == bin.size
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CWTextButton(if (allSelected) "Clear selection" else "Select All", {
                    if (allSelected) vm.clearBinSelection() else vm.selectAllBin()
                })
                Spacer(Modifier.weight(1f))
                CWTextButton("Restore All", { vm.restoreEntries(bin.map { it.key }) })
                CWTextButton("Delete All", { confirm = BinConfirm.DELETE_ALL }, danger = true)
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(bin, key = { it.key }) { entry ->
                    BinRow(
                        entry = entry,
                        checked = entry.key in selected,
                        onToggle = { vm.toggleBinSelection(entry.key) },
                        onRestore = { vm.restoreEntry(entry) },
                        onDelete = {
                            single = entry
                            confirm = BinConfirm.DELETE_ONE
                        },
                        modifier = Modifier.animateItem(),
                    )
                }
            }

            if (selected.isNotEmpty()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    CWButton("Restore Selected", { vm.restoreEntries(selected.toList()) }, Modifier.weight(1f))
                    CWButton(
                        "Delete Selected Permanently",
                        { confirm = BinConfirm.DELETE_SELECTED },
                        Modifier.weight(1f),
                        danger = true,
                    )
                }
            }
        }
    }

    when (confirm) {
        BinConfirm.DELETE_SELECTED -> ConfirmDialog(
            title = "Delete permanently?",
            text = "${selected.size} item(s) will be deleted forever. This can't be undone.",
            confirmLabel = "Delete forever",
            danger = true,
            onConfirm = {
                confirm = null
                vm.deleteForever(selected.toList())
            },
            onDismiss = { confirm = null },
        )
        BinConfirm.DELETE_ALL -> ConfirmDialog(
            title = "Empty the Bin?",
            text = "All ${bin.size} item(s) in the Bin will be deleted forever. This can't be undone.",
            confirmLabel = "Delete All",
            danger = true,
            onConfirm = {
                confirm = null
                vm.deleteForever(bin.map { it.key })
            },
            onDismiss = { confirm = null },
        )
        BinConfirm.DELETE_ONE -> ConfirmDialog(
            title = "Delete permanently?",
            text = "\"${single?.name.orEmpty()}\" will be deleted forever. This can't be undone.",
            confirmLabel = "Delete forever",
            danger = true,
            onConfirm = {
                val key = single?.key
                confirm = null
                single = null
                if (key != null) vm.deleteForever(listOf(key))
            },
            onDismiss = {
                confirm = null
                single = null
            },
        )
        null -> Unit
    }

    report?.let { (title, text) ->
        MessageDialog(title = title, text = text, onDismiss = vm::dismissBinReport)
    }
}

@Composable
private fun BinRow(
    entry: BinEntry,
    checked: Boolean,
    onToggle: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = CW.colors
    val daysLeft = ContactRepository.daysLeft(entry.deletedAt)
    PanelCard(modifier = modifier, onClick = onToggle, selected = checked) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Checkbox(
                checked = checked,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(
                    checkedColor = c.accent,
                    uncheckedColor = c.muted,
                    checkmarkColor = c.ivory,
                ),
            )
            Column(Modifier.weight(1f)) {
                Text(
                    entry.name,
                    color = c.ivory,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    if (entry.isEmergency) "Emergency · ${entry.detail}" else entry.detail,
                    color = c.muted,
                    fontSize = 13.sp,
                    maxLines = 1,
                )
                Text(
                    "Deleted ${formatDate(entry.deletedAt)} · ${if (daysLeft == 1) "1 day left" else "$daysLeft days left"}",
                    color = c.muted,
                    fontSize = 11.sp,
                )
            }
            Spacer(Modifier.width(4.dp))
            CWIconButton(R.drawable.ic_restore, "Restore ${entry.name}", onRestore)
            CWIconButton(R.drawable.ic_delete, "Delete ${entry.name} permanently", onDelete, tint = c.danger)
        }
    }
}
