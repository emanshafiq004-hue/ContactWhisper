package com.contactwhisper.app

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.contactwhisper.app.data.AppSettings
import com.contactwhisper.app.data.AppTheme
import com.contactwhisper.app.data.CategoryEntity
import com.contactwhisper.app.data.CategoryResult
import com.contactwhisper.app.data.ContactDraft
import com.contactwhisper.app.data.ContactEntity
import com.contactwhisper.app.data.DeviceContactReader
import com.contactwhisper.app.data.EmergencyEntity
import com.contactwhisper.app.data.HistoryState
import com.contactwhisper.app.data.ImportSummary
import com.contactwhisper.app.data.LockMethod
import com.contactwhisper.app.data.RestoreResult
import com.contactwhisper.app.domain.ContactValidator
import com.contactwhisper.app.dsa.ContactRecord
import com.contactwhisper.app.dsa.DuplicateMatch
import com.contactwhisper.app.dsa.SortMode
import com.contactwhisper.app.util.saveProfilePhoto
import com.contactwhisper.app.voice.ActionRequest
import com.contactwhisper.app.voice.VoiceAssistant
import com.contactwhisper.app.voice.VoiceBackend
import com.contactwhisper.app.voice.VoiceBin
import com.contactwhisper.app.voice.VoiceResult
import com.contactwhisper.app.voice.VoiceEmergency
import com.contactwhisper.app.voice.EmergencyField
import com.contactwhisper.app.voice.toDraft
import com.contactwhisper.app.voice.withField
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.cancellation.CancellationException

/** One-shot message for the app-wide snackbar (optionally with an action such as "Undo"). */
data class SnackEvent(
    val message: String,
    val actionLabel: String? = null,
    val onAction: (() -> Unit)? = null,
)

/**
 * One row of the Recycle Bin. Personal contacts and Emergency Services entries share the Bin; the [key] keeps the two
 * id spaces apart, and [isEmergency] makes a restore go back to the Emergency Services list.
 */
sealed interface BinEntry {
    val key: String
    val name: String
    val detail: String
    val deletedAt: Long
    val isEmergency: Boolean

    data class Contact(val entity: ContactEntity) : BinEntry {
        override val key get() = "c:${entity.id}"
        override val name get() = entity.name
        override val detail get() = entity.phone
        override val deletedAt get() = entity.deletedAt ?: 0L
        override val isEmergency get() = false
    }

    data class Emergency(val entity: EmergencyEntity) : BinEntry {
        override val key get() = "e:${entity.id}"
        override val name get() = entity.name
        override val detail get() = entity.number
        override val deletedAt get() = entity.deletedAt ?: 0L
        override val isEmergency get() = true
    }
}

/** State of the phonebook import dialogs (first launch, or "Import phone contacts" in Profile Customization). */
sealed interface ImportUi {
    data object Idle : ImportUi
    /** Explain why READ_CONTACTS is needed, then ask for it. */
    data object Explain : ImportUi
    data object Running : ImportUi
    data class Summary(val summary: ImportSummary) : ImportUi
    /** Permission refused: the app stays fully usable; the message says how to import later. */
    data object Denied : ImportUi
    data class Failed(val message: String) : ImportUi
}

/**
 * UI state holder. All Room work happens in [com.contactwhisper.app.data.ContactRepository] on Dispatchers.IO;
 * list building (which uses the custom Java linked list / merge sort) is moved off the main thread with flowOn.
 *
 * Lock policy: App Lock (if enabled) is locked on a cold start and re-locks when the app has been in the background
 * for [RELOCK_AFTER_MS] or more.
 */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as ContactWhisperApp).container
    private val repo = container.contacts
    private val emergencyRepo = container.emergency
    private val settingsStore = container.settings
    private val appContext = application.applicationContext

    // ------------------------------------------------------------------ startup / settings

    val settings: StateFlow<AppSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _initError = MutableStateFlow<String?>(null)
    val initError: StateFlow<String?> = _initError.asStateFlow()

    // ------------------------------------------------------------------ lock state

    val appUnlocked = MutableStateFlow(false)
    private var backgroundedAt = 0L

    // ------------------------------------------------------------------ UI state shared by screens

    val query = MutableStateFlow("")
    val sortMode = MutableStateFlow(SortMode.A_Z)

    /** Expanded rows on the Categories screen (kept here so the voice assistant can expand / collapse them too). */
    val expandedCategories = MutableStateFlow<Set<String>>(emptySet())

    private val _events = MutableSharedFlow<SnackEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<SnackEvent> = _events.asSharedFlow()

    val history: StateFlow<HistoryState> = repo.history

    /** Home list: universal search + chosen sort, computed by the custom Java structures. */
    val homeList: StateFlow<List<ContactRecord>> =
        combine(repo.contacts, query, sortMode) { _, q, mode -> repo.search(q, mode) }
            .flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Every active contact (A-Z). Backs details/edit lookups, Favorites and Categories. */
    val visibleAll: StateFlow<List<ContactRecord>> =
        repo.contacts.map { repo.search("", SortMode.A_Z) }
            .flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val favorites: StateFlow<List<ContactRecord>> =
        visibleAll.map { list -> list.filter { it.isFavorite } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val categories: StateFlow<List<CategoryEntity>> =
        repo.categories.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val emergencyEntries: StateFlow<List<EmergencyEntity>> =
        emergencyRepo.entries.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ------------------------------------------------------------------ recycle bin (contacts + emergency entries)

    /** Newest deletion first. */
    val binEntries: StateFlow<List<BinEntry>> =
        combine(repo.binItems, emergencyRepo.binItems) { contacts, emergency ->
            (contacts.map { BinEntry.Contact(it) } + emergency.map { BinEntry.Emergency(it) })
                .sortedByDescending { it.deletedAt }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _binSelection = MutableStateFlow<Set<String>>(emptySet())
    val binSelection: StateFlow<Set<String>> = _binSelection.asStateFlow()

    /** Title + text of the "some entries could not be restored" dialog; null when none is showing. */
    private val _binReport = MutableStateFlow<Pair<String, String>?>(null)
    val binReport: StateFlow<Pair<String, String>?> = _binReport.asStateFlow()

    fun dismissBinReport() {
        _binReport.value = null
    }

    init {
        // forget selections for entries that are gone (restored / purged)
        viewModelScope.launch {
            binEntries.collect { list ->
                val keys = list.mapTo(HashSet()) { it.key }
                val kept = _binSelection.value.filterTo(HashSet()) { it in keys }
                if (kept.size != _binSelection.value.size) _binSelection.value = kept
            }
        }
    }

    fun toggleBinSelection(key: String) {
        _binSelection.value = _binSelection.value.let { if (key in it) it - key else it + key }
    }

    fun selectAllBin() {
        _binSelection.value = binEntries.value.mapTo(HashSet()) { it.key }
    }

    fun clearBinSelection() {
        _binSelection.value = emptySet()
    }

    private fun contactIds(keys: Collection<String>) = keys.filter { it.startsWith("c:") }.mapNotNull { it.drop(2).toLongOrNull() }
    private fun emergencyIds(keys: Collection<String>) = keys.filter { it.startsWith("e:") }.mapNotNull { it.drop(2).toLongOrNull() }

    /**
     * Restores Bin entries (contacts go back to the contact list, Emergency entries to the Emergency Services list).
     * A restore is recorded in Undo/Redo by the repository. Returns the message that was shown / should be spoken.
     */
    suspend fun restoreKeys(keys: Collection<String>, announce: Boolean = true): String {
        val cIds = contactIds(keys)
        val eIds = emergencyIds(keys)
        if (cIds.isEmpty() && eIds.isEmpty()) return "Nothing to restore."
        var restored = 0
        var conflicts: List<String> = emptyList()
        if (cIds.isNotEmpty()) {
            val r = repo.restoreAll(cIds)
            restored += r.restored
            conflicts = r.conflictedNames
        }
        if (eIds.isNotEmpty()) restored += emergencyRepo.restoreAll(eIds)
        _binSelection.value = _binSelection.value - keys.toSet()
        val message = when {
            conflicts.isNotEmpty() ->
                "Restored $restored. ${conflicts.joinToString(", ")} stays in the Bin because it matches an existing contact."
            restored == 0 -> "Nothing to restore."
            restored == 1 && cIds.size == 1 -> "Contact restored."
            restored == 1 -> "Entry restored."
            else -> "$restored items restored."
        }
        if (conflicts.isNotEmpty()) {
            if (announce) {
                _binReport.value = "Restore finished" to buildString {
                    append("Restored $restored. ")
                    append("These stay in the Bin because they match an existing contact (same phone number or email): ")
                    append(conflicts.joinToString(", "))
                    append(". Edit or delete the existing contact, then restore again.")
                }
            }
        } else if (announce) {
            snack(message)
        }
        return message
    }

    fun restoreEntries(keys: Collection<String>) = launchSafely { restoreKeys(keys) }

    fun restoreEntry(entry: BinEntry) = launchSafely {
        if (entry is BinEntry.Contact) {
            when (val r = repo.restore(entry.entity.id)) {
                RestoreResult.Restored -> snack("Contact restored.")
                RestoreResult.NotFound -> snack("That contact is no longer in the Bin.")
                is RestoreResult.Conflict -> _binReport.value = "Can't restore ${r.name}" to
                    ("It conflicts with an active contact, so it was not restored (no duplicate is created):\n" +
                        r.matches.joinToString("\n") { "• " + conflictLine(it) } +
                        "\n\nIt stays in the Bin. Edit or delete the existing contact, then restore again.")
            }
        } else {
            restoreKeys(listOf(entry.key))
        }
        _binSelection.value = _binSelection.value - entry.key
    }

    private fun conflictLine(match: DuplicateMatch): String {
        val other = match.existing
        return when (match.reason) {
            DuplicateMatch.Reason.PHONE -> "Same phone number as ${other.name} (${other.phone})"
            DuplicateMatch.Reason.EMAIL -> "Same email address as ${other.name}"
            DuplicateMatch.Reason.NAME -> "Same name as ${other.name}"
        }
    }

    /**
     * IRREVERSIBLE. Callers must have shown an explicit confirmation. Contacts are erased from Room and the DSA index
     * and every Undo/Redo entry mentioning them is purged (see ContactRepository.permanentlyDelete), so no history
     * step can ever bring them back.
     */
    suspend fun deleteKeysForever(keys: Collection<String>): Int {
        val removed = repo.permanentlyDelete(contactIds(keys)) + emergencyRepo.permanentlyDelete(emergencyIds(keys))
        _binSelection.value = _binSelection.value - keys.toSet()
        return removed
    }

    fun deleteForever(keys: Collection<String>) = launchSafely {
        val n = deleteKeysForever(keys)
        snack(if (n == 1) "1 item deleted permanently." else "$n items deleted permanently.")
    }

    // ------------------------------------------------------------------ voice assistant

    /**
     * The voice assistant reads through the same search/lookup functions as the UI and changes data only through
     * [executeVoice], which calls the same repository / ViewModel functions as the touch UI. It has no access to
     * App Lock, the PIN or biometric settings: nothing in this class exposes them to it.
     */
    private val voiceBackend = object : VoiceBackend {
        override fun search(query: String) = repo.search(query, SortMode.A_Z)
        override fun inCategory(category: String) =
            repo.search("", SortMode.A_Z).filter { it.category.equals(category, ignoreCase = true) }
        override fun categoryNames() = categories.value.map { it.name }
        override fun get(id: Long) = repo.getActive(id)
        override fun duplicates(draft: ContactDraft, excludeId: Long) = repo.findDuplicates(draft, excludeId)
        override fun binEntries() = binEntries.value.map { VoiceBin(it.key, it.name, it.isEmergency) }
        override fun binSelection() = _binSelection.value
        override fun emergencyEntries() = emergencyEntries.value.map { VoiceEmergency(it.id, it.name, it.number) }
        override fun profileName() = settings.value.name
        override fun expandedCategories() = expandedCategories.value
    }

    val voice = VoiceAssistant(application, viewModelScope, voiceBackend, ::executeVoice)

    /** Runs one voice request through the same code paths as the touch UI. Nothing is changed when it fails. */
    private suspend fun executeVoice(request: ActionRequest): VoiceResult = when (request) {
        ActionRequest.BinRestoreSelected -> restoreResult(_binSelection.value.toList())
        ActionRequest.BinRestoreAll -> restoreResult(binEntries.value.map { it.key })
        is ActionRequest.BinRestoreOne -> restoreResult(listOf(request.key))
        else -> executeVoiceRaw(request)?.let { VoiceResult.fail(it) } ?: VoiceResult.ok()
    }

    private suspend fun restoreResult(keys: List<String>): VoiceResult {
        val message = restoreKeys(keys)
        return if (message.startsWith("Nothing")) VoiceResult.fail(message) else VoiceResult.ok(message)
    }

    /** Returns null on success, otherwise a message for the assistant. */
    private suspend fun executeVoiceRaw(request: ActionRequest): String? {
        return try {
            when (request) {
                is ActionRequest.MoveToBin -> {
                    val removed = repo.moveToBin(request.id)
                    if (removed == null) {
                        "That contact is no longer available."
                    } else {
                        snack("Contact moved to Bin", "Undo") { undoDelete(request.id) }
                        null
                    }
                }
                is ActionRequest.SaveEdit -> {
                    val current = repo.getActive(request.id)
                    if (current == null) {
                        "That contact is no longer available."
                    } else {
                        val draft = current.toDraft().withField(request.field, request.value)
                        // same rules as the visual form: an untouched stored number stays acceptable
                        val r = ContactValidator.validate(draft.name, draft.phone, draft.email, draft.address, draft.notes, current.phone)
                        if (!r.isValid) {
                            "That value isn't valid, so nothing was changed."
                        } else if (repo.updateContact(request.id, draft) == null) {
                            "That contact is no longer available."
                        } else {
                            snack("Changes saved.")
                            null
                        }
                    }
                }
                is ActionRequest.AddContact -> {
                    val d = request.draft
                    if (!ContactValidator.validate(d.name, d.phone, d.email, d.address, d.notes).isValid) {
                        "Those details aren't valid, so nothing was saved."
                    } else {
                        repo.addContact(d)
                        snack("Contact added.")
                        null
                    }
                }
                is ActionRequest.SetFavorite -> {
                    if (repo.getActive(request.id) == null) {
                        "That contact is no longer available."
                    } else {
                        repo.setFavorite(request.id, request.favorite)
                        null
                    }
                }
                is ActionRequest.ExpandCategory -> {
                    expandedCategories.value = expandedCategories.value.let { if (request.expand) it + request.name else it - request.name }
                    null
                }
                is ActionRequest.CreateCategory -> categoryResultMessage(repo.addCategory(request.name))
                is ActionRequest.RenameCategory -> {
                    val cat = categories.value.firstOrNull { it.name.equals(request.oldName, ignoreCase = true) }
                    if (cat == null) "I couldn't find that category."
                    else categoryResultMessage(repo.renameCategory(cat.id, request.newName)).also {
                        if (it == null && cat.name in expandedCategories.value) {
                            expandedCategories.value = expandedCategories.value - cat.name + request.newName.trim()
                        }
                    }
                }
                is ActionRequest.RemoveCategory -> {
                    val cat = categories.value.firstOrNull { it.name.equals(request.name, ignoreCase = true) }
                    if (cat == null) "I couldn't find that category."
                    else categoryResultMessage(repo.deleteCategory(cat.id)).also {
                        expandedCategories.value = expandedCategories.value - cat.name
                    }
                }
                is ActionRequest.SetSort -> {
                    sortMode.value = request.mode
                    null
                }
                is ActionRequest.SetTheme -> {
                    settingsStore.setTheme(request.theme)
                    null
                }
                ActionRequest.BinSelectAll -> {
                    selectAllBin()
                    null
                }
                ActionRequest.BinClearSelection -> {
                    clearBinSelection()
                    null
                }
                ActionRequest.BinRestoreSelected, ActionRequest.BinRestoreAll, is ActionRequest.BinRestoreOne ->
                    null // handled in executeVoice (they report a message)
                is ActionRequest.BinDeleteKeys -> deleteForeverMessage(request.keys)
                ActionRequest.Undo -> {
                    undo()
                    null
                }
                ActionRequest.Redo -> {
                    redo()
                    null
                }
                is ActionRequest.AddEmergency -> {
                    if (request.name.isBlank()) "A name is required."
                    else ContactValidator.validateEmergencyNumber(request.number) ?: run {
                        emergencyRepo.add(request.name, request.number)
                        null
                    }
                }
                is ActionRequest.EditEmergency -> {
                    val e = emergencyRepo.get(request.id)
                    if (e == null || e.deletedAt != null) {
                        "That emergency entry is no longer available."
                    } else {
                        val name = if (request.field == EmergencyField.NAME) request.value else e.name
                        val number = if (request.field == EmergencyField.NUMBER) request.value else e.number
                        if (name.isBlank()) "A name is required."
                        else ContactValidator.validateEmergencyNumber(number) ?: run {
                            emergencyRepo.update(e, name, number)
                            snack("Changes saved.")
                            null
                        }
                    }
                }
                is ActionRequest.RemoveEmergency -> {
                    val moved = emergencyRepo.moveToBin(request.id)
                    if (moved == null) {
                        "That emergency entry is no longer available."
                    } else {
                        snack("Entry moved to Bin", "Undo") { launchSafely { emergencyRepo.restore(request.id) } }
                        null
                    }
                }
                is ActionRequest.SaveProfileName -> {
                    val s = settings.value
                    if (request.name.isBlank()) {
                        "A name can't be empty."
                    } else {
                        settingsStore.saveProfile(request.name, s.email, s.about)
                        snack("Changes saved.")
                        null
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "Something went wrong, so nothing was changed."
        }
    }

    private fun categoryResultMessage(r: CategoryResult): String? = when (r) {
        CategoryResult.Ok -> null
        is CategoryResult.Error -> r.message
    }

    /** Voice only reaches here after an explicit spoken confirmation. */
    private suspend fun deleteForeverMessage(keys: List<String>): String? {
        if (keys.isEmpty()) return "There is nothing to delete."
        val n = deleteKeysForever(keys)
        snack(if (n == 1) "1 item deleted permanently." else "$n items deleted permanently.")
        return null
    }

    init {
        viewModelScope.launch {
            try {
                container.initialize()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _initError.value = e.message ?: "The local database could not be opened."
            } finally {
                _ready.value = true
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    fun snack(message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
        _events.tryEmit(SnackEvent(message, actionLabel, onAction))
    }

    /** Runs [block]; turns unexpected database/platform failures into a message instead of a crash. */
    private fun launchSafely(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                snack("Something went wrong: ${e.message ?: "database error"}")
            }
        }
    }

    fun findVisible(id: Long): ContactRecord? = visibleAll.value.firstOrNull { it.id == id }

    fun clearInitError() {
        _initError.value = null
    }

    // ------------------------------------------------------------------ lock policy

    fun onAppUnlocked() {
        appUnlocked.value = true
    }

    fun onBackground(authInProgress: Boolean) {
        if (!authInProgress) backgroundedAt = SystemClock.elapsedRealtime()
    }

    fun onForeground() {
        val away = backgroundedAt
        backgroundedAt = 0L
        if (away != 0L && SystemClock.elapsedRealtime() - away >= RELOCK_AFTER_MS) {
            appUnlocked.value = false
            voice.close() // a re-lock ends any open voice conversation
        }
    }

    override fun onCleared() {
        voice.release()
        super.onCleared()
    }

    // ------------------------------------------------------------------ contacts

    suspend fun findDuplicates(draft: ContactDraft, excludeId: Long): List<DuplicateMatch> =
        withContext(Dispatchers.Default) { repo.findDuplicates(draft, excludeId) }

    /** Adds ([contactId] < 0) or updates a contact, then calls [onSaved] on the main thread. */
    fun saveContact(contactId: Long, draft: ContactDraft, onSaved: () -> Unit) = launchSafely {
        if (contactId < 0) {
            repo.addContact(draft)
            snack("Contact added.")
            onSaved()
        } else {
            val updated = repo.updateContact(contactId, draft)
            if (updated == null) snack("That contact no longer exists.") else snack("Changes saved.")
            onSaved()
        }
    }

    fun toggleFavorite(contact: ContactRecord) = launchSafely {
        repo.setFavorite(contact.id, !contact.isFavorite)
    }

    /** Moves to the Recycle Bin (not a permanent delete) and offers Undo. */
    fun deleteContact(id: Long, onDone: () -> Unit = {}) = launchSafely {
        val removed = repo.moveToBin(id)
        if (removed != null) snack("Contact moved to Bin", "Undo") { undoDelete(id) }
        onDone()
    }

    private fun undoDelete(id: Long) = launchSafely {
        if (repo.undoTargetsDelete(id)) {
            snack(historyMessage(repo.undo(), "Action undone."))
        } else {
            // Something else happened since: restore this contact from the Bin directly.
            when (val r = repo.restore(id)) {
                RestoreResult.Restored -> snack("Contact restored.")
                is RestoreResult.Conflict -> snack("Can't restore: it matches ${r.matches.firstOrNull()?.existing?.name ?: "an existing contact"}")
                RestoreResult.NotFound -> snack("That contact is no longer in the Bin.")
            }
        }
    }

    private fun historyMessage(outcome: com.contactwhisper.app.data.HistoryOutcome, done: String) =
        if (outcome.performed) done else outcome.message

    fun undo() = launchSafely { snack(historyMessage(repo.undo(), "Action undone.")) }
    fun redo() = launchSafely { snack(historyMessage(repo.redo(), "Action redone.")) }

    // ------------------------------------------------------------------ categories

    fun addCategory(name: String, onResult: (CategoryResult) -> Unit) = launchSafely { onResult(repo.addCategory(name)) }

    fun renameCategory(id: Long, name: String, onResult: (CategoryResult) -> Unit) = launchSafely {
        onResult(repo.renameCategory(id, name))
    }

    fun deleteCategory(id: Long, onResult: (CategoryResult) -> Unit) = launchSafely { onResult(repo.deleteCategory(id)) }

    fun toggleCategoryExpanded(name: String) {
        expandedCategories.value = expandedCategories.value.let { if (name in it) it - name else it + name }
    }

    fun renameExpanded(old: String, new: String) {
        if (old in expandedCategories.value) expandedCategories.value = expandedCategories.value - old + new
    }

    // ------------------------------------------------------------------ emergency services

    fun addEmergency(name: String, number: String) = launchSafely { emergencyRepo.add(name, number) }

    fun updateEmergency(entity: EmergencyEntity, name: String, number: String) = launchSafely {
        emergencyRepo.update(entity, name, number)
        snack("Changes saved.")
    }

    /**
     * Emergency entries go to the Recycle Bin like contacts (recoverable; restore returns them to the Emergency list).
     * They have no Undo/Redo history; the snackbar's Undo button restores the entry directly.
     */
    fun deleteEmergency(entity: EmergencyEntity) = launchSafely {
        if (emergencyRepo.moveToBin(entity.id) != null) {
            snack("Entry moved to Bin", "Undo") { launchSafely { emergencyRepo.restore(entity.id) } }
        }
    }

    fun findEmergency(id: Long): EmergencyEntity? = emergencyEntries.value.firstOrNull { it.id == id }

    // ------------------------------------------------------------------ phonebook import

    private val _importUi = MutableStateFlow<ImportUi>(ImportUi.Idle)
    val importUi: StateFlow<ImportUi> = _importUi.asStateFlow()

    /** Shown once, on the first launch after the profile is set up (never again unless the user asks for it). */
    fun offerFirstLaunchImport() {
        val s = settings.value
        if (s.loaded && s.profileDone && s.contactImport.isEmpty() && _importUi.value == ImportUi.Idle) {
            _importUi.value = ImportUi.Explain
        }
    }

    /** "Import phone contacts" in Profile Customization. */
    fun requestImport() {
        if (_importUi.value == ImportUi.Idle) _importUi.value = ImportUi.Explain
    }

    fun declineImport() {
        _importUi.value = ImportUi.Idle
        launchSafely { if (settings.value.contactImport.isEmpty()) settingsStore.setContactImport("declined") }
    }

    fun onContactsPermissionResult(granted: Boolean) {
        if (_importUi.value != ImportUi.Explain) return
        if (!granted) {
            _importUi.value = ImportUi.Denied
            launchSafely { if (settings.value.contactImport.isEmpty()) settingsStore.setContactImport("declined") }
            return
        }
        runImport()
    }

    private fun runImport() {
        _importUi.value = ImportUi.Running
        viewModelScope.launch {
            try {
                val items = withContext(Dispatchers.IO) { DeviceContactReader.read(appContext) }
                val summary = repo.importContacts(items) // Room + DSA, one transaction on Dispatchers.IO
                settingsStore.setContactImport("done")
                _importUi.value = ImportUi.Summary(summary)
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                _importUi.value = ImportUi.Denied
            } catch (e: Exception) {
                _importUi.value = ImportUi.Failed(e.message ?: "The phone contacts could not be read.")
            }
        }
    }

    fun dismissImport() {
        _importUi.value = ImportUi.Idle
    }

    // ------------------------------------------------------------------ calls

    fun markCallPermissionAsked() = launchSafely { settingsStore.markCallPermAsked() }

    // ------------------------------------------------------------------ profile / theme / lock settings

    fun saveProfile(name: String, email: String, about: String, onDone: () -> Unit = {}) = launchSafely {
        settingsStore.saveProfile(name, email, about)
        onDone()
    }

    fun pickProfilePhoto(uri: Uri) = launchSafely {
        val path = saveProfilePhoto(appContext, uri)
        if (path == null) snack("Couldn't read that image. Please choose another one.") else settingsStore.setProfilePhoto(path)
    }

    fun setTheme(theme: AppTheme) = launchSafely { settingsStore.setTheme(theme) }

    // App Lock settings: touch-only. These are called from the App Lock screen and never from the voice assistant.
    fun setAppLockEnabled(enabled: Boolean) = launchSafely {
        settingsStore.setAppLockEnabled(enabled)
        if (enabled) appUnlocked.value = true // the user has just authenticated to turn it on
    }

    fun setLockMethod(method: LockMethod) = launchSafely { settingsStore.setLockMethod(method) }

    fun setPin(pin: String, onDone: () -> Unit = {}) = launchSafely {
        settingsStore.setPin(pin)
        onDone()
    }

    fun clearPin() = launchSafely { settingsStore.clearPin() }

    suspend fun verifyPin(pin: String): Boolean = settingsStore.verifyPin(pin)

    companion object {
        /** App Lock re-locks after this long in the background. */
        const val RELOCK_AFTER_MS = 30_000L
    }
}
