package com.contactwhisper.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.contactwhisper.app.data.AppTheme

/**
 * Gothic-inspired COLOURS only: near-black charcoal base, solid matte crimson or emerald cards, smoky-gray neutral
 * fields, thin accent outlines, warm ivory text. No ornament, no gradients on functional surfaces.
 *
 * The two contact-card colours are defined ONCE, here, and nowhere else:
 *   Crimson theme -> [CRIMSON_CARD]  #3A101A (muted, charcoal-mixed)   Emerald theme -> [EMERALD_CARD]  #051912
 * #78081C ([CRIMSON_REFERENCE]) stays the crimson identity colour for outlines, indicators and pressed states; it is too
 * saturated to fill whole cards without making the Crimson theme louder than Emerald.
 */
val CRIMSON_REFERENCE = Color(0xFF78081C)
val CRIMSON_CARD = Color(0xFF3A101A)
val EMERALD_CARD = Color(0xFF051912)

data class CWPalette(
    val background: Color,   // near-black charcoal (dominant)
    val surface: Color,      // secondary charcoal (bars, dialogs)
    val field: Color,        // smoky-gray search / neutral controls
    val panel: Color,        // THE solid card colour (#3A101A / #051912), also buttons and info panels
    val panelPressed: Color, // same hue, slightly lifted: pressed / focused / selected state
    val accent: Color,       // thin outlines, selected states, indicators
    val ivory: Color,        // text and small action icons
    val muted: Color,        // supporting text
    val smoke: Color,        // delete smoke colour (crimson wisps / emerald wisps)
    val danger: Color,
    val inputWell: Color,    // recessed (bevel-in) input fill
    val ring: Color,         // solid profile-picture outline / chips (vivid crimson or emerald)
)

val CrimsonPalette = CWPalette(
    background = Color(0xFF101012),
    surface = Color(0xFF191719),
    field = Color(0xFF2B2A2D),
    panel = CRIMSON_CARD,
    panelPressed = lerp(CRIMSON_CARD, CRIMSON_REFERENCE, 0.55f),
    accent = lerp(CRIMSON_REFERENCE, Color(0xFFB4465B), 0.35f),
    ivory = Color(0xFFE8D8C4),
    muted = Color(0xFFAAA3A0),
    smoke = Color(0xFFA83A50),
    danger = Color(0xFFE0788A),
    inputWell = Color(0xFF1A191B),
    ring = Color(0xFFC0304B),
)

val EmeraldPalette = CWPalette(
    background = Color(0xFF101211),
    surface = Color(0xFF191D1A),
    field = Color(0xFF2B2E2C),
    panel = EMERALD_CARD,
    panelPressed = lerp(EMERALD_CARD, Color(0xFF39745D), 0.45f),
    accent = Color(0xFF3A7A62),
    ivory = Color(0xFFE8D8C4),
    muted = Color(0xFFAAA9A1),
    smoke = Color(0xFF4FA583),
    danger = Color(0xFFE0788A),
    inputWell = Color(0xFF191C1A),
    ring = Color(0xFF2FA37F),
)

/** Brand colours that appear TOGETHER (splash, profile setup, About title). Brighter than the card colours so text is legible. */
val BrandCrimson = Color(0xFFD02A47)
val BrandEmerald = Color(0xFF22B38A)

/** Crimson-to-emerald gradient used for the "Contact Whisper" title text only. */
val BrandGradient: Brush get() = Brush.horizontalGradient(listOf(BrandCrimson, BrandEmerald))

/** Profile-setup outline colours (both brand colours at once). */
val SetupCrimson = Color(0xFFA32A40)
val SetupEmerald = Color(0xFF2A8A6C)

/** Ambient glow colours for splash / first-run only (both at once, opposite corners, very soft). */
val GlowCrimson = Color(0xFFB0304A)
val GlowEmerald = Color(0xFF1F9C78)

val LocalCW = staticCompositionLocalOf { CrimsonPalette }

object CW {
    val colors: CWPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalCW.current
}

fun paletteFor(theme: AppTheme): CWPalette = when (theme) {
    AppTheme.CRIMSON -> CrimsonPalette
    AppTheme.EMERALD -> EmeraldPalette
}

/**
 * Roboto everywhere. Android's default sans-serif IS Roboto on stock Android, but some OEM skins swap the system
 * font, so the app prefers bundled Roboto when it is present: drop roboto_regular.ttf, roboto_medium.ttf and
 * roboto_bold.ttf into app/src/main/res/font/ and no code change is needed. Without them it uses the platform
 * sans-serif (see docs/ASSETS.md).
 */
@Composable
private fun rememberRoboto(): FontFamily {
    val context = LocalContext.current
    return remember(context) {
        fun id(name: String) = context.resources.getIdentifier(name, "font", context.packageName)
        val regular = id("roboto_regular")
        val medium = id("roboto_medium")
        val bold = id("roboto_bold")
        if (regular != 0) {
            val fonts = buildList {
                add(Font(regular, FontWeight.Normal))
                if (medium != 0) add(Font(medium, FontWeight.Medium)) else add(Font(regular, FontWeight.Medium))
                if (bold != 0) {
                    add(Font(bold, FontWeight.SemiBold))
                    add(Font(bold, FontWeight.Bold))
                } else {
                    add(Font(regular, FontWeight.SemiBold))
                    add(Font(regular, FontWeight.Bold))
                }
            }
            FontFamily(fonts)
        } else {
            FontFamily.SansSerif
        }
    }
}

private fun typographyFor(f: FontFamily): Typography {
    val base = Typography()
    fun TextStyle.roboto() = copy(fontFamily = f)
    return Typography(
        displayLarge = base.displayLarge.roboto(),
        displayMedium = base.displayMedium.roboto(),
        displaySmall = base.displaySmall.roboto(),
        headlineLarge = base.headlineLarge.roboto(),
        headlineMedium = base.headlineMedium.roboto(),
        headlineSmall = base.headlineSmall.roboto(),
        titleLarge = base.titleLarge.copy(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
        titleMedium = base.titleMedium.copy(fontFamily = f, fontWeight = FontWeight.SemiBold),
        titleSmall = base.titleSmall.roboto(),
        bodyLarge = base.bodyLarge.roboto(),
        bodyMedium = base.bodyMedium.roboto(),
        bodySmall = base.bodySmall.roboto(),
        labelLarge = base.labelLarge.copy(fontFamily = f, fontWeight = FontWeight.Medium),
        labelMedium = base.labelMedium.roboto(),
        labelSmall = base.labelSmall.roboto(),
    )
}

/** Roboto family for code that builds its own TextStyle (voice overlay etc.). */
val LocalRoboto = staticCompositionLocalOf<FontFamily> { FontFamily.SansSerif }

@Composable
fun ContactWhisperTheme(theme: AppTheme, content: @Composable () -> Unit) {
    val p = paletteFor(theme)
    val roboto = rememberRoboto()
    val typography = remember(roboto) { typographyFor(roboto) }
    val scheme = darkColorScheme(
        primary = p.accent,
        onPrimary = p.ivory,
        secondary = p.accent,
        onSecondary = p.ivory,
        background = p.background,
        onBackground = p.ivory,
        surface = p.surface,
        onSurface = p.ivory,
        surfaceVariant = p.field,
        onSurfaceVariant = p.muted,
        surfaceContainer = p.surface,
        surfaceContainerHigh = p.surface,
        surfaceContainerHighest = p.field,
        outline = p.accent,
        outlineVariant = p.accent,
        error = p.danger,
        onError = p.background,
    )
    CompositionLocalProvider(LocalCW provides p, LocalRoboto provides roboto) {
        MaterialTheme(colorScheme = scheme, typography = typography) {
            // Text outside a Surface would otherwise fall back to the framework default; make Roboto explicit everywhere.
            ProvideTextStyle(TextStyle(fontFamily = roboto, color = p.ivory), content = content)
        }
    }
}
