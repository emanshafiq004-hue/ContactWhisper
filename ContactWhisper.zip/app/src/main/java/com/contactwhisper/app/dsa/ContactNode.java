package com.contactwhisper.app.dsa;

/** One node of {@link ContactLinkedList}. */
final class ContactNode {
    ContactRecord data;
    ContactNode next;

    ContactNode(ContactRecord data) {
        this.data = data;
    }
}
