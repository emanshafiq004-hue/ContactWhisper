package com.contactwhisper.app.voice

import com.contactwhisper.app.data.AppTheme
import com.contactwhisper.app.data.ContactDraft
import com.contactwhisper.app.domain.ContactValidator
import com.contactwhisper.app.dsa.ContactRecord
import com.contactwhisper.app.dsa.DuplicateMatch
import com.contactwhisper.app.dsa.SortMode

/** Everything the conversation needs from the app. Implemented over the existing repository; faked in tests. */
interface VoiceBackend {
    /** The app's universal search. */
    fun search(query: String): List<ContactRecord>
    fun inCategory(category: String): List<ContactRecord>
    fun categoryNames(): List<String>
    /** A fresh copy of an ACTIVE contact, or null (deleted meanwhile, ...). */
    fun get(id: Long): ContactRecord?
    fun duplicates(draft: ContactDraft, excludeId: Long): List<DuplicateMatch>
    fun binEntries(): List<VoiceBin>
    fun binSelection(): Set<String>
    fun emergencyEntries(): List<VoiceEmergency>
    fun profileName(): String
    fun expandedCategories(): Set<String>
}

data class VoiceBin(val key: String, val name: String, val emergency: Boolean)
data class VoiceEmergency(val id: Long, val name: String, val number: String)

data class VoiceEnvironment(val hasPermission: Boolean, val recognitionAvailable: Boolean)

/** Result of an [ActionRequest] run by the app. [message] (if any) is what the assistant says instead of the default. */
data class VoiceResult(val ok: Boolean, val message: String? = null) {
    companion object {
        fun ok(message: String? = null) = VoiceResult(true, message)
        fun fail(message: String) = VoiceResult(false, message)
    }
}

/**
 * A change the conversation asks the app to perform. They all go through the existing ViewModel / repository path
 * (same validation, same Room + DSA updates, same history rules as the touch UI).
 *
 * There is intentionally NO request for App Lock, the PIN, biometrics or any other authentication setting.
 */
sealed interface ActionRequest {
    data class SaveEdit(val id: Long, val field: EditField, val value: String) : ActionRequest
    data class MoveToBin(val id: Long, val name: String) : ActionRequest
    data class AddContact(val draft: ContactDraft) : ActionRequest
    data class SetFavorite(val id: Long, val name: String, val favorite: Boolean) : ActionRequest
    data class ExpandCategory(val name: String, val expand: Boolean) : ActionRequest
    data class CreateCategory(val name: String) : ActionRequest
    data class RenameCategory(val oldName: String, val newName: String) : ActionRequest
    data class RemoveCategory(val name: String) : ActionRequest
    data class SetSort(val mode: SortMode) : ActionRequest
    data class SetTheme(val theme: AppTheme) : ActionRequest
    data object BinSelectAll : ActionRequest
    data object BinClearSelection : ActionRequest
    data object BinRestoreSelected : ActionRequest
    data object BinRestoreAll : ActionRequest
    data class BinRestoreOne(val key: String, val name: String) : ActionRequest
    /** PERMANENT deletion of exactly the Bin entries that were read back and confirmed (nothing else). */
    data class BinDeleteKeys(val keys: List<String>, val label: String) : ActionRequest
    data class AddEmergency(val name: String, val number: String) : ActionRequest
    data class EditEmergency(val id: Long, val name: String, val field: EmergencyField, val value: String) : ActionRequest
    data class RemoveEmergency(val id: Long, val name: String) : ActionRequest
    data class SaveProfileName(val name: String) : ActionRequest
    data object Undo : ActionRequest
    data object Redo : ActionRequest
}

/** Side effects, executed by the Android layer. The conversation itself touches nothing. */
sealed interface VoiceEffect {
    data class Speak(val text: String) : VoiceEffect
    data object RequestPermission : VoiceEffect
    data class Navigate(val screen: VoiceScreen) : VoiceEffect
    data object Back : VoiceEffect
    data class OpenDetails(val id: Long) : VoiceEffect
    data class Dial(val number: String) : VoiceEffect
    data class Execute(val request: ActionRequest) : VoiceEffect
    /** End the session once everything queued has been spoken (immediately if nothing is being spoken). */
    data object CloseAfterSpeech : VoiceEffect
    /** End the session now. Whatever sentence is already being spoken is allowed to finish. */
    data object CloseNow : VoiceEffect
}

/** One tappable / speakable choice. [id] is a contact id, a Bin key or an emergency id, depending on the [ChoiceKind]. */
data class VoiceOption(val id: String, val label: String, val detail: String = "")

enum class ChoiceKind { CONTACT, BIN_RESTORE, BIN_DELETE, EMERGENCY_EDIT, EMERGENCY_REMOVE }

enum class CategoryAsk { CREATE, RENAME }

sealed interface VoiceState {
    data object Idle : VoiceState
    data object RequestingPermission : VoiceState
    /** Cannot listen at all (no recogniser / no microphone permission): only Close is offered. */
    data class Unavailable(val message: String) : VoiceState
    /** The top-level prompt: waiting for any command. The session sits here between commands. */
    data object AwaitingCommand : VoiceState
    data class Choosing(val title: String, val options: List<VoiceOption>, val kind: ChoiceKind, val action: VoiceAction?) : VoiceState
    data class AskingAction(val contact: ContactRecord) : VoiceState
    data class AskingEditField(val contact: ContactRecord) : VoiceState
    data class AskingEditValue(val contact: ContactRecord, val field: EditField) : VoiceState
    data class ConfirmingEdit(val contact: ContactRecord, val field: EditField, val newValue: String, val warning: String?) : VoiceState
    data class ConfirmingDelete(val contact: ContactRecord) : VoiceState
    data object AskingAddName : VoiceState
    data class AskingAddPhone(val name: String) : VoiceState
    data class AskingAddEmail(val name: String, val phone: String) : VoiceState
    data class ConfirmingAdd(val draft: ContactDraft, val warning: String?) : VoiceState
    data object AskingTheme : VoiceState
    data class AskingCategoryName(val ask: CategoryAsk, val oldName: String) : VoiceState
    data class ConfirmingRemoveCategory(val name: String) : VoiceState
    /** PERMANENT deletion: needs an explicit yes. [keys] are Bin keys; [summary] is what is read back. */
    data class ConfirmingBinDelete(val keys: List<String>, val summary: String) : VoiceState
    data object AskingEmergencyName : VoiceState
    data class AskingEmergencyNumber(val name: String) : VoiceState
    data class ConfirmingEmergencyAdd(val name: String, val number: String) : VoiceState
    data class AskingEmergencyEditField(val entry: VoiceEmergency) : VoiceState
    data class AskingEmergencyEditValue(val entry: VoiceEmergency, val field: EmergencyField) : VoiceState
    data class ConfirmingEmergencyEdit(val entry: VoiceEmergency, val field: EmergencyField, val value: String) : VoiceState
    data class ConfirmingEmergencyRemove(val entry: VoiceEmergency) : VoiceState
    data class ConfirmingProfileName(val name: String) : VoiceState
    data class ExecutingAction(val request: ActionRequest) : VoiceState
    /** The closing sentence is being spoken; the session ends when it finishes. */
    data object Closing : VoiceState
}

/** What the UI renders: the state plus the texts that are also spoken. [listening]/[speaking] are added by the Android layer. */
data class VoiceSnapshot(
    val state: VoiceState = VoiceState.Idle,
    val transcript: String = "",
    val partial: String = "",
    val assistant: String = "",
    val listening: Boolean = false,
    val speaking: Boolean = false,
    /** Number of commands handled in this session (the very first screen is the solid "listening" screen). */
    val handled: Int = 0,
)

/**
 * The conversational state machine. Pure Kotlin: input arrives through the on* methods (final speech results, taps,
 * typed text), each returns the list of [VoiceEffect]s to perform, and [snapshot] always holds what to show.
 *
 * It does NOT start or stop the microphone. The Android layer ([VoiceAssistant]) keeps listening while the session is
 * open and [wantsInput] is true, pauses while text-to-speech is talking, and simply starts the next recognition when
 * one ends. Therefore:
 *  - silence ([onSilence]) is not a command: nothing is said, nothing changes, listening just continues
 *  - speech that was heard but not understood ([onNotUnderstood] or an unparseable transcript) is answered once with
 *    "I didn't catch that. Please say it again." and listening continues; there is no retry button anywhere
 *
 * Safety rules built in:
 *  - A contact is re-read from [VoiceBackend.get] right before every action, so a contact that disappeared meanwhile
 *    can't be edited, deleted or dialled.
 *  - Delete / edit / add always need an explicit yes; PERMANENT deletion needs an explicit "yes"/"confirm"/"delete"
 *    (not just "ok"). Unclear answers re-ask. Cancel and errors change nothing.
 *  - Data is never touched here: changes leave as [VoiceEffect.Execute] and go through the existing ViewModel.
 *  - Anything aimed at App Lock / PIN / biometrics is refused ([VoiceCommand.SecurityRefused]); there is no
 *    [ActionRequest] able to change security settings, so nothing here could do it even by mistake.
 */
class VoiceConversation(private val backend: VoiceBackend) {

    var snapshot: VoiceSnapshot = VoiceSnapshot()
        private set

    val state: VoiceState get() = snapshot.state
    val isActive: Boolean get() = state != VoiceState.Idle

    /** True when a final transcript would be understood right now, i.e. the Android layer should be listening. */
    val wantsInput: Boolean
        get() = when (state) {
            VoiceState.Idle, VoiceState.RequestingPermission, is VoiceState.Unavailable,
            is VoiceState.ExecutingAction, VoiceState.Closing -> false
            else -> true
        }

    private val out = ArrayList<VoiceEffect>()

    private inline fun emit(block: () -> Unit): List<VoiceEffect> {
        out.clear()
        block()
        return out.toList()
    }

    // ------------------------------------------------------------------ helpers

    private fun go(next: VoiceState, say: String? = null, speak: Boolean = true) {
        snapshot = snapshot.copy(state = next, partial = "", assistant = say ?: snapshot.assistant)
        if (say != null && speak) out += VoiceEffect.Speak(say)
    }

    private fun top(say: String?) = go(VoiceState.AwaitingCommand, say)

    private fun nav(screen: VoiceScreen) {
        out += VoiceEffect.Navigate(screen)
    }

    private fun didntCatch() {
        snapshot = snapshot.copy(partial = "", assistant = PHRASE_DIDNT_CATCH)
        out += VoiceEffect.Speak(PHRASE_DIDNT_CATCH)
    }

    private fun stale() = top("That contact is no longer available.")

    private fun beginClose() {
        go(VoiceState.Closing, MSG_CLOSING)
        out += VoiceEffect.CloseAfterSpeech
    }

    // ------------------------------------------------------------------ session start / permission

    /** The microphone button or the two-finger swipe. Ignored while a session is already open (repeated taps / swipes). */
    fun open(env: VoiceEnvironment): List<VoiceEffect> = emit {
        if (state != VoiceState.Idle) return@emit
        snapshot = VoiceSnapshot()
        when {
            !env.recognitionAvailable -> go(VoiceState.Unavailable(MSG_UNAVAILABLE), MSG_UNAVAILABLE)
            !env.hasPermission -> {
                go(VoiceState.RequestingPermission, "I need microphone permission to listen.", speak = false)
                out += VoiceEffect.RequestPermission
            }
            else -> go(VoiceState.AwaitingCommand, PROMPT_READY, speak = false)
        }
    }

    fun onPermissionResult(granted: Boolean): List<VoiceEffect> = emit {
        if (state != VoiceState.RequestingPermission) return@emit
        if (granted) go(VoiceState.AwaitingCommand, PROMPT_READY, speak = false)
        else go(VoiceState.Unavailable(MSG_PERMISSION_DENIED), MSG_PERMISSION_DENIED)
    }

    /** The recogniser reported a failure that retrying cannot fix (service missing, permission revoked). */
    fun onRecognizerUnavailable(permission: Boolean): List<VoiceEffect> = emit {
        if (!isActive || state is VoiceState.Unavailable) return@emit
        val msg = if (permission) MSG_PERMISSION_DENIED else MSG_UNAVAILABLE
        go(VoiceState.Unavailable(msg), msg)
    }

    // ------------------------------------------------------------------ recognizer callbacks

    fun onPartial(text: String) {
        if (wantsInput) snapshot = snapshot.copy(partial = text)
    }

    /** Silence, a timeout or an empty result is NOT a command: no announcement, no state change. */
    fun onSilence(): List<VoiceEffect> = emit {
        if (snapshot.partial.isNotEmpty()) snapshot = snapshot.copy(partial = "")
    }

    /** Speech was heard but produced no usable text. */
    fun onNotUnderstood(): List<VoiceEffect> = emit {
        if (wantsInput) didntCatch()
    }

    /** Final speech results (best first). */
    fun onTranscript(alternatives: List<String>): List<VoiceEffect> = emit {
        if (!wantsInput) return@emit
        val alts = alternatives.map { it.trim() }.filter { it.isNotEmpty() }
        if (alts.isEmpty()) {
            didntCatch()
            return@emit
        }
        snapshot = snapshot.copy(transcript = alts[0], partial = "")
        handleReply(state, alts)
    }

    private fun handleReply(prompt: VoiceState, alts: List<String>) {
        val text = alts[0]
        when (prompt) {
            VoiceState.AwaitingCommand -> processCommand(text)
            is VoiceState.Choosing -> choosingReply(prompt, alts)
            is VoiceState.AskingAction -> actionReply(prompt, alts)
            is VoiceState.AskingEditField -> guard(text) { fieldReply(prompt, text) }
            is VoiceState.AskingEditValue -> guard(text) { valueReply(prompt, text) }
            is VoiceState.ConfirmingEdit -> confirmReply(alts, prompt, { editConfirmed(prompt) }, { editDeclined(prompt) })
            is VoiceState.ConfirmingDelete -> confirmReply(alts, prompt, { deleteConfirmed(prompt) }, { deleteDeclined(prompt) })
            VoiceState.AskingAddName -> guard(text) { addNameReply(text) }
            is VoiceState.AskingAddPhone -> guard(text) { addPhoneReply(prompt, text) }
            is VoiceState.AskingAddEmail -> guard(text) { addEmailReply(prompt, text) }
            is VoiceState.ConfirmingAdd -> confirmReply(alts, prompt, { addConfirmed(prompt) }, { addDeclined() })
            VoiceState.AskingTheme -> themeReply(alts)
            is VoiceState.AskingCategoryName -> guard(text) { categoryNameReply(prompt, text) }
            is VoiceState.ConfirmingRemoveCategory ->
                confirmReply(alts, prompt, { execute(ActionRequest.RemoveCategory(prompt.name)) }, { top("Okay, I kept the ${prompt.name} category.") })
            is VoiceState.ConfirmingBinDelete -> confirmReply(alts, prompt, { binDeleteConfirmed(prompt) }, { top("Okay, nothing was deleted.") }, strict = true)
            VoiceState.AskingEmergencyName -> guard(text) { emergencyNameReply(text) }
            is VoiceState.AskingEmergencyNumber -> guard(text) { emergencyNumberReply(prompt, text) }
            is VoiceState.ConfirmingEmergencyAdd ->
                confirmReply(alts, prompt, { execute(ActionRequest.AddEmergency(prompt.name, prompt.number)) }, { top("Okay, I didn't add anything.") })
            is VoiceState.AskingEmergencyEditField -> guard(text) { emergencyFieldReply(prompt, text) }
            is VoiceState.AskingEmergencyEditValue -> guard(text) { emergencyValueReply(prompt, text) }
            is VoiceState.ConfirmingEmergencyEdit -> confirmReply(
                alts, prompt,
                { execute(ActionRequest.EditEmergency(prompt.entry.id, prompt.entry.name, prompt.field, prompt.value)) },
                { top("Okay, I didn't change anything.") },
            )
            is VoiceState.ConfirmingEmergencyRemove ->
                confirmReply(alts, prompt, { execute(ActionRequest.RemoveEmergency(prompt.entry.id, prompt.entry.name)) }, { top("Okay, I kept ${prompt.entry.name}.") })
            is VoiceState.ConfirmingProfileName ->
                confirmReply(alts, prompt, { execute(ActionRequest.SaveProfileName(prompt.name)) }, { top("Okay, I didn't change your name.") })
            else -> Unit
        }
    }

    /** In free-text states only an exact close / cancel phrase is a command; everything else is the answer. */
    private inline fun guard(text: String, reply: () -> Unit) {
        when {
            VoiceCommandParser.isClose(text) -> beginClose()
            VoiceCommandParser.isCancel(text) -> top(MSG_CANCELLED)
            else -> reply()
        }
    }

    // ------------------------------------------------------------------ top-level commands

    private fun processCommand(text: String) {
        snapshot = snapshot.copy(handled = snapshot.handled + 1)
        when (val cmd = VoiceCommandParser.parseCommand(text)) {
            VoiceCommand.Unknown -> didntCatch()
            VoiceCommand.SecurityRefused -> top(MSG_SECURITY)
            VoiceCommand.Close -> beginClose()
            VoiceCommand.Cancel -> top("Okay.")
            VoiceCommand.Back -> {
                out += VoiceEffect.Back
                top("Going back.")
            }
            VoiceCommand.Undo -> execute(ActionRequest.Undo)
            VoiceCommand.Redo -> execute(ActionRequest.Redo)
            is VoiceCommand.Open -> openScreen(cmd.screen)
            VoiceCommand.AddContact -> go(VoiceState.AskingAddName, "Okay, let's add a contact. What is the name?")
            is VoiceCommand.Find -> doFind(cmd)
            is VoiceCommand.Sort -> {
                nav(VoiceScreen.HOME)
                execute(ActionRequest.SetSort(cmd.mode))
            }
            is VoiceCommand.Theme -> {
                val t = cmd.theme
                if (t == null) go(VoiceState.AskingTheme, "Which theme would you like: Crimson or Emerald?")
                else execute(ActionRequest.SetTheme(t))
            }
            is VoiceCommand.Favorite -> doFavoriteCommand(cmd)
            is VoiceCommand.ExpandCategory -> doExpandCategory(cmd)
            is VoiceCommand.CreateCategory -> {
                if (cmd.name.isBlank()) go(VoiceState.AskingCategoryName(CategoryAsk.CREATE, ""), "What should the new category be called?")
                else execute(ActionRequest.CreateCategory(VoiceCommandParser.titleCase(cmd.name)))
            }
            is VoiceCommand.RenameCategory -> doRenameCategory(cmd)
            is VoiceCommand.RemoveCategory -> doRemoveCategory(cmd)
            VoiceCommand.BinSelectAll -> binCommand { execute(ActionRequest.BinSelectAll) }
            VoiceCommand.BinClearSelection -> {
                nav(VoiceScreen.BIN)
                execute(ActionRequest.BinClearSelection)
            }
            VoiceCommand.BinRestoreAll -> binCommand { execute(ActionRequest.BinRestoreAll) }
            VoiceCommand.BinRestoreSelected -> {
                if (backend.binSelection().isEmpty()) top("Nothing is selected in the Bin. Say select all, or say restore and a name.")
                else {
                    nav(VoiceScreen.BIN)
                    execute(ActionRequest.BinRestoreSelected)
                }
            }
            is VoiceCommand.BinRestore -> doBinRestore(cmd.query)
            is VoiceCommand.BinDeletePermanently -> doBinDelete(cmd)
            VoiceCommand.BinDeleteAmbiguous ->
                top("Deleting from the Bin is permanent, so please be explicit: say delete all permanently, or permanently delete and a name. Saying delete on its own only moves a contact to the Bin.")
            VoiceCommand.AddEmergency -> go(VoiceState.AskingEmergencyName, "Okay. What is the name of the emergency service?")
            is VoiceCommand.EditEmergency -> doEmergencyPick(cmd.query, edit = true)
            is VoiceCommand.RemoveEmergency -> doEmergencyPick(cmd.query, edit = false)
            is VoiceCommand.ProfileName -> doProfileName(cmd.name)
        }
    }

    private fun openScreen(screen: VoiceScreen) {
        nav(screen)
        top(
            when (screen) {
                VoiceScreen.HOME -> "Opening Home."
                VoiceScreen.CATEGORIES -> "Opening Categories."
                VoiceScreen.FAVORITES -> "Opening Favorites."
                VoiceScreen.BIN -> "Opening the Bin."
                VoiceScreen.EMERGENCY -> "Opening Emergency Services."
                VoiceScreen.SETTINGS -> "Opening Settings."
                VoiceScreen.PROFILE -> "Opening your profile. You can say, change my name to, and then a name. To change the photo, tap the camera icon."
                VoiceScreen.APPEARANCE -> "Opening Appearance. Say Crimson or Emerald to switch the theme."
                VoiceScreen.ABOUT -> "Opening About."
            },
        )
    }

    private inline fun binCommand(then: () -> Unit) {
        if (backend.binEntries().isEmpty()) {
            nav(VoiceScreen.BIN)
            top("The Bin is empty.")
        } else {
            nav(VoiceScreen.BIN)
            then()
        }
    }

    // ---- find / contact actions

    private fun doFind(intent: VoiceCommand.Find) {
        val q = intent.query
        if (q.isBlank()) {
            top(
                if (intent.action == null) "Who would you like to find? Say a name, a phone number or an email."
                else "Which contact? For example, say ${verbExample(intent.action)} Ahmed Khan.",
            )
            return
        }
        val category = backend.categoryNames().firstOrNull { it.equals(q, ignoreCase = true) }
        if (intent.action == null && category != null) {
            val list = backend.inCategory(category)
            if (list.isEmpty()) {
                top("There are no contacts in $category.")
            } else {
                go(
                    contactChoice(list, null, "$category contacts"),
                    if (list.size == 1) "There is one contact in $category. Tap it to continue."
                    else "You have ${list.size} contacts in $category. Which one do you mean?",
                )
            }
            return
        }
        val results = backend.search(q)
        when {
            results.isEmpty() -> {
                // "call police": no contact matches, but an Emergency Services entry might
                val emergency = if (intent.action == VoiceAction.CALL) emergencyMatches(q) else emptyList()
                if (emergency.size == 1) {
                    out += VoiceEffect.Dial(emergency[0].number)
                    go(VoiceState.Closing, "Opening the dialer for ${emergency[0].name}.", speak = false)
                    out += VoiceEffect.CloseNow
                } else {
                    top("I couldn't find a contact matching $q.")
                }
            }
            results.size == 1 -> dispatch(results[0], intent.action)
            else -> go(
                contactChoice(results, intent.action, "Matches for \"$q\""),
                "I found ${results.size} contacts matching $q. Which one do you mean?",
            )
        }
    }

    private fun verbExample(a: VoiceAction) = when (a) {
        VoiceAction.VIEW -> "view"
        VoiceAction.EDIT -> "edit"
        VoiceAction.DELETE -> "delete"
        VoiceAction.CALL -> "call"
        VoiceAction.FAVORITE -> "add to favorites"
        VoiceAction.UNFAVORITE -> "remove from favorites"
    }

    private fun contactChoice(list: List<ContactRecord>, action: VoiceAction?, title: String) =
        VoiceState.Choosing(title, list.map { VoiceOption(it.id.toString(), it.name, it.phone) }, ChoiceKind.CONTACT, action)

    private fun dispatch(contact: ContactRecord, action: VoiceAction?) {
        val fresh = backend.get(contact.id)
        if (fresh == null) {
            stale()
            return
        }
        when (action) {
            null -> go(VoiceState.AskingAction(fresh), "I found ${fresh.name}. What would you like to do?")
            VoiceAction.VIEW -> {
                out += VoiceEffect.OpenDetails(fresh.id)
                top("Opening ${fresh.name}.")
            }
            VoiceAction.EDIT -> go(VoiceState.AskingEditField(fresh), PROMPT_EDIT_FIELD)
            VoiceAction.DELETE ->
                go(VoiceState.ConfirmingDelete(fresh), "Are you sure you want to move ${fresh.name} to the Bin?")
            VoiceAction.CALL -> {
                // ACTION_DIAL only opens the dialer with the number filled in; the user confirms the call there.
                out += VoiceEffect.Dial(fresh.phone)
                go(VoiceState.Closing, "Opening the dialer for ${fresh.name}.", speak = false)
                out += VoiceEffect.CloseNow
            }
            VoiceAction.FAVORITE -> doFavorite(fresh, true)
            VoiceAction.UNFAVORITE -> doFavorite(fresh, false)
        }
    }

    private fun doFavorite(c: ContactRecord, add: Boolean) {
        if (c.isFavorite == add) top(if (add) "${c.name} is already a favorite." else "${c.name} is not a favorite.")
        else execute(ActionRequest.SetFavorite(c.id, c.name, add))
    }

    private fun doFavoriteCommand(cmd: VoiceCommand.Favorite) {
        if (cmd.query.isBlank()) {
            top("Which contact? For example, say add Ahmed Khan to favorites.")
            return
        }
        val results = backend.search(cmd.query)
        val action = if (cmd.add) VoiceAction.FAVORITE else VoiceAction.UNFAVORITE
        when {
            results.isEmpty() -> top("I couldn't find a contact matching ${cmd.query}.")
            results.size == 1 -> dispatch(results[0], action)
            else -> go(
                contactChoice(results, action, "Matches for \"${cmd.query}\""),
                "I found ${results.size} contacts matching ${cmd.query}. Which one do you mean?",
            )
        }
    }

    // ---- categories

    private fun resolveCategory(raw: String): String? {
        val n = VoiceCommandParser.normalize(raw)
        if (n.isEmpty()) return null
        val names = backend.categoryNames()
        return names.firstOrNull { VoiceCommandParser.normalize(it) == n }
            ?: names.firstOrNull { VoiceCommandParser.normalize(it).startsWith(n) }
    }

    private fun doExpandCategory(cmd: VoiceCommand.ExpandCategory) {
        val name = resolveCategory(cmd.name)
        if (name == null) {
            top("I couldn't find a category called ${cmd.name}.")
            return
        }
        nav(VoiceScreen.CATEGORIES)
        execute(ActionRequest.ExpandCategory(name, cmd.expand))
    }

    private fun doRenameCategory(cmd: VoiceCommand.RenameCategory) {
        val old = resolveCategory(cmd.oldName)
        if (old == null) {
            top(if (cmd.oldName.isBlank()) "Which category should I rename? Say, for example, rename Work to Office." else "I couldn't find a category called ${cmd.oldName}.")
            return
        }
        if (cmd.newName.isBlank()) go(VoiceState.AskingCategoryName(CategoryAsk.RENAME, old), "What should $old be called instead?")
        else execute(ActionRequest.RenameCategory(old, VoiceCommandParser.titleCase(cmd.newName)))
    }

    private fun doRemoveCategory(cmd: VoiceCommand.RemoveCategory) {
        val name = resolveCategory(cmd.name)
        if (name == null) {
            top(if (cmd.name.isBlank()) "Which category should I remove?" else "I couldn't find a category called ${cmd.name}.")
            return
        }
        go(VoiceState.ConfirmingRemoveCategory(name), "Remove the $name category? Its contacts are not deleted; they move to Other. Say yes or no.")
    }

    private fun categoryNameReply(s: VoiceState.AskingCategoryName, raw: String) {
        val name = VoiceCommandParser.titleCase(VoiceCommandParser.cleanFreeText(raw))
        if (name.isBlank()) {
            go(s, PHRASE_DIDNT_CATCH)
            return
        }
        when (s.ask) {
            CategoryAsk.CREATE -> execute(ActionRequest.CreateCategory(name))
            CategoryAsk.RENAME -> execute(ActionRequest.RenameCategory(s.oldName, name))
        }
    }

    // ---- theme

    private fun themeReply(alts: List<String>) {
        val text = alts[0]
        if (VoiceCommandParser.isClose(text)) return beginClose()
        if (VoiceCommandParser.isCancel(text)) return top(MSG_CANCELLED)
        val theme = alts.firstNotNullOfOrNull { VoiceCommandParser.parseTheme(it) }
        if (theme != null) execute(ActionRequest.SetTheme(theme)) else fallbackToCommand(text, VoiceState.AskingTheme)
    }

    // ---- bin

    private fun binMatches(query: String): List<VoiceBin> {
        val words = VoiceCommandParser.tokens(query).filter { it !in setOf("contact", "the", "entry") }
        if (words.isEmpty()) return emptyList()
        return backend.binEntries().filter { b ->
            val nameTokens = VoiceCommandParser.tokens(b.name)
            words.all { w -> nameTokens.any { it.startsWith(w) } }
        }
    }

    private fun binOptions(list: List<VoiceBin>) =
        list.map { VoiceOption(it.key, it.name, if (it.emergency) "Emergency entry" else "") }

    private fun doBinRestore(query: String) {
        if (query.isBlank()) {
            top("Which contact should I restore? Say, for example, restore Ahmed.")
            return
        }
        val m = binMatches(query)
        when {
            m.isEmpty() -> top("I couldn't find $query in the Bin.")
            m.size == 1 -> {
                nav(VoiceScreen.BIN)
                execute(ActionRequest.BinRestoreOne(m[0].key, m[0].name))
            }
            else -> go(
                VoiceState.Choosing("Restore which one?", binOptions(m), ChoiceKind.BIN_RESTORE, null),
                "I found ${m.size} entries matching $query in the Bin. Which one should I restore?",
            )
        }
    }

    private fun doBinDelete(cmd: VoiceCommand.BinDeletePermanently) {
        val all = backend.binEntries()
        when (cmd.scope) {
            BinScope.ALL -> {
                nav(VoiceScreen.BIN)
                if (all.isEmpty()) top("The Bin is empty.")
                else go(
                    VoiceState.ConfirmingBinDelete(all.map { it.key }, "all ${all.size} entries in the Bin"),
                    "Permanently delete all ${all.size} entries in the Bin? This can't be undone. Say yes to delete everything, or no to cancel.",
                )
            }
            BinScope.SELECTED -> {
                val keys = backend.binSelection().toList()
                nav(VoiceScreen.BIN)
                if (keys.isEmpty()) top("Nothing is selected in the Bin. Say select all first, or name the contact.")
                else go(
                    VoiceState.ConfirmingBinDelete(keys, "${keys.size} selected ${if (keys.size == 1) "entry" else "entries"}"),
                    "Permanently delete ${keys.size} selected ${if (keys.size == 1) "entry" else "entries"}? This can't be undone. Say yes to delete, or no to cancel.",
                )
            }
            null -> {
                if (cmd.query.isBlank()) {
                    top("Which one? Say, for example, permanently delete Sara, or delete all permanently.")
                    return
                }
                val m = binMatches(cmd.query)
                when {
                    m.isEmpty() ->
                        top(
                            if (backend.search(cmd.query).isNotEmpty()) "${cmd.query} isn't in the Bin. Say delete and the name to move it to the Bin first."
                            else "I couldn't find ${cmd.query} in the Bin.",
                        )
                    m.size == 1 -> {
                        nav(VoiceScreen.BIN)
                        go(
                            VoiceState.ConfirmingBinDelete(listOf(m[0].key), m[0].name),
                            "Permanently delete ${m[0].name}? This can't be undone. Say yes to delete, or no to cancel.",
                        )
                    }
                    else -> go(
                        VoiceState.Choosing("Delete which one permanently?", binOptions(m), ChoiceKind.BIN_DELETE, null),
                        "I found ${m.size} entries matching ${cmd.query} in the Bin. Which one should I delete permanently?",
                    )
                }
            }
        }
    }

    private fun binDeleteConfirmed(s: VoiceState.ConfirmingBinDelete) {
        // Re-check against the live Bin: only entries that are STILL in the Bin can be deleted, and only the ones that
        // were read back to the user and confirmed (a selection changed meanwhile can't widen the deletion).
        val live = backend.binEntries().map { it.key }.toSet()
        val keys = s.keys.filter { it in live }
        if (keys.isEmpty()) top("Those entries are no longer in the Bin.")
        else execute(ActionRequest.BinDeleteKeys(keys, s.summary))
    }

    // ---- emergency services

    private fun emergencyMatches(query: String): List<VoiceEmergency> {
        val words = VoiceCommandParser.tokens(query).filter { it !in setOf("emergency", "service", "services", "the", "number") }
        if (words.isEmpty()) return emptyList()
        return backend.emergencyEntries().filter { e ->
            val nameTokens = VoiceCommandParser.tokens(e.name)
            words.all { w -> nameTokens.any { it.startsWith(w) } }
        }
    }

    private fun doEmergencyPick(query: String, edit: Boolean) {
        if (query.isBlank()) {
            top("Which entry? Say, for example, ${if (edit) "edit" else "remove"} emergency Police.")
            return
        }
        val m = emergencyMatches(query)
        when {
            m.isEmpty() -> top("I couldn't find an emergency entry matching $query.")
            m.size == 1 -> emergencyChosen(m[0], edit)
            else -> go(
                VoiceState.Choosing(
                    if (edit) "Edit which entry?" else "Remove which entry?",
                    m.map { VoiceOption(it.id.toString(), it.name, it.number) },
                    if (edit) ChoiceKind.EMERGENCY_EDIT else ChoiceKind.EMERGENCY_REMOVE,
                    null,
                ),
                "I found ${m.size} entries matching $query. Which one do you mean?",
            )
        }
    }

    private fun emergencyChosen(e: VoiceEmergency, edit: Boolean) {
        nav(VoiceScreen.EMERGENCY)
        if (edit) go(VoiceState.AskingEmergencyEditField(e), "What would you like to change for ${e.name}: the name or the number?")
        else go(VoiceState.ConfirmingEmergencyRemove(e), "Move ${e.name} to the Bin? You can restore it from there. Say yes or no.")
    }

    private fun emergencyNameReply(raw: String) {
        val name = VoiceCommandParser.titleCase(VoiceCommandParser.cleanFreeText(raw))
        if (name.isBlank()) go(VoiceState.AskingEmergencyName, PHRASE_DIDNT_CATCH)
        else go(VoiceState.AskingEmergencyNumber(name), "What is the number for $name?")
    }

    private fun emergencyNumberReply(s: VoiceState.AskingEmergencyNumber, raw: String) {
        val number = VoiceCommandParser.normalizeSpokenPhone(raw)
        val error = ContactValidator.validateEmergencyNumber(number)
        if (error != null) {
            go(s, "That number doesn't look valid. Please say it again.")
        } else {
            nav(VoiceScreen.EMERGENCY)
            go(VoiceState.ConfirmingEmergencyAdd(s.name, number), "Add ${s.name}, $number, to Emergency Services? Say yes to save or no to cancel.")
        }
    }

    private fun emergencyFieldReply(s: VoiceState.AskingEmergencyEditField, raw: String) {
        val field = VoiceCommandParser.parseEmergencyField(raw)
        if (field == null) go(s, "Please say name or number.")
        else go(
            VoiceState.AskingEmergencyEditValue(s.entry, field),
            if (field == EmergencyField.NAME) "What is the new name?" else "What is the new number?",
        )
    }

    private fun emergencyValueReply(s: VoiceState.AskingEmergencyEditValue, raw: String) {
        val value = if (s.field == EmergencyField.NUMBER) VoiceCommandParser.normalizeSpokenPhone(raw)
        else VoiceCommandParser.titleCase(VoiceCommandParser.cleanFreeText(raw))
        if (s.field == EmergencyField.NAME && value.isBlank()) {
            go(s, PHRASE_DIDNT_CATCH)
            return
        }
        if (s.field == EmergencyField.NUMBER && ContactValidator.validateEmergencyNumber(value) != null) {
            go(s, "That number doesn't look valid. Please say it again.")
            return
        }
        val old = if (s.field == EmergencyField.NAME) s.entry.name else s.entry.number
        go(
            VoiceState.ConfirmingEmergencyEdit(s.entry, s.field, value),
            "Change the ${s.field.label} of ${s.entry.name} from $old to $value? Say yes to save or no to cancel.",
        )
    }

    // ---- profile

    private fun doProfileName(name: String) {
        val error = if (name.isBlank()) "What name should I use? Say, change my name to, and then the name." else ContactValidator.validateName(name)
        if (error != null) {
            top(error)
        } else {
            go(VoiceState.ConfirmingProfileName(name), "Change your profile name to $name? Say yes or no.")
        }
    }

    // ------------------------------------------------------------------ replies (spoken, typed or tapped share these)

    /** A prompt that wasn't answered but is a complete top-level command (e.g. "open bin") is simply run. */
    private fun fallbackToCommand(text: String, prompt: VoiceState) {
        val cmd = VoiceCommandParser.parseCommand(text)
        if (cmd != VoiceCommand.Unknown && cmd !is VoiceCommand.Find) {
            snapshot = snapshot.copy(state = VoiceState.AwaitingCommand)
            processCommand(text)
        } else {
            go(prompt, PHRASE_DIDNT_CATCH)
        }
    }

    private fun confirmReply(alts: List<String>, prompt: VoiceState, yes: () -> Unit, no: () -> Unit, strict: Boolean = false) {
        val text = alts[0]
        if (VoiceCommandParser.isClose(text)) return beginClose()
        val answer = alts.firstNotNullOfOrNull { if (strict) VoiceCommandParser.parseStrictYesNo(it) else VoiceCommandParser.parseYesNo(it) }
        when (answer) {
            YesNo.YES -> yes()
            YesNo.NO -> no()
            null -> go(prompt, if (strict) "I didn't catch that. Please say yes to delete permanently, or no to cancel." else PHRASE_DIDNT_CATCH)
        }
    }

    // ---- choosing among matches

    private fun choosingReply(s: VoiceState.Choosing, alts: List<String>) {
        val text = alts[0]
        if (VoiceCommandParser.isClose(text)) return beginClose()
        if (VoiceCommandParser.isCancel(text)) return top(MSG_CANCELLED)
        val action = alts.firstNotNullOfOrNull { VoiceCommandParser.parseAction(it) } ?: s.action
        for (alt in alts) {
            val index = VoiceCommandParser.parseOrdinal(alt)
            if (index != null && index < s.options.size) {
                choose(s, s.options[index].id, action)
                return
            }
        }
        val skip = setOf("the", "one", "please", "contact", "number", "option", "i", "mean", "want", "it", "is", "that", "entry")
        for (alt in alts) {
            val spoken = VoiceCommandParser.tokens(alt).filter { it !in skip && it !in ACTION_WORDS }
            if (spoken.isEmpty()) continue
            val narrowed = s.options.filter { o ->
                val nameTokens = VoiceCommandParser.tokens(o.label)
                spoken.all { w -> nameTokens.any { it.startsWith(w) } }
            }
            when {
                narrowed.size == 1 -> {
                    choose(s, narrowed[0].id, action)
                    return
                }
                narrowed.size > 1 && narrowed.size < s.options.size -> {
                    go(s.copy(options = narrowed), "That still matches ${narrowed.size}. Which one do you mean?")
                    return
                }
            }
        }
        fallbackToCommand(text, s)
    }

    private fun choose(s: VoiceState.Choosing, id: String, action: VoiceAction?) {
        when (s.kind) {
            ChoiceKind.CONTACT -> {
                val c = id.toLongOrNull()?.let { backend.get(it) }
                if (c == null) stale() else dispatch(c, action)
            }
            ChoiceKind.BIN_RESTORE -> {
                val b = backend.binEntries().firstOrNull { it.key == id }
                if (b == null) top("That entry is no longer in the Bin.")
                else {
                    nav(VoiceScreen.BIN)
                    execute(ActionRequest.BinRestoreOne(b.key, b.name))
                }
            }
            ChoiceKind.BIN_DELETE -> {
                val b = backend.binEntries().firstOrNull { it.key == id }
                if (b == null) top("That entry is no longer in the Bin.")
                else {
                    nav(VoiceScreen.BIN)
                    go(
                        VoiceState.ConfirmingBinDelete(listOf(b.key), b.name),
                        "Permanently delete ${b.name}? This can't be undone. Say yes to delete, or no to cancel.",
                    )
                }
            }
            ChoiceKind.EMERGENCY_EDIT, ChoiceKind.EMERGENCY_REMOVE -> {
                val e = backend.emergencyEntries().firstOrNull { it.id.toString() == id }
                if (e == null) top("That entry is no longer available.") else emergencyChosen(e, s.kind == ChoiceKind.EMERGENCY_EDIT)
            }
        }
    }

    // ---- action question

    private fun actionReply(s: VoiceState.AskingAction, alts: List<String>) {
        val text = alts[0]
        if (VoiceCommandParser.isClose(text)) return beginClose()
        if (VoiceCommandParser.isCancel(text)) return top(MSG_CANCELLED)
        val contactTokens = VoiceCommandParser.tokens(s.contact.name)
        for (alt in alts) {
            val action = VoiceCommandParser.parseAction(alt, allowHomophones = true) ?: continue
            // "View", "View this contact", "Open contact", "Show details", "Show Ahmed Khan": the action applies to the
            // contact already selected. Names that point at somebody else make it a new command instead.
            val names = VoiceCommandParser.nameWords(alt)
            if (VoiceCommandParser.isViewHomophone(alt) || names.all { w -> contactTokens.any { it.startsWith(w) } }) {
                dispatch(s.contact, action)
                return
            }
            fallbackToCommand(alt, s)
            return
        }
        fallbackToCommand(text, s)
    }

    // ---- edit

    private fun fieldReply(s: VoiceState.AskingEditField, text: String) {
        val field = VoiceCommandParser.parseEditField(text)
        if (field == null) go(s, "Please say name, phone number, email, address, notes or category.")
        else chooseField(s.contact, field)
    }

    private fun chooseField(contact: ContactRecord, field: EditField) {
        val fresh = backend.get(contact.id)
        if (fresh == null) {
            stale()
            return
        }
        val prompt = when (field) {
            EditField.NAME -> "What is the new name?"
            EditField.PHONE -> "What is the new phone number?"
            EditField.EMAIL -> "What is the new email address? You can say clear to remove it."
            EditField.ADDRESS -> "What is the new address? You can say clear to remove it."
            EditField.NOTES -> "What should the notes say? You can say clear to remove them."
            EditField.CATEGORY -> {
                val names = backend.categoryNames()
                "Which category? Your categories are ${names.joinToString(", ")}. Say none to clear it."
            }
        }
        go(VoiceState.AskingEditValue(fresh, field), prompt)
    }

    private fun resolveCategoryValue(raw: String): String? {
        if (VoiceCommandParser.isClear(raw)) return ""
        return resolveCategory(raw)
    }

    private fun valueReply(s: VoiceState.AskingEditValue, raw: String) {
        val fresh = backend.get(s.contact.id)
        if (fresh == null) {
            stale()
            return
        }
        val field = s.field
        val value: String = when (field) {
            EditField.PHONE -> VoiceCommandParser.normalizeSpokenPhone(raw)
            EditField.EMAIL -> if (VoiceCommandParser.isClear(raw)) "" else VoiceCommandParser.normalizeSpokenEmail(raw)
            EditField.CATEGORY -> resolveCategoryValue(raw) ?: run {
                go(s, "I couldn't find that category. Your categories are ${backend.categoryNames().joinToString(", ")}. Please try again.")
                return
            }
            EditField.ADDRESS, EditField.NOTES ->
                if (VoiceCommandParser.isClear(raw)) "" else VoiceCommandParser.cleanFreeText(raw)
            EditField.NAME -> VoiceCommandParser.cleanFreeText(raw)
        }

        // Same validation as the visual Edit form (an untouched stored number stays acceptable).
        val draft = fresh.toDraft().withField(field, value)
        val r = ContactValidator.validate(draft.name, draft.phone, draft.email, draft.address, draft.notes, fresh.phone)
        val error = when (field) {
            EditField.NAME -> r.nameError
            EditField.PHONE -> r.phoneError
            EditField.EMAIL -> r.emailError
            EditField.ADDRESS -> r.addressError
            EditField.NOTES -> r.notesError
            EditField.CATEGORY -> null
        }
        if (error != null) {
            go(s, if (field == EditField.PHONE) "Please say an 11-digit mobile number, for example zero three zero zero, one two three, four five six seven." else "$error. Please try again.")
            return
        }
        if (value == fresh.valueOf(field)) {
            go(s, "That is already the current ${field.label}. Say a different value, or cancel.")
            return
        }
        val warning = if (field == EditField.NAME || field == EditField.PHONE || field == EditField.EMAIL) {
            duplicateWarning(backend.duplicates(draft, fresh.id))
        } else null
        val old = fresh.valueOf(field).ifBlank { "empty" }
        val new = value.ifBlank { "empty" }
        go(
            VoiceState.ConfirmingEdit(fresh, field, value, warning),
            "Change ${fresh.name}'s ${field.label} from $old to $new?" +
                (warning?.let { " $it" } ?: "") + " Say yes to save or no to cancel.",
        )
    }

    private fun editConfirmed(s: VoiceState.ConfirmingEdit) {
        val fresh = backend.get(s.contact.id)
        if (fresh == null) stale() else execute(ActionRequest.SaveEdit(fresh.id, s.field, s.newValue))
    }

    private fun editDeclined(s: VoiceState.ConfirmingEdit) {
        val fresh = backend.get(s.contact.id)
        if (fresh == null) stale() else go(VoiceState.AskingAction(fresh), "Okay, I didn't change anything. What would you like to do?")
    }

    // ---- delete

    private fun deleteConfirmed(s: VoiceState.ConfirmingDelete) {
        val fresh = backend.get(s.contact.id)
        if (fresh == null) stale() else execute(ActionRequest.MoveToBin(fresh.id, fresh.name))
    }

    private fun deleteDeclined(s: VoiceState.ConfirmingDelete) {
        val fresh = backend.get(s.contact.id)
        if (fresh == null) stale() else go(VoiceState.AskingAction(fresh), "Okay, I won't delete ${fresh.name}. What would you like to do?")
    }

    // ---- add contact

    private fun addNameReply(raw: String) {
        val name = VoiceCommandParser.cleanFreeText(raw)
        val error = ContactValidator.validateName(name)
        if (error != null) go(VoiceState.AskingAddName, "$error. Please say the name again.")
        else go(VoiceState.AskingAddPhone(name), "What is the phone number for $name?")
    }

    private fun addPhoneReply(s: VoiceState.AskingAddPhone, raw: String) {
        val phone = VoiceCommandParser.normalizeSpokenPhone(raw)
        // Same rule as the visual Add form: an 11-digit Pakistani mobile number (+92 is converted).
        if (ContactValidator.validateMobile(phone) != null) {
            go(s, "Please say an 11-digit mobile number, for example zero three zero zero, one two three, four five six seven.")
        } else {
            go(VoiceState.AskingAddEmail(s.name, ContactValidator.phoneForSave(phone)), "Do you want to add an email address? Say the address, or say skip.")
        }
    }

    private fun addEmailReply(s: VoiceState.AskingAddEmail, raw: String) {
        val email = if (VoiceCommandParser.isSkip(raw)) "" else VoiceCommandParser.normalizeSpokenEmail(raw)
        val error = ContactValidator.validateEmail(email)
        if (error != null) {
            go(s, "$error. Please try again, or say skip.")
            return
        }
        val draft = ContactDraft(name = s.name, phone = s.phone, email = email)
        val warning = duplicateWarning(backend.duplicates(draft, -1L))
        val details = "${s.name}, ${s.phone}" + if (email.isNotEmpty()) ", $email" else ""
        go(
            VoiceState.ConfirmingAdd(draft, warning),
            "Add $details?" + (warning?.let { " $it" } ?: "") + " Say yes to save or no to cancel.",
        )
    }

    private fun addConfirmed(s: VoiceState.ConfirmingAdd) = execute(ActionRequest.AddContact(s.draft))

    private fun addDeclined() = top("Okay, I didn't add anything.")

    // ------------------------------------------------------------------ execution

    private fun execute(request: ActionRequest) {
        go(VoiceState.ExecutingAction(request), "Working on it.", speak = false)
        out += VoiceEffect.Execute(request)
    }

    /** The app reports back after running an [ActionRequest]. Ignored if the session was closed meanwhile. */
    fun onExecutionResult(result: VoiceResult): List<VoiceEffect> = emit {
        val s = state as? VoiceState.ExecutingAction ?: return@emit
        if (!result.ok) {
            top(result.message ?: "That didn't work, and nothing was changed.")
            return@emit
        }
        top(result.message ?: successMessage(s.request))
    }

    private fun successMessage(r: ActionRequest): String = when (r) {
        is ActionRequest.MoveToBin -> "${r.name} has been moved to the Bin."
        is ActionRequest.SaveEdit -> "The ${r.field.label} has been updated."
        is ActionRequest.AddContact -> "${r.draft.name} has been added."
        is ActionRequest.SetFavorite -> if (r.favorite) "${r.name} was added to your favorites." else "${r.name} was removed from your favorites."
        is ActionRequest.ExpandCategory -> if (r.expand) "Showing ${r.name}." else "Collapsed ${r.name}."
        is ActionRequest.CreateCategory -> "Created the ${r.name} category."
        is ActionRequest.RenameCategory -> "Renamed ${r.oldName} to ${r.newName}."
        is ActionRequest.RemoveCategory -> "Removed the ${r.name} category."
        is ActionRequest.SetSort -> "Sorted ${r.mode.label}."
        is ActionRequest.SetTheme -> "Switched to the ${if (r.theme == AppTheme.EMERALD) "Emerald" else "Crimson"} theme."
        ActionRequest.BinSelectAll -> "Everything in the Bin is selected."
        ActionRequest.BinClearSelection -> "Selection cleared."
        ActionRequest.BinRestoreSelected, ActionRequest.BinRestoreAll, is ActionRequest.BinRestoreOne -> "Restored."
        is ActionRequest.BinDeleteKeys -> "Deleted permanently."
        is ActionRequest.AddEmergency -> "${r.name} was added to Emergency Services."
        is ActionRequest.EditEmergency -> "Updated ${r.name}."
        is ActionRequest.RemoveEmergency -> "${r.name} was moved to the Bin."
        is ActionRequest.SaveProfileName -> "Your name is now ${r.name}."
        ActionRequest.Undo -> "Done."
        ActionRequest.Redo -> "Done."
    }

    // ------------------------------------------------------------------ touch / typed input

    fun onChoiceTapped(id: String): List<VoiceEffect> = emit {
        val s = state as? VoiceState.Choosing ?: return@emit
        choose(s, id, s.action)
    }

    fun onActionTapped(action: VoiceAction): List<VoiceEffect> = emit {
        val s = state as? VoiceState.AskingAction ?: return@emit
        dispatch(s.contact, action)
    }

    fun onFieldTapped(field: EditField): List<VoiceEffect> = emit {
        val s = state as? VoiceState.AskingEditField ?: return@emit
        chooseField(s.contact, field)
    }

    fun onEmergencyFieldTapped(field: EmergencyField): List<VoiceEffect> = emit {
        val s = state as? VoiceState.AskingEmergencyEditField ?: return@emit
        go(
            VoiceState.AskingEmergencyEditValue(s.entry, field),
            if (field == EmergencyField.NAME) "What is the new name?" else "What is the new number?",
        )
    }

    fun onThemeTapped(theme: AppTheme): List<VoiceEffect> = emit {
        if (state != VoiceState.AskingTheme) return@emit
        execute(ActionRequest.SetTheme(theme))
    }

    fun onYes(): List<VoiceEffect> = emit { answer(true) }
    fun onNo(): List<VoiceEffect> = emit { answer(false) }

    private fun answer(yes: Boolean) {
        when (val s = state) {
            is VoiceState.ConfirmingEdit -> if (yes) editConfirmed(s) else editDeclined(s)
            is VoiceState.ConfirmingDelete -> if (yes) deleteConfirmed(s) else deleteDeclined(s)
            is VoiceState.ConfirmingAdd -> if (yes) addConfirmed(s) else addDeclined()
            is VoiceState.ConfirmingRemoveCategory ->
                if (yes) execute(ActionRequest.RemoveCategory(s.name)) else top("Okay, I kept the ${s.name} category.")
            is VoiceState.ConfirmingBinDelete -> if (yes) binDeleteConfirmed(s) else top("Okay, nothing was deleted.")
            is VoiceState.ConfirmingEmergencyAdd ->
                if (yes) execute(ActionRequest.AddEmergency(s.name, s.number)) else top("Okay, I didn't add anything.")
            is VoiceState.ConfirmingEmergencyEdit ->
                if (yes) execute(ActionRequest.EditEmergency(s.entry.id, s.entry.name, s.field, s.value)) else top("Okay, I didn't change anything.")
            is VoiceState.ConfirmingEmergencyRemove ->
                if (yes) execute(ActionRequest.RemoveEmergency(s.entry.id, s.entry.name)) else top("Okay, I kept ${s.entry.name}.")
            is VoiceState.ConfirmingProfileName ->
                if (yes) execute(ActionRequest.SaveProfileName(s.name)) else top("Okay, I didn't change your name.")
            else -> Unit
        }
    }

    /** Typed answer for the value questions (an alternative to speaking). */
    fun onTypedText(text: String): List<VoiceEffect> = emit {
        val s = state
        val typed = text.isNotBlank() && when (s) {
            is VoiceState.AskingEditValue, VoiceState.AskingAddName, is VoiceState.AskingAddPhone, is VoiceState.AskingAddEmail,
            is VoiceState.AskingCategoryName, VoiceState.AskingEmergencyName, is VoiceState.AskingEmergencyNumber,
            is VoiceState.AskingEmergencyEditValue -> true
            else -> false
        }
        if (typed) {
            snapshot = snapshot.copy(transcript = text.trim())
            handleReply(s, listOf(text.trim()))
        }
    }

    /** Cancel the current operation but keep the session going (the "Cancel" button). */
    fun onCancelOperation(): List<VoiceEffect> = emit {
        if (wantsInput && state != VoiceState.AwaitingCommand) top(MSG_CANCELLED)
    }

    // ------------------------------------------------------------------ leaving

    /** The visible Close / Back control. Ends the session now; a sentence already being spoken is allowed to finish. */
    fun onClose(): List<VoiceEffect> = emit {
        if (state != VoiceState.Idle) {
            snapshot = VoiceSnapshot()
            out += VoiceEffect.CloseNow
        }
    }

    /** Called by the Android layer when the closing sentence has finished (or nothing needed to be said). */
    fun finishClose(): List<VoiceEffect> = emit {
        if (state == VoiceState.Closing) {
            snapshot = VoiceSnapshot()
            out += VoiceEffect.CloseNow
        }
    }

    /** The app left the foreground: the session ends (nothing may keep recording), unlike a pause. */
    fun onInterrupted(): List<VoiceEffect> = emit {
        if (state != VoiceState.Idle) {
            snapshot = VoiceSnapshot()
            out += VoiceEffect.CloseNow
        }
    }

    // ------------------------------------------------------------------ text helpers

    private fun duplicateWarning(matches: List<DuplicateMatch>): String? {
        if (matches.isEmpty()) return null
        val m = matches.firstOrNull { it.isStrong } ?: matches.first()
        return when (m.reason) {
            DuplicateMatch.Reason.PHONE -> "Heads up: that is the same phone number as ${m.existing.name}."
            DuplicateMatch.Reason.EMAIL -> "Heads up: that is the same email address as ${m.existing.name}."
            DuplicateMatch.Reason.NAME -> "Heads up: a contact named ${m.existing.name} already exists."
        }
    }

    companion object {
        const val PHRASE_DIDNT_CATCH = "I didn't catch that. Please say it again."
        const val PROMPT_READY = "I'm listening."
        const val MSG_CLOSING = "Closing the voice assistant."
        const val MSG_CANCELLED = "Okay, cancelled."
        const val MSG_UNAVAILABLE = "Speech recognition is not available right now."
        const val MSG_PERMISSION_DENIED =
            "I need microphone permission to hear you. You can allow it in the app's Android settings, or use the search box instead."
        const val MSG_SECURITY =
            "I can't change App Lock or any security setting by voice. Please use the App Lock screen in Settings."
        const val PROMPT_EDIT_FIELD = "What would you like to change: name, phone number, email, address, notes or category?"
        private val ACTION_WORDS = setOf(
            "call", "dial", "phone", "ring", "edit", "change", "update", "modify",
            "delete", "remove", "erase", "view", "open", "show", "see", "details",
            "favorite", "favourite", "restore", "permanently", "forever",
        )
    }
}
