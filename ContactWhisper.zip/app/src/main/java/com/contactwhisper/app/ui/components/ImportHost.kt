package com.contactwhisper.app.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.ImportUi
import com.contactwhisper.app.data.ImportSummary
import com.contactwhisper.app.ui.theme.CW

/**
 * Phonebook import dialogs: explain -> Android's READ_CONTACTS prompt -> background import -> summary.
 * Reading and storing happen in the ViewModel on a background dispatcher; contacts never leave the device.
 */
@Composable
fun ImportHost(vm: AppViewModel) {
    val c = CW.colors
    val context = LocalContext.current
    val state by vm.importUi.collectAsStateWithLifecycle()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.onContactsPermissionResult(granted)
    }

    when (val s = state) {
        ImportUi.Idle -> Unit
        ImportUi.Explain -> AlertDialog(
            onDismissRequest = vm::declineImport,
            containerColor = c.surface,
            titleContentColor = c.ivory,
            textContentColor = c.ivory.copy(alpha = 0.85f),
            title = { Text("Import your phone contacts?") },
            text = {
                Text(
                    "ContactWhisper can copy the names, phone numbers and email addresses from your phone's contacts " +
                        "into this app. They are stored only on this device and are never uploaded. Contacts you already " +
                        "have here are never duplicated or overwritten.\n\nAndroid will now ask for permission to read " +
                        "your contacts.",
                    fontSize = 14.sp,
                )
            },
            confirmButton = {
                CWTextButton("Continue", {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
                        PackageManager.PERMISSION_GRANTED
                    if (granted) vm.onContactsPermissionResult(true) else launcher.launch(Manifest.permission.READ_CONTACTS)
                })
            },
            dismissButton = { CWTextButton("Not now", vm::declineImport) },
        )
        ImportUi.Running -> AlertDialog(
            onDismissRequest = {},
            containerColor = c.surface,
            titleContentColor = c.ivory,
            title = { Text("Importing contacts") },
            text = {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    CircularProgressIndicator(color = c.ring, modifier = Modifier.width(28.dp).height(28.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.width(16.dp))
                    Text("This only takes a moment.", color = c.ivory.copy(alpha = 0.85f), fontSize = 14.sp)
                }
            },
            confirmButton = {},
        )
        is ImportUi.Summary -> AlertDialog(
            onDismissRequest = vm::dismissImport,
            containerColor = c.surface,
            titleContentColor = c.ivory,
            textContentColor = c.ivory.copy(alpha = 0.85f),
            title = { Text("Import finished") },
            text = { SummaryBody(s.summary) },
            confirmButton = { CWTextButton("Done", vm::dismissImport) },
        )
        ImportUi.Denied -> MessageDialog(
            title = "Contacts not imported",
            text = "ContactWhisper works fine with its own contacts. To import your phone contacts later, open " +
                "Settings > Profile Customization > Import phone contacts. If Android doesn't show the permission " +
                "prompt again, allow Contacts for ContactWhisper in your phone's app settings.",
            onDismiss = vm::dismissImport,
        )
        is ImportUi.Failed -> MessageDialog(
            title = "Import failed",
            text = "Your phone contacts couldn't be read: ${s.message}. Nothing was changed.",
            onDismiss = vm::dismissImport,
        )
    }
}

@Composable
private fun SummaryBody(s: ImportSummary) {
    Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
        Text(
            "Imported ${s.imported} of ${s.scanned} phone contact${if (s.scanned == 1) "" else "s"}.",
            fontSize = 14.sp,
        )
        SummarySection("Already in ContactWhisper (skipped)", s.duplicates, "same phone number or email")
        SummarySection("Missing a name or phone number (skipped)", s.skipped, null)
        SummarySection("Imported, but not an 11-digit mobile number", s.nonStandardPhones, "kept exactly as it was; checked only if you edit that number")
        SummarySection("Same name as an existing contact (imported)", s.sameNameDifferentNumber, null)
    }
}

@Composable
private fun SummarySection(title: String, names: List<String>, note: String?) {
    if (names.isEmpty()) return
    Spacer(Modifier.height(12.dp))
    Text("$title: ${names.size}", fontSize = 13.sp, color = CW.colors.ivory)
    if (note != null) Text(note, fontSize = 12.sp, color = CW.colors.muted)
    val shown = names.take(8).joinToString(", ") + if (names.size > 8) " and ${names.size - 8} more" else ""
    Text(shown, fontSize = 12.sp, color = CW.colors.muted)
}
