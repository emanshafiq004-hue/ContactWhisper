package com.contactwhisper.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.data.CategoryEntity
import com.contactwhisper.app.data.CategoryResult
import com.contactwhisper.app.ui.components.CWIcon
import com.contactwhisper.app.ui.components.CWIconButton
import com.contactwhisper.app.ui.components.CWTextButton
import com.contactwhisper.app.ui.components.CWTextField
import com.contactwhisper.app.ui.components.ConfirmDialog
import com.contactwhisper.app.ui.components.ContactActions
import com.contactwhisper.app.ui.components.ContactCard
import com.contactwhisper.app.ui.components.PanelCard
import com.contactwhisper.app.ui.components.ScreenHeader
import com.contactwhisper.app.ui.theme.CW

private sealed interface CategoryDialog {
    data object Add : CategoryDialog
    data class Rename(val category: CategoryEntity) : CategoryDialog
    data class Delete(val category: CategoryEntity) : CategoryDialog
}

private const val UNCATEGORISED = "Uncategorised"

/**
 * Expandable category rows. Expanding shows that category's contacts with the same cards and gestures as Home.
 * Default categories (Family, Friends, Work, Other) are fixed; custom ones can be renamed or deleted
 * (contacts of a deleted category are safely moved to "Other").
 */
@Composable
fun CategoriesScreen(vm: AppViewModel, actions: ContactActions) {
    val c = CW.colors
    val categories by vm.categories.collectAsStateWithLifecycle()
    val contacts by vm.visibleAll.collectAsStateWithLifecycle()
    val grouped = remember(contacts) { contacts.groupBy { it.category } }
    // shared with the voice assistant ("expand Family") through the ViewModel
    val expandedSet by vm.expandedCategories.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<CategoryDialog?>(null) }
    var dialogError by remember { mutableStateOf<String?>(null) }

    fun closeDialog() {
        dialog = null
        dialogError = null
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Categories",
            onBack = null,
            actions = { CWIconButton(R.drawable.ic_add, "New category", { dialog = CategoryDialog.Add }) },
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            categories.forEach { category ->
                val list = grouped[category.name].orEmpty()
                val isOpen = category.name in expandedSet
                item(key = "cat-${category.id}") {
                    CategoryHeader(
                        name = category.name,
                        count = list.size,
                        open = isOpen,
                        editable = !category.isDefault,
                        onToggle = { vm.toggleCategoryExpanded(category.name) },
                        onRename = { dialog = CategoryDialog.Rename(category) },
                        onDelete = { dialog = CategoryDialog.Delete(category) },
                    )
                }
                if (isOpen) {
                    if (list.isEmpty()) {
                        item(key = "cat-${category.id}-empty") {
                            Text("No contacts in this category.", color = c.muted, fontSize = 13.sp, modifier = Modifier.padding(start = 12.dp, bottom = 4.dp))
                        }
                    }
                    items(list, key = { "cat-${category.id}-${it.id}" }) { contact ->
                        ContactRow(contact, actions, Modifier.animateItem())
                    }
                }
            }

            // Contacts that have no category (it is optional) get their own row so they stay reachable.
            val none = grouped[""].orEmpty()
            if (none.isNotEmpty()) {
                val isOpen = UNCATEGORISED in expandedSet
                item(key = "cat-none") {
                    CategoryHeader(
                        name = UNCATEGORISED,
                        count = none.size,
                        open = isOpen,
                        editable = false,
                        showEditActions = false,
                        onToggle = { vm.toggleCategoryExpanded(UNCATEGORISED) },
                        onRename = {},
                        onDelete = {},
                    )
                }
                if (isOpen) {
                    items(none, key = { "cat-none-${it.id}" }) { contact -> ContactRow(contact, actions, Modifier.animateItem()) }
                }
            }
        }
    }

    when (val d = dialog) {
        null -> Unit
        CategoryDialog.Add -> NameDialog(
            title = "New category",
            initial = "",
            confirmLabel = "Add",
            error = dialogError,
            onConfirm = { name ->
                vm.addCategory(name) { r ->
                    when (r) {
                        CategoryResult.Ok -> closeDialog()
                        is CategoryResult.Error -> dialogError = r.message
                    }
                }
            },
            onDismiss = ::closeDialog,
        )
        is CategoryDialog.Rename -> NameDialog(
            title = "Rename category",
            initial = d.category.name,
            confirmLabel = "Rename",
            error = dialogError,
            onConfirm = { name ->
                vm.renameCategory(d.category.id, name) { r ->
                    when (r) {
                        CategoryResult.Ok -> {
                            vm.renameExpanded(d.category.name, name.trim())
                            closeDialog()
                        }
                        is CategoryResult.Error -> dialogError = r.message
                    }
                }
            },
            onDismiss = ::closeDialog,
        )
        is CategoryDialog.Delete -> ConfirmDialog(
            title = "Delete \"${d.category.name}\"?",
            text = "Contacts in this category are not deleted; they will be moved to \"Other\".",
            confirmLabel = "Delete",
            danger = true,
            onConfirm = {
                vm.deleteCategory(d.category.id) { r ->
                    if (d.category.name in expandedSet) vm.toggleCategoryExpanded(d.category.name)
                    closeDialog()
                    if (r is CategoryResult.Error) vm.snack(r.message)
                }
            },
            onDismiss = ::closeDialog,
        )
    }
}

@Composable
private fun ContactRow(contact: com.contactwhisper.app.dsa.ContactRecord, actions: ContactActions, modifier: Modifier = Modifier) {
    ContactCard(
        modifier = modifier,
        contact = contact,
        onOpen = { actions.open(contact) },
        onEdit = { actions.edit(contact) },
        onCall = { actions.call(contact) },
        onDelete = { actions.delete(contact) },
        onToggleFavorite = { actions.toggleFavorite(contact) },
    )
}

@Composable
private fun CategoryHeader(
    name: String,
    count: Int,
    open: Boolean,
    editable: Boolean,
    onToggle: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    showEditActions: Boolean = true,
) {
    val c = CW.colors
    PanelCard(onClick = onToggle) {
        // Fixed column grid, so nothing about the name, the count or the actions can move the chevron:
        //   [chevron 48dp] [icon 24dp] [name + count: flexible] [actions: always 88dp, empty when not editable]
        Row(
            Modifier
                .fillMaxWidth()
                .height(60.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.width(CHEVRON_COLUMN).fillMaxHeight(), contentAlignment = Alignment.Center) {
                CWIcon(
                    R.drawable.ic_expand_more,
                    if (open) "Collapse $name" else "Expand $name",
                    size = 22.dp,
                    rotation = if (open) 180f else 0f,
                )
            }
            CWIcon(R.drawable.ic_category, null, tint = c.ivory)
            Spacer(Modifier.width(12.dp))
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    name,
                    color = c.ivory,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Text("  $count", color = c.ivory.copy(alpha = 0.7f), fontSize = 14.sp, maxLines = 1)
            }
            Row(Modifier.width(ACTIONS_COLUMN), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                if (showEditActions && editable) {
                    CWIconButton(R.drawable.ic_edit, "Rename $name", onRename, size = 20.dp)
                    CWIconButton(R.drawable.ic_delete, "Delete $name", onDelete, tint = c.danger, size = 20.dp)
                }
            }
        }
    }
}

private val CHEVRON_COLUMN = 48.dp
private val ACTIONS_COLUMN = 96.dp

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    error: String?,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val c = CW.colors
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        titleContentColor = c.ivory,
        textContentColor = c.muted,
        title = { Text(title) },
        text = {
            CWTextField(
                value = text,
                onValueChange = { text = it },
                label = "Category name",
                error = error,
            )
        },
        confirmButton = { CWTextButton(confirmLabel, { onConfirm(text) }) },
        dismissButton = { CWTextButton("Cancel", onDismiss) },
    )
}
