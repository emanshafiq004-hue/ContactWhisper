package com.contactwhisper.app.ui

/** Every navigation destination. Bottom navigation contains exactly the four [tabs]; Settings opens from Home's gear. */
object Routes {
    const val SPLASH = "splash"
    const val SETUP = "setup"

    // bottom-navigation destinations (exactly four)
    const val HOME = "home"
    const val CATEGORIES = "categories"
    const val FAVORITES = "favorites"
    const val BIN = "bin"

    const val DETAILS = "details/{id}"
    const val FORM = "form/{id}"
    const val EMERGENCY = "emergency"

    const val SETTINGS = "settings"
    const val PROFILE = "profile"
    const val APPEARANCE = "appearance"
    const val APP_LOCK = "applock"
    const val ABOUT = "about"

    /** Id used by [form] for "new contact". */
    const val NEW_CONTACT = -1L

    fun details(id: Long) = "details/$id"
    fun form(id: Long) = "form/$id"

    val tabs: Set<String> = setOf(HOME, CATEGORIES, FAVORITES, BIN)
}
