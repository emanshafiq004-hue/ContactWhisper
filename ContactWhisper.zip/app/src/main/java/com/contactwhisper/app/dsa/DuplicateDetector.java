package com.contactwhisper.app.dsa;

import java.util.ArrayList;
import java.util.List;

/**
 * Finds active contacts that a candidate may duplicate, using the hash indexes of {@link ContactIndex}.
 *
 *  - Phone: compared on the normalised phone key (digits, last 10).
 *  - E-mail: compared case-insensitively.
 *  - Name: compared case/whitespace-insensitively; reported only as a soft (non-strong) match,
 *    because two different people can share a name.
 *
 * This class never deletes or merges anything; it only reports. Cost: three O(1) hash lookups.
 */
public final class DuplicateDetector {
    private DuplicateDetector() {
    }

    /**
     * @param excludeId id of the contact being edited (so it does not match itself), or -1 for none.
     */
    public static List<DuplicateMatch> detect(ContactIndex index, ContactRecord candidate, long excludeId) {
        List<DuplicateMatch> out = new ArrayList<>();
        if (!ContactAlgorithms.phoneKey(candidate.getPhone()).isEmpty()) {
            for (ContactRecord r : index.findByPhone(candidate.getPhone())) {
                if (r.getId() != excludeId) out.add(new DuplicateMatch(r, DuplicateMatch.Reason.PHONE));
            }
        }
        if (!ContactAlgorithms.emailKey(candidate.getEmail()).isEmpty()) {
            for (ContactRecord r : index.findByEmail(candidate.getEmail())) {
                if (r.getId() != excludeId) out.add(new DuplicateMatch(r, DuplicateMatch.Reason.EMAIL));
            }
        }
        if (!ContactAlgorithms.nameKey(candidate.getName()).isEmpty()) {
            for (ContactRecord r : index.findByName(candidate.getName())) {
                if (r.getId() != excludeId) out.add(new DuplicateMatch(r, DuplicateMatch.Reason.NAME));
            }
        }
        return out;
    }

    /** True when at least one phone/e-mail match exists (used to block Bin restores). */
    public static boolean hasStrongMatch(List<DuplicateMatch> matches) {
        for (DuplicateMatch m : matches) if (m.isStrong()) return true;
        return false;
    }
}
