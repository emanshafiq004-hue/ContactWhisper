package com.contactwhisper.app.data

import androidx.room.withTransaction
import com.contactwhisper.app.domain.ContactValidator
import com.contactwhisper.app.dsa.ContactAlgorithms
import com.contactwhisper.app.dsa.ContactIndex
import com.contactwhisper.app.dsa.ContactRecord
import com.contactwhisper.app.dsa.DuplicateDetector
import com.contactwhisper.app.dsa.DuplicateMatch
import com.contactwhisper.app.dsa.SortMode
import com.contactwhisper.app.dsa.UndoRedoManager
import com.contactwhisper.app.dsa.UndoableAction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** What the Add/Edit form hands to the repository. */
data class ContactDraft(
    val name: String,
    val phone: String,
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val category: String = "",
)

data class HistoryState(val canUndo: Boolean = false, val canRedo: Boolean = false)

data class HistoryOutcome(val performed: Boolean, val message: String)

sealed interface RestoreResult {
    data object Restored : RestoreResult
    data class Conflict(val name: String, val matches: List<DuplicateMatch>) : RestoreResult
    data object NotFound : RestoreResult
}

/** One phonebook entry read from the Android Contacts Provider (nothing is stored until it is imported). */
data class ImportedContact(val name: String, val phones: List<String>, val emails: List<String>)

/**
 * Outcome of a phonebook import. Every list holds display names so the summary screen can show exactly what
 * happened to each entry.
 *  - duplicates:  skipped because the same phone/e-mail already exists (active contact or Bin)
 *  - skipped:     skipped because a name or a phone number was missing (the data model needs both)
 *  - nonStandardPhones: imported unchanged, but the number is not an 11-digit Pakistani mobile; it stays visible
 *                 and is only validated against the mobile rule if the user edits that number
 *  - sameNameDifferentNumber: imported, but another contact already has that name
 */
data class ImportSummary(
    val scanned: Int,
    val imported: Int,
    val duplicates: List<String>,
    val skipped: List<String>,
    val nonStandardPhones: List<String>,
    val sameNameDifferentNumber: List<String>,
)

data class BulkRestoreResult(val restored: Int, val conflictedNames: List<String>, val missing: Int)

sealed interface CategoryResult {
    data object Ok : CategoryResult
    data class Error(val message: String) : CategoryResult
}

/**
 * Single entry point for contact data.
 *
 *  - Room/SQLite is the durable source of truth.
 *  - Every successful write is mirrored into the in-memory Java [ContactIndex] (custom linked list +
 *    hash tables) while holding [mutex], then published, so DB, DSA index and UI never drift apart.
 *  - Undo/Redo uses the two custom Java stacks in [UndoRedoManager] (memory only: resets on process restart).
 *  - Search/sort for the UI and for the future voice assistant go through [search].
 */
class ContactRepository(private val db: AppDatabase) {
    private val dao = db.contactDao()
    private val categoryDao = db.categoryDao()
    private val index = ContactIndex()
    private val undoRedo = UndoRedoManager()
    private val mutex = Mutex()

    private val _contacts = MutableStateFlow<List<ContactRecord>>(emptyList())

    /** Snapshot of every ACTIVE contact. */
    val contacts: StateFlow<List<ContactRecord>> = _contacts.asStateFlow()

    private val _history = MutableStateFlow(HistoryState())
    val history: StateFlow<HistoryState> = _history.asStateFlow()

    val binItems: Flow<List<ContactEntity>> = dao.observeBin()
    val categories: Flow<List<CategoryEntity>> = categoryDao.observeAll()

    private fun now() = System.currentTimeMillis()

    private fun publish() {
        _contacts.value = index.snapshot().toList()
        _history.value = HistoryState(undoRedo.canUndo(), undoRedo.canRedo())
    }

    // ------------------------------------------------------------------ loading

    /** Rebuilds the DSA structures from Room. Called at startup and after bulk changes. */
    suspend fun load() = withContext(Dispatchers.IO) {
        mutex.withLock { reloadLocked() }
    }

    private suspend fun reloadLocked() {
        index.rebuild(dao.getActive().map { it.toRecord() })
        publish()
    }

    suspend fun ensureDefaultCategories() = withContext(Dispatchers.IO) {
        if (categoryDao.count() == 0) {
            EmergencySeed.defaultCategories.forEach { categoryDao.insert(CategoryEntity(name = it, isDefault = true)) }
        }
    }

    // ------------------------------------------------------------------ search / duplicates (reusable by voice later)

    /** Universal search + sort through the custom linked list / merge sort. Cheap enough for any thread. */
    fun search(query: String, mode: SortMode): List<ContactRecord> =
        index.search(query, mode).toList()

    fun getActive(id: Long): ContactRecord? = index.get(id)

    fun findDuplicates(draft: ContactDraft, excludeId: Long): List<DuplicateMatch> {
        val candidate = ContactRecord(
            0L, draft.name.trim(), draft.phone.trim(), draft.email.trim(), draft.address.trim(),
            draft.notes.trim(), draft.category, false, 0L, 0L,
        )
        return DuplicateDetector.detect(index, candidate, excludeId)
    }

    // ------------------------------------------------------------------ create / update / favorite / delete

    suspend fun addContact(d: ContactDraft): ContactRecord = withContext(Dispatchers.IO) {
        mutex.withLock {
            val ts = now()
            val entity = ContactEntity(
                name = d.name.trim(), phone = ContactValidator.phoneForSave(d.phone), email = d.email.trim(),
                address = d.address.trim(), notes = d.notes.trim(), category = d.category,
                createdAt = ts, updatedAt = ts,
            )
            val id = db.withTransaction { dao.insert(entity) }
            val record = entity.copy(id = id).toRecord()
            index.add(record)
            undoRedo.record(UndoableAction.add(record))
            publish()
            record
        }
    }

    /** Returns the updated record, or null if the contact is no longer active. */
    suspend fun updateContact(id: Long, d: ContactDraft): ContactRecord? = withContext(Dispatchers.IO) {
        mutex.withLock {
            val old = index.get(id)
            if (old == null) {
                null
            } else {
                val updated = old.withDetails(
                    d.name.trim(), ContactValidator.phoneForSave(d.phone), d.email.trim(), d.address.trim(),
                    d.notes.trim(), d.category, now(),
                )
                if (old.withUpdatedAt(updated.updatedAt) == updated) {
                    old // nothing changed: no DB write, no history entry
                } else {
                    db.withTransaction { dao.update(updated.toEntity()) }
                    index.update(updated)
                    undoRedo.record(
                        if (old.differsOnlyInCategory(updated)) UndoableAction.category(old, updated)
                        else UndoableAction.edit(old, updated),
                    )
                    publish()
                    updated
                }
            }
        }
    }

    suspend fun setFavorite(id: Long, favorite: Boolean) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val old = index.get(id)
            if (old != null && old.isFavorite != favorite) {
                val updated = old.withFavorite(favorite)
                db.withTransaction { dao.update(updated.toEntity()) }
                index.update(updated)
                undoRedo.record(UndoableAction.favorite(old, updated))
                publish()
            }
        }
    }

    /** Moves the contact to the Recycle Bin (soft delete). Returns the record, or null if not active. */
    suspend fun moveToBin(id: Long): ContactRecord? = withContext(Dispatchers.IO) {
        mutex.withLock {
            val record = index.get(id)
            if (record != null) {
                db.withTransaction { dao.softDelete(id, now()) }
                index.remove(id)
                undoRedo.record(UndoableAction.delete(record))
                publish()
            }
            record
        }
    }

    // ------------------------------------------------------------------ Undo / Redo

    /**
     * True when the newest Undo entry is "delete [id]". The delete snackbar uses this so its Undo button only
     * pops the history when it would really reverse that delete (not some later action).
     */
    suspend fun undoTargetsDelete(id: Long): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            val top = undoRedo.peekUndo()
            top != null && top.type == UndoableAction.Type.DELETE && top.contactId == id
        }
    }

    suspend fun undo(): HistoryOutcome = withContext(Dispatchers.IO) {
        mutex.withLock {
            val action = undoRedo.peekUndo()
            if (action == null) {
                HistoryOutcome(false, "Nothing to undo")
            } else {
                try {
                    if (applyAction(action, undoing = true)) {
                        undoRedo.commitUndo()
                        publish()
                        HistoryOutcome(true, "Undone: ${action.label}")
                    } else {
                        undoRedo.discardUndo()
                        publish()
                        HistoryOutcome(false, "Couldn't undo ${action.label.lowercase()}: that contact is no longer available")
                    }
                } catch (e: Exception) {
                    HistoryOutcome(false, "Undo failed: ${e.message ?: "database error"}")
                }
            }
        }
    }

    suspend fun redo(): HistoryOutcome = withContext(Dispatchers.IO) {
        mutex.withLock {
            val action = undoRedo.peekRedo()
            if (action == null) {
                HistoryOutcome(false, "Nothing to redo")
            } else {
                try {
                    if (applyAction(action, undoing = false)) {
                        undoRedo.commitRedo()
                        publish()
                        HistoryOutcome(true, "Redone: ${action.label}")
                    } else {
                        undoRedo.discardRedo()
                        publish()
                        HistoryOutcome(false, "Couldn't redo ${action.label.lowercase()}: that contact is no longer available")
                    }
                } catch (e: Exception) {
                    HistoryOutcome(false, "Redo failed: ${e.message ?: "database error"}")
                }
            }
        }
    }

    /** Applies one history step to Room AND the DSA index. Returns false when the target is gone. */
    private suspend fun applyAction(action: UndoableAction, undoing: Boolean): Boolean {
        val id = action.contactId
        return when (action.type) {
            UndoableAction.Type.ADD ->
                if (undoing) {
                    db.withTransaction { dao.hardDelete(id) }
                    index.remove(id)
                    true
                } else {
                    val record = action.after
                    db.withTransaction { dao.insert(record.toEntity()) }
                    if (index.get(id) == null) index.add(record) else index.update(record)
                    true
                }

            UndoableAction.Type.DELETE ->
                if (undoing) {
                    val row = dao.getById(id)
                    when {
                        row == null -> false // permanently deleted or expired from the Bin
                        row.deletedAt == null -> {
                            if (index.get(id) == null) index.add(row.toRecord())
                            true
                        }
                        else -> {
                            db.withTransaction { dao.clearDeleted(id) }
                            index.add(row.copy(deletedAt = null).toRecord())
                            true
                        }
                    }
                } else if (index.get(id) == null) {
                    false
                } else {
                    db.withTransaction { dao.softDelete(id, now()) }
                    index.remove(id)
                    true
                }

            // Restoring from the Bin is itself undoable: undo sends the contact back to the Bin, redo restores it
            // again. Room is re-read (never the stale snapshot) and a permanently deleted contact is simply gone.
            UndoableAction.Type.RESTORE ->
                if (undoing) {
                    if (index.get(id) == null) {
                        false
                    } else {
                        db.withTransaction { dao.softDelete(id, now()) }
                        index.remove(id)
                        true
                    }
                } else {
                    val row = dao.getById(id)
                    when {
                        row == null -> false
                        row.deletedAt == null -> {
                            if (index.get(id) == null) index.add(row.toRecord())
                            true
                        }
                        else -> {
                            db.withTransaction { dao.clearDeleted(id) }
                            index.add(row.copy(deletedAt = null).toRecord())
                            true
                        }
                    }
                }

            UndoableAction.Type.EDIT, UndoableAction.Type.FAVORITE, UndoableAction.Type.CATEGORY -> {
                val target = if (undoing) action.before else action.after
                if (index.get(id) == null) {
                    false
                } else {
                    db.withTransaction { dao.update(target.toEntity()) }
                    index.update(target)
                    true
                }
            }
        }
    }

    // ------------------------------------------------------------------ Recycle Bin

    suspend fun restore(id: Long): RestoreResult = withContext(Dispatchers.IO) {
        mutex.withLock { restoreLocked(id) }
    }

    private suspend fun restoreLocked(id: Long): RestoreResult {
        val row = dao.getById(id)
        if (row == null || row.deletedAt == null) return RestoreResult.NotFound
        val record = row.toRecord()
        // Phone/e-mail clashes block the restore (never silently merged or deleted).
        // A shared name alone is not a conflict: two different people may have the same name.
        val strong = DuplicateDetector.detect(index, record, record.id).filter { it.isStrong }
        if (strong.isNotEmpty()) return RestoreResult.Conflict(row.name, strong)
        db.withTransaction { dao.clearDeleted(id) }
        val restored = record.withUpdatedAt(record.updatedAt)
        index.add(restored)
        undoRedo.record(UndoableAction.restore(restored))
        publish()
        return RestoreResult.Restored
    }

    /** Restores every non-conflicting entry; conflicting ones stay in the Bin and are reported. */
    suspend fun restoreAll(ids: List<Long>): BulkRestoreResult = withContext(Dispatchers.IO) {
        mutex.withLock {
            var restored = 0
            var missing = 0
            val conflicts = mutableListOf<String>()
            for (id in ids) {
                when (val r = restoreLocked(id)) {
                    RestoreResult.Restored -> restored++
                    is RestoreResult.Conflict -> conflicts += r.name
                    RestoreResult.NotFound -> missing++
                }
            }
            BulkRestoreResult(restored, conflicts, missing)
        }
    }

    /**
     * Permanently deletes the given Bin entries (callers must have obtained explicit user confirmation).
     *
     * Permanent deletion is irreversible, so in the same locked step every Undo AND Redo entry that mentions
     * one of these contact ids (an old Add, Edit, Delete, Restore ...) is purged from both stacks: nothing in the
     * history can ever re-create them. Only entries that really are in the Bin are touched.
     */
    suspend fun permanentlyDelete(ids: List<Long>): Int = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (ids.isEmpty()) {
                0
            } else {
                val binned = dao.binIdsAmong(ids.distinct())
                val removed = if (binned.isEmpty()) 0 else db.withTransaction { dao.hardDeleteBinItems(binned) }
                undoRedo.purgeContacts(binned)
                publish()
                removed
            }
        }
    }

    /** True when any Undo/Redo entry still mentions this contact id (used by tests and diagnostics). */
    suspend fun historyMentions(id: Long): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock { undoRedo.mentions(id) }
    }

    /** Removes Bin entries older than the 30-day retention. Safe to call from the app or from WorkManager. */
    suspend fun purgeExpired(nowMillis: Long = now()): Int = withContext(Dispatchers.IO) {
        mutex.withLock {
            val cutoff = nowMillis - RETENTION_MS
            val expired = dao.expiredIds(cutoff)
            val removed = db.withTransaction { dao.purgeBefore(cutoff) }
            undoRedo.purgeContacts(expired)
            publish()
            removed
        }
    }

    // ------------------------------------------------------------------ phonebook import

    /**
     * Stores phonebook entries as ordinary contacts. Existing data always wins: a phone or e-mail that already
     * exists (active contact or Bin) is skipped, user edits are never overwritten, and numbers are saved exactly
     * as the phonebook has them. The DSA index is updated entry by entry under the same lock and everything is
     * written in ONE Room transaction. An import is a bulk operation and is not added to Undo/Redo.
     */
    suspend fun importContacts(items: List<ImportedContact>): ImportSummary = withContext(Dispatchers.IO) {
        mutex.withLock {
            val duplicates = mutableListOf<String>()
            val skipped = mutableListOf<String>()
            val nonStandard = mutableListOf<String>()
            val sameName = mutableListOf<String>()
            val toInsert = mutableListOf<ContactEntity>()
            val binRows = dao.getBin()
            val binPhones = binRows.map { ContactAlgorithms.phoneKey(it.phone) }.toHashSet()
            val binEmails = binRows.map { ContactAlgorithms.emailKey(it.email) }
                .filter { it.isNotEmpty() }.toHashSet()
            val ts = now()
            var counter = 0L
            for (item in items) {
                val name = item.name.trim().take(ContactValidator.MAX_NAME)
                val phones = item.phones.map { it.trim() }.filter {
                    ContactAlgorithms.normalizePhone(it).isNotEmpty()
                }.distinct()
                val emails = item.emails.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                val label = name.ifEmpty { phones.firstOrNull() ?: "(unnamed)" }
                if (name.isEmpty() || phones.isEmpty()) {
                    skipped += label
                    continue
                }
                val primaryEmail = emails.firstOrNull { ContactValidator.validateEmail(it) == null } ?: ""
                val extra = buildList {
                    if (phones.size > 1) add("Other numbers: " + phones.drop(1).joinToString(", "))
                    val otherEmails = emails.filter { it != primaryEmail }
                    if (otherEmails.isNotEmpty()) add("Other emails: " + otherEmails.joinToString(", "))
                }.joinToString("\n").take(ContactValidator.MAX_NOTES)
                val candidate = ContactRecord(0L, name, phones[0], primaryEmail, "", extra, "", false, ts, ts)
                val strong = DuplicateDetector.detect(index, candidate, NO_EXCLUDE).filter { it.isStrong }
                val pKey = ContactAlgorithms.phoneKey(phones[0])
                val eKey = ContactAlgorithms.emailKey(primaryEmail)
                val inBin = pKey in binPhones || (eKey.isNotEmpty() && eKey in binEmails)
                if (strong.isNotEmpty() || inBin) {
                    duplicates += name
                    continue
                }
                if (DuplicateDetector.detect(index, candidate, NO_EXCLUDE).any { !it.isStrong }) sameName += name
                if (ContactValidator.normalizePkMobile(phones[0]) == null) nonStandard += name
                val entity = ContactEntity(
                    name = name, phone = phones[0], email = primaryEmail, notes = extra,
                    createdAt = ts - counter, updatedAt = ts - counter,
                )
                toInsert += entity
                // Placeholder with a negative temporary id so the next entries of this batch are checked against
                // it (the same person listed twice is imported once). Replaced by the real row below.
                index.add(candidate.withId(-(++counter)))
            }
            // Remove the temporary placeholders, then write the real rows and index them with their real ids.
            for (c in 1..counter) index.remove(-c)
            val ids = if (toInsert.isEmpty()) emptyList() else db.withTransaction { toInsert.map { dao.insert(it) } }
            ids.forEachIndexed { i, id -> index.add(toInsert[i].copy(id = id).toRecord()) }
            publish()
            ImportSummary(items.size, toInsert.size, duplicates, skipped, nonStandard, sameName)
        }
    }

    // ------------------------------------------------------------------ categories

    suspend fun addCategory(rawName: String): CategoryResult = withContext(Dispatchers.IO) {
        val name = rawName.trim()
        when {
            name.isEmpty() -> CategoryResult.Error("Category name is required")
            name.length > MAX_CATEGORY_LENGTH -> CategoryResult.Error("Use at most $MAX_CATEGORY_LENGTH characters")
            categoryDao.findByName(name) != null -> CategoryResult.Error("A category named \"$name\" already exists")
            else -> {
                categoryDao.insert(CategoryEntity(name = name))
                CategoryResult.Ok
            }
        }
    }

    /** Renames a custom category and every contact (active or in the Bin) that uses it. */
    suspend fun renameCategory(id: Long, rawName: String): CategoryResult = withContext(Dispatchers.IO) {
        mutex.withLock {
            val current = categoryDao.getById(id)
            val name = rawName.trim()
            when {
                current == null -> CategoryResult.Error("Category not found")
                current.isDefault -> CategoryResult.Error("Default categories can't be renamed")
                name.isEmpty() -> CategoryResult.Error("Category name is required")
                name.length > MAX_CATEGORY_LENGTH -> CategoryResult.Error("Use at most $MAX_CATEGORY_LENGTH characters")
                categoryDao.findByName(name)?.let { it.id != id } == true ->
                    CategoryResult.Error("A category named \"$name\" already exists")
                else -> {
                    db.withTransaction {
                        categoryDao.rename(id, name)
                        dao.renameCategory(current.name, name)
                    }
                    undoRedo.clear() // stored snapshots would still carry the old category name
                    reloadLocked()
                    CategoryResult.Ok
                }
            }
        }
    }

    /** Deletes a custom category; its contacts are safely moved to "Other". */
    suspend fun deleteCategory(id: Long): CategoryResult = withContext(Dispatchers.IO) {
        mutex.withLock {
            val current = categoryDao.getById(id)
            when {
                current == null -> CategoryResult.Error("Category not found")
                current.isDefault -> CategoryResult.Error("Default categories can't be deleted")
                else -> {
                    db.withTransaction {
                        dao.renameCategory(current.name, EmergencySeed.FALLBACK_CATEGORY)
                        categoryDao.delete(id)
                    }
                    undoRedo.clear()
                    reloadLocked()
                    CategoryResult.Ok
                }
            }
        }
    }

    companion object {
        const val RETENTION_DAYS = 30
        const val RETENTION_MS = RETENTION_DAYS * 24L * 60L * 60L * 1000L
        const val MAX_CATEGORY_LENGTH = 30
        private const val NO_EXCLUDE = Long.MIN_VALUE
        private const val DAY_MS = 24L * 60L * 60L * 1000L

        /** Whole days remaining before a Bin entry is purged (never negative). */
        fun daysLeft(deletedAt: Long, nowMillis: Long = System.currentTimeMillis()): Int {
            val remaining = RETENTION_MS - (nowMillis - deletedAt)
            return if (remaining <= 0) 0 else ((remaining + DAY_MS - 1) / DAY_MS).toInt()
        }
    }
}
