package com.contactwhisper.app.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.contactwhisper.app.data.AppTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Things only the UI layer can do (it owns the permission launcher, navigation and the activity context). */
sealed interface VoiceUiEffect {
    data object RequestPermission : VoiceUiEffect
    data class Navigate(val screen: VoiceScreen) : VoiceUiEffect
    data object Back : VoiceUiEffect
    data class OpenDetails(val id: Long) : VoiceUiEffect
    data class Dial(val number: String) : VoiceUiEffect
}

/**
 * Glue between the pure [VoiceConversation] and Android. Main thread only (it lives in the ViewModel).
 *
 * Continuous session: while a session is open and the conversation is waiting for input, this class keeps one
 * recognition request running at all times and starts the next one the moment one ends (a result, silence, a
 * timeout). It never records
 *   - while the assistant is speaking (recognition is paused, then resumes from the TTS completion callback, so the
 *     assistant can't transcribe its own sentence),
 *   - while a command is executing or a permission dialog is up, nor
 *   - after the session ended: closing the assistant, "close", or the app leaving the foreground ([onStop]).
 *
 * Android's SpeechRecognizer is sequential, not an always-open stream: there is a short gap between requests, the
 * device's speech service may play its own start/stop beep, and some services need a network connection. The
 * app can't remove those service-dependent limits.
 */
class VoiceAssistant(
    context: Context,
    private val scope: CoroutineScope,
    backend: VoiceBackend,
    private val executor: suspend (ActionRequest) -> VoiceResult,
) {
    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private val conversation = VoiceConversation(backend)

    private val _snapshot = MutableStateFlow(VoiceSnapshot())
    val snapshot: StateFlow<VoiceSnapshot> = _snapshot.asStateFlow()

    private val _ui = MutableSharedFlow<VoiceUiEffect>(extraBufferCapacity = 8)
    val ui: SharedFlow<VoiceUiEffect> = _ui.asSharedFlow()

    // ---- recognition bookkeeping
    private var tokenCounter = 0
    private var activeToken = 0 // 0 = no recognition request is running; a result is accepted once, for this token only
    private var startedAt = 0L
    private var quickFailures = 0
    private var errorStreak = 0
    private var restartPending: Runnable? = null
    private var pendingClose = false

    private val tts = SpeechOutput(
        appContext,
        onBusy = {
            stopRecognizer()
            publish()
        },
        onIdle = {
            if (pendingClose) {
                pendingClose = false
                perform(conversation.finishClose())
            } else {
                syncListening()
            }
        },
    )

    private val speech = SpeechInput(appContext, object : SpeechInput.Listener {
        override fun onPartial(token: Int, text: String) {
            if (token != activeToken) return
            conversation.onPartial(text)
            publish()
        }

        override fun onResults(token: Int, alternatives: List<String>) {
            if (token == 0 || token != activeToken) return // late / duplicate callback
            activeToken = 0
            val usable = alternatives.filter { it.isNotBlank() }
            if (usable.isEmpty()) {
                noteSilence()
            } else {
                quickFailures = 0
                errorStreak = 0
                perform(conversation.onTranscript(usable))
            }
        }

        override fun onFailure(token: Int, kind: FailureKind) {
            if (token == 0 || token != activeToken) return
            activeToken = 0
            when (kind) {
                FailureKind.NO_SPEECH -> noteSilence() // silence is not a command: say nothing, listen again
                FailureKind.NOT_UNDERSTOOD -> {
                    quickFailures = 0
                    errorStreak = 0
                    perform(conversation.onNotUnderstood())
                }
                FailureKind.PERMISSION -> perform(conversation.onRecognizerUnavailable(permission = true))
                FailureKind.UNAVAILABLE -> perform(conversation.onRecognizerUnavailable(permission = false))
                FailureKind.BUSY, FailureKind.NETWORK, FailureKind.OTHER -> {
                    errorStreak++
                    if (errorStreak >= MAX_ERROR_STREAK) perform(conversation.onRecognizerUnavailable(permission = false))
                    else restartAfter(RETRY_BACKOFF_MS * errorStreak)
                }
            }
        }
    })

    private fun env() = VoiceEnvironment(
        hasPermission = ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED,
        recognitionAvailable = speech.isAvailable(),
    )

    private fun publish() {
        _snapshot.value = conversation.snapshot.copy(listening = activeToken != 0, speaking = tts.isBusy)
    }

    // ------------------------------------------------------------------ listening control

    /** Decides, from the conversation and the speaker, whether a recognition request should be running. */
    private fun syncListening() {
        val want = conversation.wantsInput && !tts.isBusy && !pendingClose
        if (want) {
            if (activeToken == 0 && restartPending == null) startRecognizer()
        } else {
            stopRecognizer()
        }
        publish()
    }

    private fun startRecognizer() {
        tokenCounter++
        activeToken = tokenCounter
        startedAt = SystemClock.elapsedRealtime()
        speech.start(activeToken)
    }

    private fun stopRecognizer() {
        restartPending?.let { handler.removeCallbacks(it) }
        restartPending = null
        if (activeToken != 0) {
            activeToken = 0
            speech.cancel()
        }
    }

    /** An empty result / timeout. Restart at once; only back off if the service keeps failing instantly. */
    private fun noteSilence() {
        val elapsed = SystemClock.elapsedRealtime() - startedAt
        if (elapsed < QUICK_END_MS) {
            quickFailures++
            if (quickFailures >= MAX_QUICK_FAILURES) {
                perform(conversation.onRecognizerUnavailable(permission = false))
                return
            }
            restartAfter(RETRY_BACKOFF_MS * quickFailures)
        } else {
            quickFailures = 0
            perform(conversation.onSilence())
        }
    }

    private fun restartAfter(delayMs: Long) {
        restartPending?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            restartPending = null
            syncListening()
        }
        restartPending = r
        handler.postDelayed(r, delayMs)
        publish()
    }

    // ------------------------------------------------------------------ effects

    private fun perform(effects: List<VoiceEffect>) {
        for (e in effects) {
            when (e) {
                is VoiceEffect.Speak -> tts.speak(e.text)
                VoiceEffect.RequestPermission -> _ui.tryEmit(VoiceUiEffect.RequestPermission)
                is VoiceEffect.Navigate -> _ui.tryEmit(VoiceUiEffect.Navigate(e.screen))
                VoiceEffect.Back -> _ui.tryEmit(VoiceUiEffect.Back)
                is VoiceEffect.OpenDetails -> _ui.tryEmit(VoiceUiEffect.OpenDetails(e.id))
                is VoiceEffect.Dial -> _ui.tryEmit(VoiceUiEffect.Dial(e.number))
                is VoiceEffect.Execute -> scope.launch {
                    val result = try {
                        executor(e.request)
                    } catch (ex: kotlin.coroutines.cancellation.CancellationException) {
                        throw ex
                    } catch (ex: Exception) {
                        VoiceResult.fail("Something went wrong, so nothing was changed.")
                    }
                    perform(conversation.onExecutionResult(result))
                }
                VoiceEffect.CloseAfterSpeech -> {
                    if (tts.isBusy) pendingClose = true else perform(conversation.finishClose())
                }
                VoiceEffect.CloseNow -> {
                    pendingClose = false
                    quickFailures = 0
                    errorStreak = 0
                    stopRecognizer()
                    tts.dropQueued() // the sentence in progress finishes; nothing stale follows
                }
            }
        }
        syncListening()
    }

    // ------------------------------------------------------------------ input from the UI

    val isActive: Boolean get() = conversation.isActive

    /** The microphone icon in the search field, or the two-finger swipe up. Ignored while a session is already open. */
    fun open() = perform(conversation.open(env()))

    fun onPermissionResult(granted: Boolean) = perform(conversation.onPermissionResult(granted))

    fun selectChoice(id: String) = touch { conversation.onChoiceTapped(id) }
    fun chooseAction(action: VoiceAction) = touch { conversation.onActionTapped(action) }
    fun chooseField(field: EditField) = touch { conversation.onFieldTapped(field) }
    fun chooseEmergencyField(field: EmergencyField) = touch { conversation.onEmergencyFieldTapped(field) }
    fun chooseTheme(theme: AppTheme) = touch { conversation.onThemeTapped(theme) }
    fun confirm() = touch { conversation.onYes() }
    fun decline() = touch { conversation.onNo() }
    fun cancelOperation() = touch { conversation.onCancelOperation() }
    fun submitText(text: String) = touch { conversation.onTypedText(text) }

    /** A touch replaces whatever question was pending: lines queued for it are dropped, the current one finishes. */
    private inline fun touch(block: () -> List<VoiceEffect>) {
        tts.dropQueued()
        perform(block())
    }

    /** The visible Close / Back control. The session ends; a sentence already in progress is allowed to finish. */
    fun close() = perform(conversation.onClose())

    /** The app left the foreground: stop recording AND speaking immediately and end the session. */
    fun onStop() {
        perform(conversation.onInterrupted())
        tts.stop()
        stopRecognizer()
        publish()
    }

    fun release() {
        stopRecognizer()
        speech.release()
        tts.shutdown()
    }

    companion object {
        /** A request that ends sooner than this without a result is treated as a service hiccup, not as silence. */
        private const val QUICK_END_MS = 400L
        private const val MAX_QUICK_FAILURES = 8
        private const val MAX_ERROR_STREAK = 5
        private const val RETRY_BACKOFF_MS = 300L
    }
}
