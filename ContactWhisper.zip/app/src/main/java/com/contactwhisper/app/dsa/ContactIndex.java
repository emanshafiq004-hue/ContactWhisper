package com.contactwhisper.app.dsa;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * The in-memory working set: ONE {@link ContactLinkedList} that owns the records plus three
 * {@link ContactHashTable} indexes (phone key, e-mail key, name key). Every mutation updates the list
 * and all indexes together so they cannot drift apart.
 *
 * Room/SQLite stays the durable source of truth; {@link #rebuild} refills this structure from it.
 * Methods are synchronized because the repository reads (search) and writes from different coroutines.
 *
 * Lookup costs: findByPhone / findByEmail / findByName are O(1) average hash lookups + O(1) per match
 * resolved through {@link #get} (O(n) list walk) -> practical duplicate checks stay cheap for phone-sized data.
 */
public final class ContactIndex {
    private final ContactLinkedList list = new ContactLinkedList();
    private final ContactHashTable phoneIndex = new ContactHashTable();
    private final ContactHashTable emailIndex = new ContactHashTable();
    private final ContactHashTable nameIndex = new ContactHashTable();

    public synchronized int size() {
        return list.size();
    }

    /** Clears everything and loads the given active records (e.g. from Room). */
    public synchronized void rebuild(Collection<ContactRecord> records) {
        list.clear();
        phoneIndex.clear();
        emailIndex.clear();
        nameIndex.clear();
        for (ContactRecord r : records) {
            list.insertLast(r);
            indexKeys(r);
        }
    }

    /** Adds a new record. Throws if a record with the same id is already present. */
    public synchronized void add(ContactRecord record) {
        if (list.contains(record.getId())) {
            throw new IllegalArgumentException("duplicate id " + record.getId());
        }
        list.insertFirst(record);
        indexKeys(record);
    }

    /** Replaces the record with the same id and refreshes its index keys. Returns false if absent. */
    public synchronized boolean update(ContactRecord record) {
        ContactRecord old = list.update(record);
        if (old == null) return false;
        unindexKeys(old);
        indexKeys(record);
        return true;
    }

    /** Removes by id; returns the removed record or null. */
    public synchronized ContactRecord remove(long id) {
        ContactRecord removed = list.remove(id);
        if (removed != null) unindexKeys(removed);
        return removed;
    }

    public synchronized ContactRecord get(long id) {
        return list.findById(id);
    }

    public synchronized ContactRecord[] snapshot() {
        return list.toArray();
    }

    /** Universal search + sort entirely through the custom structures. */
    public synchronized ContactRecord[] search(String query, SortMode mode) {
        ContactRecord[] found = ContactAlgorithms.search(list, query);
        return ContactAlgorithms.sort(found, mode);
    }

    // ------------------------------------------------------------------ hash-index lookups

    public synchronized List<ContactRecord> findByPhone(String phone) {
        return resolve(phoneIndex.get(ContactAlgorithms.phoneKey(phone)));
    }

    public synchronized List<ContactRecord> findByEmail(String email) {
        return resolve(emailIndex.get(ContactAlgorithms.emailKey(email)));
    }

    public synchronized List<ContactRecord> findByName(String name) {
        return resolve(nameIndex.get(ContactAlgorithms.nameKey(name)));
    }

    private List<ContactRecord> resolve(long[] ids) {
        List<ContactRecord> out = new ArrayList<>(ids.length);
        for (long id : ids) {
            ContactRecord r = list.findById(id);
            if (r != null) out.add(r);
        }
        return out;
    }

    /** Test hook: do all indexes contain exactly the keys of the records in the list? */
    public synchronized boolean isConsistent() {
        for (ContactRecord r : list) {
            if (!containsId(phoneIndex.get(ContactAlgorithms.phoneKey(r.getPhone())), r.getId())) return false;
            String ek = ContactAlgorithms.emailKey(r.getEmail());
            if (!ek.isEmpty() && !containsId(emailIndex.get(ek), r.getId())) return false;
            if (!containsId(nameIndex.get(ContactAlgorithms.nameKey(r.getName())), r.getId())) return false;
        }
        return true;
    }

    private static boolean containsId(long[] ids, long id) {
        for (long x : ids) if (x == id) return true;
        return false;
    }

    private void indexKeys(ContactRecord r) {
        phoneIndex.put(ContactAlgorithms.phoneKey(r.getPhone()), r.getId());
        emailIndex.put(ContactAlgorithms.emailKey(r.getEmail()), r.getId());
        nameIndex.put(ContactAlgorithms.nameKey(r.getName()), r.getId());
    }

    private void unindexKeys(ContactRecord r) {
        phoneIndex.remove(ContactAlgorithms.phoneKey(r.getPhone()), r.getId());
        emailIndex.remove(ContactAlgorithms.emailKey(r.getEmail()), r.getId());
        nameIndex.remove(ContactAlgorithms.nameKey(r.getName()), r.getId());
    }
}
