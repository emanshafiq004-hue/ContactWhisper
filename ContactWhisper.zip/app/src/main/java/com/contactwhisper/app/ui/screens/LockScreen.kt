package com.contactwhisper.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.auth.LocalAuth
import com.contactwhisper.app.data.LockMethod
import com.contactwhisper.app.ui.components.CWButton
import com.contactwhisper.app.ui.components.CWTextButton
import com.contactwhisper.app.ui.theme.CW
import kotlinx.coroutines.delay

/**
 * Shown instead of the app while App Lock is enabled and the app is locked (cold start, or back after
 * [AppViewModel.RELOCK_AFTER_MS] in the background). No contact data is composed behind it.
 */
@Composable
fun LockScreen(vm: AppViewModel, lifecycle: Lifecycle) {
    val c = CW.colors
    val auth = LocalAuth.current
    val settings by vm.settings.collectAsStateWithLifecycle()

    fun unlock() {
        auth.authenticate("Unlock ContactWhisper") { ok -> if (ok) vm.onAppUnlocked() }
    }

    // Prompt automatically once the activity is actually resumed (a prompt can't be shown before that).
    LaunchedEffect(Unit) {
        while (!lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) delay(100)
        unlock()
    }

    val systemAvailable = auth.systemAuthAvailable()
    val noWayToUnlock = !systemAvailable && !settings.hasPin

    Box(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(
                painter = painterResource(R.drawable.app_icon),
                contentDescription = null,
                modifier = Modifier.size(96.dp),
            )
            Text("ContactWhisper is locked", color = c.ivory, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (noWayToUnlock) {
                Text(
                    "App Lock is turned on, but this phone has no screen lock, fingerprint or app PIN to unlock with. " +
                        "You can turn App Lock off here, or add a screen lock in Android settings.",
                    color = c.muted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(4.dp))
                CWButton("Turn off App Lock", onClick = { vm.setAppLockEnabled(false) })
            } else {
                Text("Authenticate to see your contacts.", color = c.muted, fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                CWButton("Unlock", onClick = { unlock() })
                // Forgotten-PIN recovery: the phone's own fingerprint / screen lock still works.
                if (settings.lockMethod == LockMethod.PIN && systemAvailable) {
                    CWTextButton(
                        "Use fingerprint / screen lock instead",
                        onClick = {
                            auth.authenticateWithSystem("Unlock ContactWhisper") { ok -> if (ok) vm.onAppUnlocked() }
                        },
                    )
                }
            }
        }
    }
}
