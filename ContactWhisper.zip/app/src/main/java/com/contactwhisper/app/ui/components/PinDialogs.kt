package com.contactwhisper.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.contactwhisper.app.data.PinHasher
import com.contactwhisper.app.ui.theme.CW
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val MAX_ATTEMPTS = 5
private const val LOCKOUT_MS = 30_000L

@Composable
private fun pinFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = CW.colors.ivory,
    unfocusedTextColor = CW.colors.ivory,
    focusedBorderColor = CW.colors.accent,
    unfocusedBorderColor = CW.colors.accent.copy(alpha = 0.5f),
    focusedLabelColor = CW.colors.ivory,
    unfocusedLabelColor = CW.colors.muted,
    cursorColor = CW.colors.ivory,
    errorBorderColor = CW.colors.danger,
    errorLabelColor = CW.colors.danger,
    errorTextColor = CW.colors.ivory,
    errorCursorColor = CW.colors.ivory,
    errorSupportingTextColor = CW.colors.danger,
)

/**
 * Asks for the app PIN. [verify] checks it against the stored salted hash. After 5 wrong tries the dialog
 * pauses input for 30 seconds (in memory only; it is a speed bump, not a replacement for device security).
 */
@Composable
fun PinEntryDialog(
    title: String,
    verify: suspend (String) -> Boolean,
    onSuccess: () -> Unit,
    onCancel: () -> Unit,
) {
    val c = CW.colors
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var attempts by remember { mutableIntStateOf(0) }
    var lockedUntil by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var checking by remember { mutableStateOf(false) }

    // tick once per second only while locked out, to update the countdown
    LaunchedEffect(lockedUntil) {
        while (System.currentTimeMillis() < lockedUntil) {
            now = System.currentTimeMillis()
            delay(500)
        }
        now = System.currentTimeMillis()
    }
    val lockedOut = now < lockedUntil

    fun submit() {
        if (lockedOut || checking || pin.isEmpty()) return
        checking = true
        scope.launch {
            val ok = verify(pin)
            checking = false
            if (ok) {
                onSuccess()
            } else {
                attempts++
                pin = ""
                if (attempts >= MAX_ATTEMPTS) {
                    attempts = 0
                    lockedUntil = System.currentTimeMillis() + LOCKOUT_MS
                    error = "Too many attempts. Try again in 30 seconds."
                } else {
                    error = "Incorrect PIN"
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = c.surface,
        titleContentColor = c.ivory,
        textContentColor = c.muted,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> if (v.length <= PinHasher.MAX_LENGTH && v.all { it.isDigit() }) pin = v },
                    label = { Text("App PIN") },
                    singleLine = true,
                    enabled = !lockedOut,
                    isError = error != null,
                    supportingText = {
                        val msg = if (lockedOut) "Locked for ${((lockedUntil - now) / 1000 + 1)} s" else error
                        if (msg != null) Text(msg)
                    },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = pinFieldColors(),
                )
            }
        },
        confirmButton = { CWTextButton("Unlock", ::submit) },
        dismissButton = { CWTextButton("Cancel", onCancel) },
    )
}

/** Creates (or replaces) the app PIN: enter twice, 4-12 digits. */
@Composable
fun PinSetupDialog(onSave: (String) -> Unit, onCancel: () -> Unit) {
    val c = CW.colors
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = c.surface,
        titleContentColor = c.ivory,
        textContentColor = c.muted,
        title = { Text("Set app PIN") },
        text = {
            Column {
                Text("Use ${PinHasher.MIN_LENGTH}–${PinHasher.MAX_LENGTH} digits.")
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> if (v.length <= PinHasher.MAX_LENGTH && v.all { it.isDigit() }) pin = v },
                    label = { Text("New PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = pinFieldColors(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { v -> if (v.length <= PinHasher.MAX_LENGTH && v.all { it.isDigit() }) confirm = v },
                    label = { Text("Confirm PIN") },
                    singleLine = true,
                    isError = error != null,
                    supportingText = { error?.let { Text(it) } },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = pinFieldColors(),
                )
            }
        },
        confirmButton = {
            CWTextButton("Save PIN", {
                when {
                    !PinHasher.isValidFormat(pin) -> error = "PIN must be ${PinHasher.MIN_LENGTH}–${PinHasher.MAX_LENGTH} digits"
                    pin != confirm -> error = "PINs don't match"
                    else -> onSave(pin)
                }
            })
        },
        dismissButton = { CWTextButton("Cancel", onCancel) },
    )
}
