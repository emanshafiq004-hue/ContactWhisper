package com.contactwhisper.app.domain;

import com.contactwhisper.app.dsa.ContactAlgorithms;

import java.util.regex.Pattern;

/**
 * Field-level validation for the Add/Edit form. Pure Java so it is unit-testable on the JVM.
 *
 * Two phone rule sets:
 *  - MANUAL add/edit ({@link #validateMobile}): an 11-digit Pakistani mobile number 03XXXXXXXXX. Spaces and hyphens
 *    are accepted as separators and "+92 3XX XXXXXXX" (or 0092...) is converted to 03XXXXXXXXX.
 *  - LENIENT ({@link #validatePhone}): used for numbers that were imported from the phonebook and for emergency
 *    numbers; permissive so nothing already stored is ever rejected or corrupted.
 */
public final class ContactValidator {
    public static final int MAX_NAME = 80;
    public static final int MAX_EMAIL = 120;
    public static final int MAX_ADDRESS = 200;
    public static final int MAX_NOTES = 1000;

    private static final Pattern PHONE_CHARS = Pattern.compile("^\\+?[0-9\\s().*#-]+$");
    private static final Pattern MOBILE = Pattern.compile("^03[0-9]{9}$");
    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]{2,}$");

    private ContactValidator() {
    }

    /** Result with one nullable error message per field. */
    public static final class Result {
        public final String nameError;
        public final String phoneError;
        public final String emailError;
        public final String addressError;
        public final String notesError;

        Result(String nameError, String phoneError, String emailError, String addressError, String notesError) {
            this.nameError = nameError;
            this.phoneError = phoneError;
            this.emailError = emailError;
            this.addressError = addressError;
            this.notesError = notesError;
        }

        public boolean isValid() {
            return nameError == null && phoneError == null && emailError == null
                    && addressError == null && notesError == null;
        }
    }

    /**
     * Form validation for manual Add/Edit. The phone must be a Pakistani mobile (see {@link #validateMobile}),
     * except that an EXISTING number that the user did not touch is accepted in its lenient form so an imported
     * landline / foreign number never blocks editing other fields.
     *
     * @param originalPhone the phone currently stored (edit) or null (add)
     */
    public static Result validate(String name, String phone, String email, String address, String notes,
                                  String originalPhone) {
        String phoneError;
        if (originalPhone != null && phone != null && phone.trim().equals(originalPhone.trim())
                && validatePhone(phone) == null) {
            phoneError = null;
        } else {
            phoneError = validateMobile(phone);
        }
        return new Result(validateName(name), phoneError, validateEmail(email),
                validateLength(address, MAX_ADDRESS, "Address"), validateLength(notes, MAX_NOTES, "Notes"));
    }

    public static Result validate(String name, String phone, String email, String address, String notes) {
        return validate(name, phone, email, address, notes, null);
    }

    /**
     * Normalises a manually entered Pakistani mobile number to 03XXXXXXXXX, or returns null when the input
     * cannot be one. Accepts spaces and hyphens as separators, a leading +92 / 0092 country code, or a bare
     * 03XXXXXXXXX. Anything else (letters, brackets, dots, short numbers, landlines) yields null.
     */
    public static String normalizePkMobile(String raw) {
        if (raw == null) return null;
        String p = raw.trim();
        if (p.isEmpty()) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < p.length(); i++) {
            char c = p.charAt(i);
            if (c == ' ' || c == '-') continue;
            if (c == '+' && sb.length() == 0) { sb.append(c); continue; }
            if (c >= '0' && c <= '9') { sb.append(c); continue; }
            return null;
        }
        String t = sb.toString();
        if (t.startsWith("+92")) t = "0" + t.substring(3);
        else if (t.startsWith("0092")) t = "0" + t.substring(4);
        return MOBILE.matcher(t).matches() ? t : null;
    }

    /** Error text for a manually entered number, or null when it is a valid Pakistani mobile number. */
    public static String validateMobile(String phone) {
        String p = phone == null ? "" : phone.trim();
        if (p.isEmpty()) return "Phone number is required";
        if (normalizePkMobile(p) != null) return null;
        return "Enter an 11-digit mobile number like 0300 1234567";
    }

    /** The value to store for a manually entered number: normalised when valid, otherwise just trimmed. */
    public static String phoneForSave(String phone) {
        String n = normalizePkMobile(phone);
        return n != null ? n : (phone == null ? "" : phone.trim());
    }

    public static String validateName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) return "Name is required";
        if (n.length() > MAX_NAME) return "Name must be at most " + MAX_NAME + " characters";
        return null;
    }

    /** Lenient check (imported numbers, legacy data). Manual forms use {@link #validateMobile}. */
    public static String validatePhone(String phone) {
        String p = phone == null ? "" : phone.trim();
        if (p.isEmpty()) return "Phone number is required";
        if (!PHONE_CHARS.matcher(p).matches()) return "Use only digits, spaces and + - ( ) . characters";
        // '+' is only valid as the first character
        if (p.indexOf('+', 1) >= 0) return "'+' may only appear at the start";
        int digits = ContactAlgorithms.normalizePhone(p).length();
        if (digits < 3) return "Phone number is too short";
        if (digits > 15) return "Phone number is too long";
        return null;
    }

    /** Emergency numbers are often 2-4 digit short codes, so the minimum is 2 digits (maximum 15). */
    public static String validateEmergencyNumber(String number) {
        String p = number == null ? "" : number.trim();
        if (p.isEmpty()) return "Number is required";
        if (!PHONE_CHARS.matcher(p).matches() || p.indexOf('+', 1) >= 0) return "Use only digits, spaces and + - ( ) characters";
        int digits = ContactAlgorithms.normalizePhone(p).length();
        if (digits < 2) return "Number is too short";
        if (digits > 15) return "Number is too long";
        return null;
    }

    public static String validateEmail(String email) {
        String e = email == null ? "" : email.trim();
        if (e.isEmpty()) return null; // optional
        if (e.length() > MAX_EMAIL) return "Email must be at most " + MAX_EMAIL + " characters";
        if (!EMAIL.matcher(e).matches()) return "Enter a valid email address";
        return null;
    }

    private static String validateLength(String value, int max, String label) {
        if (value != null && value.trim().length() > max) return label + " must be at most " + max + " characters";
        return null;
    }
}
