package com.contactwhisper.app.dsa;

/** One reason why a candidate contact may duplicate an existing active contact. */
public final class DuplicateMatch {
    public enum Reason { PHONE, EMAIL, NAME }

    private final ContactRecord existing;
    private final Reason reason;

    public DuplicateMatch(ContactRecord existing, Reason reason) {
        this.existing = existing;
        this.reason = reason;
    }

    public ContactRecord getExisting() { return existing; }
    public Reason getReason() { return reason; }

    /** Phone or e-mail matches are strong signals; a shared name alone is only a soft warning. */
    public boolean isStrong() {
        return reason == Reason.PHONE || reason == Reason.EMAIL;
    }
}
