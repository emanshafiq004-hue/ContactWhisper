package com.contactwhisper.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.zIndex
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import android.os.SystemClock
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.contactwhisper.app.R
import com.contactwhisper.app.dsa.ContactRecord
import com.contactwhisper.app.ui.theme.CW
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val MODE_UNDECIDED = 0
private const val MODE_HORIZONTAL = 1
private const val MODE_PULL = 2

/** Hold-to-arm duration before a downward pull is allowed (ms). Tune on the device. */
private const val HOLD_TO_ARM_MS = 250L
/** Finger travel (dp, measured from where the pull started) that must be passed before release to place the call. */
private const val PULL_THRESHOLD_DP = 80
/** The card shows this fraction of the finger travel (the rest is "spring resistance"), capped at [PULL_CARD_MAX_DP]. */
private const val PULL_RESISTANCE = 0.85f
private const val PULL_CARD_MAX_DP = 110
/** Ignore a second call trigger from the same card inside this window (duplicate-event guard). */
private const val CALL_DEBOUNCE_MS = 800L

/** Everything the gesture detector reports. Plain lambdas so the detector stays free of UI state. */
private class GestureCallbacks(
    val onTouch: (Boolean) -> Unit,
    val onPullReady: (Boolean) -> Unit,
    val onTap: () -> Unit,
    val onDoubleTap: () -> Unit,
    val onHorizontalDelta: (Float) -> Unit,
    val onHorizontalEnd: (Float) -> Unit,
    val onPullDelta: (Float) -> Unit,
    val onPullEnd: (Float) -> Unit,
    val onDragCancel: () -> Unit,
)

/**
 * Card-level gesture arbitration (coexists with the vertically scrolling list).
 *
 *  - The right [rightExclusionPx] strip (call / star buttons) is never handled here, so buttons keep working.
 *  - A press starts UNDECIDED and nothing is consumed.
 *  - Quick release (before the hold completes, no movement past touch slop): tap -> onTap, 2nd tap -> onDoubleTap.
 *  - Movement past touch slop BEFORE the hold completes:
 *      * mostly horizontal -> horizontal drag (edit), consumed as before
 *      * anything else (any vertical movement) -> gesture abandoned, NOT consumed: the list scrolls. Never calls.
 *  - Hold completes (HOLD_TO_ARM_MS, finger still within slop) -> "pull-ready" (onPullReady(true)).
 *    From here ONLY a mostly-downward drag starts the pull (consumed). Upward / horizontal movement just cancels:
 *    no call, no edit, no scroll takeover issues. Releasing while armed without pulling does nothing at all
 *    (no tap, so a hold can never feed the double-tap delete).
 *  - Release after a pull: onPullEnd(travel); the call is placed only if travel >= threshold.
 *  - A second finger / lost pointer / cancellation / coroutine cancellation all end with onDragCancel() (no call).
 */
private fun Modifier.contactGestures(
    rightExclusionPx: Float,
    callbacks: () -> GestureCallbacks,
): Modifier = pointerInput(rightExclusionPx) {
    val slop = viewConfiguration.touchSlop
    val doubleTapTimeout = viewConfiguration.doubleTapTimeoutMillis
    awaitEachGesture {
        val cb = callbacks()
        val down = awaitFirstDown(requireUnconsumed = false)
        if (down.position.x > size.width - rightExclusionPx) return@awaitEachGesture
        val startedAt = SystemClock.uptimeMillis()
        cb.onTouch(true)
        var mode = MODE_UNDECIDED
        var armed = false
        var finished = false
        try {
            var totalX = 0f
            var totalY = 0f
            var pullOrigin = 0f

            while (true) {
                // While undecided and not yet armed, wake up when the hold time elapses even if the finger is still.
                val event = if (mode == MODE_UNDECIDED && !armed) {
                    val remaining = HOLD_TO_ARM_MS - (SystemClock.uptimeMillis() - startedAt)
                    if (remaining <= 0L) null else withTimeoutOrNull(remaining) { awaitPointerEvent() }
                } else {
                    awaitPointerEvent()
                }
                if (event == null) {
                    armed = true
                    cb.onPullReady(true)
                    continue
                }
                if (event.changes.count { it.pressed } > 1) return@awaitEachGesture
                val change: PointerInputChange = event.changes.firstOrNull { it.id == down.id }
                    ?: return@awaitEachGesture
                if (mode == MODE_UNDECIDED && change.isConsumed) return@awaitEachGesture

                if (!change.pressed) {
                    finished = true
                    cb.onTouch(false)
                    when {
                        mode == MODE_PULL -> cb.onPullEnd(totalY - pullOrigin)
                        mode == MODE_HORIZONTAL -> cb.onHorizontalEnd(totalX)
                        armed -> cb.onDragCancel() // held, never pulled: nothing happens
                        else -> handleTapSequence(down.position, slop, doubleTapTimeout, cb)
                    }
                    return@awaitEachGesture
                }

                val delta = change.positionChange()
                totalX += delta.x
                totalY += delta.y

                if (mode == MODE_UNDECIDED) {
                    val ax = abs(totalX)
                    val ay = abs(totalY)
                    if (maxOf(ax, ay) > slop) {
                        if (armed) {
                            if (ay > ax && totalY > 0f) {
                                mode = MODE_PULL
                                pullOrigin = totalY - slop // card starts moving from ~0, no jump
                            } else {
                                return@awaitEachGesture // up / sideways after arming: cancel, no call
                            }
                        } else {
                            mode = if (ax > ay * 1.2f) MODE_HORIZONTAL else return@awaitEachGesture // let the list scroll
                        }
                    }
                }
                when (mode) {
                    MODE_HORIZONTAL -> {
                        cb.onHorizontalDelta(delta.x)
                        change.consume()
                    }
                    MODE_PULL -> {
                        cb.onPullDelta((totalY - pullOrigin).coerceAtLeast(0f))
                        change.consume()
                    }
                }
            }
        } finally {
            cb.onTouch(false)
            if (!finished) cb.onDragCancel() // always resets ready state / offsets; never places a call
        }
    }
}

private suspend fun AwaitPointerEventScope.handleTapSequence(
    firstDownPosition: Offset,
    slop: Float,
    doubleTapTimeout: Long,
    cb: GestureCallbacks,
) {
    val second = withTimeoutOrNull(doubleTapTimeout) { awaitFirstDown(requireUnconsumed = false) }
    if (second == null) {
        cb.onTap()
        return
    }
    val up = waitForUpOrCancellation()
    val close = (second.position - firstDownPosition).getDistance() <= slop * 6f
    if (up != null && close) {
        up.consume()
        cb.onDoubleTap()
    } else {
        cb.onTap()
    }
}

/** One accessibility action (TalkBack menu) for a gesture card. */
class CardAction(val label: String, val run: () -> Unit)

/**
 * The shared interactive card behind every contact row AND every Emergency Services row:
 *
 *   tap -> [onOpen] | double tap -> [onDelete] after a ~500 ms smoke burst | horizontal drag -> [onEdit] |
 *   hold ~250 ms, then pull the whole card down >= 80 dp and release -> [onCall] (rigid card, snaps back fast, the call
 *   starts immediately on release) | TalkBack custom actions for all of them.
 *
 * Flat and solid by default (#78081C / #051912); raised (bevel-out) only while touched.
 *
 * @param rightExclusion width of the trailing button strip that the gesture detector must leave alone
 * @param leading content of the 64dp leading "pull zone"
 */
@Composable
fun GestureCard(
    seed: Int,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onCall: () -> Unit,
    onDelete: () -> Unit,
    actions: List<CardAction>,
    modifier: Modifier = Modifier,
    rightExclusion: Dp = 104.dp,
    leading: @Composable BoxScope.() -> Unit,
    content: @Composable RowScope.() -> Unit,
) {
    val c = CW.colors
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val pullThresholdPx = with(density) { PULL_THRESHOLD_DP.dp.toPx() }
    val pullCardMaxPx = with(density) { PULL_CARD_MAX_DP.dp.toPx() }
    val editThresholdPx = with(density) { 72.dp.toPx() }
    val rightExclusionPx = with(density) { rightExclusion.toPx() }
    val haptic = LocalHapticFeedback.current

    var dragX by remember { mutableFloatStateOf(0f) }
    // Rigid-body pull: the whole card chases the finger through a soft spring instead of copying it pixel for pixel.
    val pull = remember { Animatable(0f) }
    var pullReady by remember { mutableStateOf(false) }   // hold completed: subtle "ready" lift
    var lifted by remember { mutableStateOf(false) }      // draw above neighbouring rows while armed / returning
    var lastCallAt by remember { mutableLongStateOf(0L) } // duplicate-call guard
    var smokeProgress by remember { mutableFloatStateOf(0f) }
    var smokeField by remember { mutableStateOf<SmokeField?>(null) }
    var smoking by remember { mutableStateOf(false) }
    var touching by remember { mutableStateOf(false) }

    val latestOpen by rememberUpdatedState(onOpen)
    val latestEdit by rememberUpdatedState(onEdit)
    val latestCall by rememberUpdatedState(onCall)
    val latestDelete by rememberUpdatedState(onDelete)

    // Double-tap delete: a ~500 ms procedural smoke burst from the card centre, THEN the real delete (Room + DSA via the
    // ViewModel). `smoking` blocks any second trigger for this card while the effect or the delete is in progress.
    LaunchedEffect(smoking) {
        if (smoking) {
            smokeField = SmokeField(seed)
            animate(0f, 1f, animationSpec = tween(SMOKE_DURATION_MS, easing = LinearEasing)) { v, _ -> smokeProgress = v }
            latestDelete()
            delay(1500) // only reached if this card is still on screen (the delete failed): bring it back
            smoking = false
        }
        // release the particle table and reset the frame state whenever the effect is not running
        smokeField = null
        smokeProgress = 0f
    }

    fun springBack() {
        val fromX = dragX
        if (fromX != 0f) scope.launch {
            animate(fromX, 0f, animationSpec = spring(dampingRatio = 0.6f, stiffness = 520f)) { v, _ -> dragX = v }
        }
        // always launched: it also cancels any pending follow-the-finger animation, so no stale offset can survive
        scope.launch {
            // quick (~150-200 ms), well damped: a restrained object returning to rest, not a bouncing toy
            pull.animateTo(0f, spring(dampingRatio = 0.8f, stiffness = 1100f))
            lifted = false
        }
    }

    val callbacks = GestureCallbacks(
        onTouch = { touching = it },
        onTap = { if (!smoking) latestOpen() },
        onDoubleTap = { if (!smoking) smoking = true },
        onHorizontalDelta = { dx -> if (!smoking) dragX = (dragX + dx).coerceIn(-editThresholdPx * 1.6f, editThresholdPx * 1.6f) },
        onHorizontalEnd = { total ->
            val trigger = abs(total) >= editThresholdPx && !smoking
            springBack()
            if (trigger) latestEdit()
        },
        onPullReady = { ready ->
            if (ready && !smoking) {
                pullReady = true
                lifted = true
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            } else pullReady = false
        },
        onPullDelta = { dy ->
            if (!smoking) scope.launch { pull.animateTo(dy, spring(dampingRatio = 0.9f, stiffness = 700f)) } // slight, smooth lag
        },
        onPullEnd = { travel ->
            pullReady = false
            val now = SystemClock.uptimeMillis()
            val trigger = travel >= pullThresholdPx && !smoking && now - lastCallAt > CALL_DEBOUNCE_MS
            if (trigger) lastCallAt = now
            springBack()
            if (trigger) latestCall() // exactly once, immediately on release; the spring-back runs in parallel
        },
        onDragCancel = { pullReady = false; springBack() }, // never calls
    )
    val latestCallbacks by rememberUpdatedState(callbacks)

    val raise by animateFloatAsState(if (touching && !smoking) 1f else 0f, tween(90), label = "cardRaise")
    val ready by animateFloatAsState(if (pullReady) 1f else 0f, tween(120), label = "cardReady")
    val shape = RoundedCornerShape(12.dp)
    val smokeColor = c.smoke
    val cardAlpha = if (smokeProgress <= 0f) 1f else 1f - smoothStep((smokeProgress - 0.35f) / 0.5f)

    // OUTER box: elastic transforms + the smoke layer (drawn above the card, may extend beyond its edges).
    Box(
        modifier = modifier
            .fillMaxWidth()
            .zIndex(if (lifted) 1f else 0f) // a pulled card slides over the row below instead of under it
            .graphicsLayer {
                translationX = dragX * 0.6f
                // rigid translation only (no scale / rotation): the whole card moves as one object, with resistance
                translationY = (pull.value * PULL_RESISTANCE).coerceIn(0f, pullCardMaxPx)
            }
            .drawWithContent {
                drawContent()
                val field = smokeField
                if (field != null && smokeProgress > 0f) drawSmokeBurst(smokeProgress, smokeColor, field)
            }
            .semantics {
                onClick(label = "Open details") { latestOpen(); true }
                customActions = actions.map { a -> CustomAccessibilityAction(a.label) { a.run(); true } }
            },
    ) {
        // INNER box: the solid card itself (its alpha fades only late in the burst; its colour is never tinted)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer { alpha = cardAlpha }
                .shadow((3f * raise + 5f * ready).dp, shape, clip = false)
                .clip(shape)
                .background(lerp(c.panel, c.panelPressed, raise))
                .border(1.dp, c.accent.copy(alpha = 0.7f), shape)
                .bevelOut(12.dp, raise)
                .contactGestures(rightExclusionPx) { latestCallbacks },
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // leading avatar area (the pull-to-call gesture works anywhere on the card body)
                Box(
                    modifier = Modifier
                        .width(64.dp)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center,
                    content = leading,
                )
                content()
            }
        }
    }
}

private fun smoothStep(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

/**
 * A contact row used on Home, Favorites and inside expanded Categories (same gestures everywhere).
 * Visible actions: Call icon first, then Favorite, so nothing is gesture-only.
 */
@Composable
fun ContactCard(
    contact: ContactRecord,
    onOpen: () -> Unit,
    onEdit: () -> Unit,
    onCall: () -> Unit,
    onDelete: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = CW.colors
    GestureCard(
        seed = contact.id.toInt(),
        onOpen = onOpen,
        onEdit = onEdit,
        onCall = onCall,
        onDelete = onDelete,
        actions = listOf(
            CardAction("Call ${contact.name}", onCall),
            CardAction("Edit contact", onEdit),
            CardAction("Delete contact", onDelete),
            CardAction(if (contact.isFavorite) "Remove from favorites" else "Add to favorites", onToggleFavorite),
        ),
        modifier = modifier,
        rightExclusion = 104.dp,
        leading = { InitialAvatar(contact.name, 40.dp) },
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = contact.name,
                color = c.ivory,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = contact.phone,
                color = c.ivory.copy(alpha = 0.70f),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        // visible, always-available actions: Call first, Favorite beside it
        IconButton(onClick = onCall) { PhoneIcon(size = 24.dp) }
        IconButton(onClick = onToggleFavorite) {
            CWIcon(
                id = if (contact.isFavorite) R.drawable.ic_star else R.drawable.ic_star_outline,
                contentDescription = if (contact.isFavorite) "Remove from favorites" else "Add to favorites",
                size = 24.dp,
            )
        }
    }
}
