package com.contactwhisper.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.contactwhisper.app.R
import com.contactwhisper.app.ui.components.GradientText
import com.contactwhisper.app.ui.components.InfoSection
import com.contactwhisper.app.ui.components.PanelCard
import com.contactwhisper.app.ui.components.ScreenHeader
import com.contactwhisper.app.ui.theme.CW

// ====================================================================== About

/** Name of the installed app version, read from the package (no BuildConfig needed). */
@Composable
private fun rememberVersionName(): String {
    val context = LocalContext.current
    return remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0.0"
        } catch (e: Exception) {
            "1.0.0"
        }
    }
}

private const val DEVELOPER_EMAIL = "emanshafiq004@gmail.com"

/**
 * Polished app introduction: icon, gradient title, short description, four feature cards (only features that work in
 * this build) and the developer section with the watermark centered at its bottom.
 */
@Composable
fun AboutScreen(onBack: () -> Unit) {
    val c = CW.colors
    val version = rememberVersionName()
    val uriHandler = LocalUriHandler.current

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = "About", onBack = onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // ---- branding
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(R.drawable.app_icon),
                    contentDescription = "Contact Whisper icon",
                    modifier = Modifier.size(112.dp),
                )
                Spacer(Modifier.height(10.dp))
                GradientText("Contact Whisper", fontSize = 28.sp)
                Spacer(Modifier.height(4.dp))
                Text("Smart Contact Management.", color = c.ivory, fontSize = 15.sp, textAlign = TextAlign.Center)
                Text("Version $version", color = c.muted, fontSize = 13.sp, textAlign = TextAlign.Center)
            }

            // ---- about the app
            InfoSection(
                "About the App",
                "ContactWhisper is a smart contact management application designed to make staying connected simpler, " +
                    "faster, and more intuitive. Combining organized contact storage with intelligent voice interaction " +
                    "and convenient gestures, it transforms everyday contact management into a smoother experience.",
            )

            // ---- what makes it different
            Text("What Makes It Different", color = c.ivory, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
            FeatureCard(
                "Conversational Voice Assistant",
                "Find contacts by speaking a contact name or available details, then interact with the assistant to choose an action such as calling, editing or deleting a contact.",
            )
            FeatureCard(
                "Smart Gesture Controls",
                "Perform common actions through intuitive gestures, reducing unnecessary taps and making contact management more convenient.",
            )
            FeatureCard(
                "Unified Contact Search",
                "Find contacts using names, phone numbers, email addresses and other available details.",
            )
            FeatureCard(
                "Organized & Convenient",
                "Keep important people within reach with favorites, categories, flexible sorting and contact recovery through the Recycle Bin.",
            )

            // ---- developer
            Text("Meet the Developer", color = c.ivory, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
            PanelCard {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Eman Shafiq", color = c.ivory, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("Developer & Creator of Contact Whisper", color = c.muted, fontSize = 13.sp)
                    Text(
                        "Developed as a university DSA project, Contact Whisper reflects my interest in creating practical " +
                            "applications that combine thoughtful design, efficient programming and meaningful user experiences.",
                        color = c.ivory.copy(alpha = 0.85f),
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                    )
                    Row(
                        Modifier.clickable {
                            // opens the user's mail app; ignore devices without one
                            runCatching { uriHandler.openUri("mailto:$DEVELOPER_EMAIL") }
                        },
                    ) {
                        Text("Email: ", color = c.ivory, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(DEVELOPER_EMAIL, color = c.ivory, fontSize = 14.sp, textDecoration = TextDecoration.Underline)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("ContactWhisper © 2026", color = c.muted, fontSize = 12.sp)
                    Text("Created by Eman Shafiq", color = c.muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    // Developer signature: supplied watermark, centered at the bottom of the developer section,
                    // proportional (aspect 3.6:1, never stretched). The supplied artwork is dark, so it is tinted warm
                    // ivory to be visible on the charcoal card, and kept subtle.
                    Image(
                        painter = painterResource(R.drawable.developer_watermark),
                        contentDescription = "Eman Game Dev",
                        contentScale = ContentScale.Fit,
                        colorFilter = ColorFilter.tint(c.ivory),
                        alpha = 0.45f,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(170.dp)
                            .aspectRatio(900f / 250f),
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun FeatureCard(title: String, body: String) = InfoSection(title, body)
