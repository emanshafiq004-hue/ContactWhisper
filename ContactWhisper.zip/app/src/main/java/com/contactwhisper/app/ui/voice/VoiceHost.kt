package com.contactwhisper.app.ui.voice

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.data.AppTheme
import com.contactwhisper.app.ui.components.CWButton
import com.contactwhisper.app.ui.components.CWIcon
import com.contactwhisper.app.ui.components.CWTextButton
import com.contactwhisper.app.ui.components.CWTextField
import com.contactwhisper.app.ui.theme.CW
import com.contactwhisper.app.util.dialNumber
import com.contactwhisper.app.voice.CategoryAsk
import com.contactwhisper.app.voice.EditField
import com.contactwhisper.app.voice.EmergencyField
import com.contactwhisper.app.voice.VoiceAction
import com.contactwhisper.app.voice.VoiceAssistant
import com.contactwhisper.app.voice.VoiceScreen
import com.contactwhisper.app.voice.VoiceSnapshot
import com.contactwhisper.app.voice.VoiceState
import com.contactwhisper.app.voice.VoiceUiEffect
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------- state helpers

/**
 * Presentation rules:
 *  - the very first screen of a session (nothing handled yet) and the "can't listen" screen are the SOLID charcoal
 *    interface;
 *  - lists of matching contacts / Bin entries are solid too (they need room);
 *  - every follow-up question about a found contact or an operation uses the translucent overlay, so the app
 *    underneath stays visible;
 *  - between commands the session shows a compact panel without a scrim, so the screen the command opened is visible
 *    and usable while the assistant keeps listening.
 */
private enum class Presentation { SOLID, OVERLAY, PANEL }

private fun VoiceSnapshot.presentation(): Presentation = when (state) {
    VoiceState.RequestingPermission, is VoiceState.Unavailable -> Presentation.SOLID
    is VoiceState.Choosing -> Presentation.SOLID
    VoiceState.AwaitingCommand -> if (handled == 0) Presentation.SOLID else Presentation.PANEL
    VoiceState.Closing -> Presentation.PANEL
    else -> Presentation.OVERLAY
}

private fun VoiceState.contactName(): String? = when (this) {
    is VoiceState.AskingAction -> contact.name
    is VoiceState.AskingEditField -> contact.name
    is VoiceState.AskingEditValue -> contact.name
    is VoiceState.ConfirmingEdit -> contact.name
    is VoiceState.ConfirmingDelete -> contact.name
    VoiceState.AskingAddName, is VoiceState.AskingAddPhone, is VoiceState.AskingAddEmail, is VoiceState.ConfirmingAdd -> "New contact"
    is VoiceState.AskingEmergencyEditField -> entry.name
    is VoiceState.AskingEmergencyEditValue -> entry.name
    is VoiceState.ConfirmingEmergencyEdit -> entry.name
    is VoiceState.ConfirmingEmergencyRemove -> entry.name
    VoiceState.AskingEmergencyName, is VoiceState.AskingEmergencyNumber, is VoiceState.ConfirmingEmergencyAdd -> "Emergency service"
    else -> null
}

// ---------------------------------------------------------------------------------------------- host

/**
 * Hosts the voice assistant above the whole app. Renders nothing while idle. Owns the microphone-permission launcher
 * (asked only when a session starts) and turns the assistant's UI effects into navigation / dialer calls.
 *
 * The session is continuous: it stays open (and keeps listening, see [VoiceAssistant]) until the user says "close",
 * taps Close / Back, or the app leaves the foreground. There is no Retry button anywhere: silence is ignored and
 * unclear speech is answered with "I didn't catch that. Please say it again." while listening continues.
 *
 * Voice never reaches App Lock, the PIN or biometrics: no state in this file touches them.
 */
@Composable
fun VoiceHost(
    vm: AppViewModel,
    onNavigate: (VoiceScreen) -> Unit,
    onBack: () -> Unit,
    onOpenDetails: (Long) -> Unit,
) {
    val assistant = vm.voice
    val snap by assistant.snapshot.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val navigate by rememberUpdatedState(onNavigate)
    val back by rememberUpdatedState(onBack)
    val openDetails by rememberUpdatedState(onOpenDetails)

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        assistant.onPermissionResult(granted)
    }

    LaunchedEffect(assistant) {
        assistant.ui.collect { effect ->
            when (effect) {
                VoiceUiEffect.RequestPermission -> permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                is VoiceUiEffect.Navigate -> navigate(effect.screen)
                VoiceUiEffect.Back -> back()
                is VoiceUiEffect.OpenDetails -> openDetails(effect.id)
                is VoiceUiEffect.Dial -> dialNumber(context, effect.number)
            }
        }
    }

    if (snap.state == VoiceState.Idle) return
    BackHandler { assistant.close() }

    when (snap.presentation()) {
        Presentation.SOLID -> VoiceFullScreen(snap, assistant)
        Presentation.OVERLAY -> VoiceOverlay(snap, assistant)
        Presentation.PANEL -> VoicePanel(snap, assistant)
    }
}

// ---------------------------------------------------------------------------------------------- solid screen

@Composable
private fun VoiceFullScreen(snap: VoiceSnapshot, assistant: VoiceAssistant) {
    val c = CW.colors
    val state = snap.state
    val listening = snap.listening
    val choosing = state as? VoiceState.Choosing
    val unavailable = state as? VoiceState.Unavailable

    val heading = when {
        unavailable != null -> "Voice assistant"
        state == VoiceState.RequestingPermission -> "Waiting for permission…"
        choosing != null -> choosing.title
        listening -> "Listening…"
        snap.speaking -> "Speaking…"
        else -> "Voice assistant"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.background) // solid charcoal: nothing shows through
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .safeDrawingPadding(),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(heading, color = c.ivory, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))

            if (choosing == null) {
                VoiceOrb(active = listening, modifier = Modifier.padding(top = 12.dp))
                Spacer(Modifier.height(20.dp))
            }

            Transcript(snap, listening)
            AssistantText(snap.assistant, hidden = false)

            if (choosing != null) {
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(choosing.options, key = { it.id }) { option ->
                        OptionRow(option.label, option.detail) { assistant.selectChoice(option.id) }
                    }
                }
                CWTextButton(text = "Cancel", onClick = assistant::cancelOperation, modifier = Modifier.padding(top = 4.dp))
            } else {
                Spacer(Modifier.weight(1f))
            }

            Spacer(Modifier.height(8.dp))
            // Close / Back is the only persistent control: no Retry / Try Again button exists.
            CWButton(text = "Close", onClick = assistant::close, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun OptionRow(label: String, detail: String, onClick: () -> Unit) {
    val c = CW.colors
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.panel)
            .border(1.dp, c.accent.copy(alpha = 0.7f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Text(label, color = c.ivory, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        if (detail.isNotBlank()) Text(detail, color = c.ivory.copy(alpha = 0.7f), fontSize = 13.sp)
    }
}

// ---------------------------------------------------------------------------------------------- compact panel (between commands)

@Composable
private fun VoicePanel(snap: VoiceSnapshot, assistant: VoiceAssistant) {
    val c = CW.colors
    val shape = RoundedCornerShape(20.dp)
    // No scrim: the screen the last command opened stays fully visible and touchable; only the panel takes touches.
    Box(Modifier.fillMaxSize().safeDrawingPadding(), contentAlignment = Alignment.BottomCenter) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 72.dp)
                .clip(shape)
                .background(c.surface)
                .border(1.dp, c.accent.copy(alpha = 0.8f), shape)
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                    if (snap.listening) VoiceBars(Modifier.size(28.dp, 22.dp)) else CWIcon(R.drawable.ic_mic, null, tint = c.ivory)
                }
                Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    Text(
                        if (snap.listening) "Listening…" else if (snap.speaking) "Speaking…" else "Voice assistant",
                        color = c.muted,
                        fontSize = 12.sp,
                    )
                    AssistantText(snap.assistant, hidden = false, align = TextAlign.Start)
                }
                CWTextButton(text = "Close", onClick = assistant::close)
            }
            Transcript(snap, snap.listening, align = TextAlign.Start)
        }
    }
}

// ---------------------------------------------------------------------------------------------- translucent overlay

@Composable
private fun VoiceOverlay(snap: VoiceSnapshot, assistant: VoiceAssistant) {
    val c = CW.colors
    val state = snap.state
    val listening = snap.listening
    val shape = RoundedCornerShape(20.dp)

    Box(
        Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.58f)) // translucent: the app stays visible
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .safeDrawingPadding(),
    ) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .clip(shape)
                .background(c.panel.copy(alpha = 0.95f))
                .border(1.dp, c.accent.copy(alpha = 0.8f), shape)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
        ) {
            state.contactName()?.let {
                Text(it, color = c.ivory, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
            }
            AssistantText(snap.assistant, hidden = false, align = TextAlign.Start)
            Transcript(snap, listening, align = TextAlign.Start)
            Spacer(Modifier.height(14.dp))

            when (state) {
                is VoiceState.AskingAction -> TwoColumn(
                    listOf(
                        ChoiceButton("View") { assistant.chooseAction(VoiceAction.VIEW) },
                        ChoiceButton("Edit") { assistant.chooseAction(VoiceAction.EDIT) },
                        ChoiceButton("Call") { assistant.chooseAction(VoiceAction.CALL) },
                        ChoiceButton("Delete", danger = true) { assistant.chooseAction(VoiceAction.DELETE) },
                        if (state.contact.isFavorite) ChoiceButton("Remove favorite") { assistant.chooseAction(VoiceAction.UNFAVORITE) }
                        else ChoiceButton("Add favorite") { assistant.chooseAction(VoiceAction.FAVORITE) },
                    ),
                )
                is VoiceState.AskingEditField -> TwoColumn(
                    EditField.entries.map { f -> ChoiceButton(f.label.replaceFirstChar { it.uppercase() }) { assistant.chooseField(f) } },
                )
                is VoiceState.AskingEditValue -> ValueInput(
                    label = "New ${state.field.label}",
                    keyboard = when (state.field) {
                        EditField.PHONE -> KeyboardType.Phone
                        EditField.EMAIL -> KeyboardType.Email
                        else -> KeyboardType.Text
                    },
                    onSend = assistant::submitText,
                    skipLabel = if (state.field.optionalToClear()) "Clear it" else null,
                    onSkip = { assistant.submitText("clear") },
                )
                VoiceState.AskingAddName -> ValueInput("Full name", KeyboardType.Text, assistant::submitText)
                is VoiceState.AskingAddPhone -> ValueInput("Phone number", KeyboardType.Phone, assistant::submitText)
                is VoiceState.AskingAddEmail -> ValueInput(
                    "Email (optional)", KeyboardType.Email, assistant::submitText,
                    skipLabel = "Skip", onSkip = { assistant.submitText("skip") },
                )
                is VoiceState.ConfirmingEdit -> {
                    state.warning?.takeIf { !snap.assistant.contains(it) }?.let { WarningText(it) }
                    ConfirmRow("Save change", "Don't save", danger = false, assistant)
                }
                is VoiceState.ConfirmingAdd -> {
                    state.warning?.takeIf { !snap.assistant.contains(it) }?.let { WarningText(it) }
                    ConfirmRow("Add contact", "Don't add", danger = false, assistant)
                }
                is VoiceState.ConfirmingDelete -> ConfirmRow("Yes, move to Bin", "No, keep it", danger = true, assistant)
                VoiceState.AskingTheme -> TwoColumn(
                    listOf(
                        ChoiceButton("Crimson") { assistant.chooseTheme(AppTheme.CRIMSON) },
                        ChoiceButton("Emerald") { assistant.chooseTheme(AppTheme.EMERALD) },
                    ),
                )
                is VoiceState.AskingCategoryName -> ValueInput(
                    if (state.ask == CategoryAsk.CREATE) "New category name" else "New name for ${state.oldName}",
                    KeyboardType.Text,
                    assistant::submitText,
                )
                is VoiceState.ConfirmingRemoveCategory -> ConfirmRow("Yes, remove it", "No, keep it", danger = true, assistant)
                // PERMANENT deletion: the red button says so explicitly
                is VoiceState.ConfirmingBinDelete -> ConfirmRow("Yes, delete permanently", "No, keep it in the Bin", danger = true, assistant)
                VoiceState.AskingEmergencyName -> ValueInput("Service name", KeyboardType.Text, assistant::submitText)
                is VoiceState.AskingEmergencyNumber -> ValueInput("Number", KeyboardType.Phone, assistant::submitText)
                is VoiceState.ConfirmingEmergencyAdd -> ConfirmRow("Add entry", "Don't add", danger = false, assistant)
                is VoiceState.AskingEmergencyEditField -> TwoColumn(
                    EmergencyField.entries.map { f -> ChoiceButton(f.label.replaceFirstChar { it.uppercase() }) { assistant.chooseEmergencyField(f) } },
                )
                is VoiceState.AskingEmergencyEditValue -> ValueInput(
                    "New ${state.field.label}",
                    if (state.field == EmergencyField.NUMBER) KeyboardType.Phone else KeyboardType.Text,
                    assistant::submitText,
                )
                is VoiceState.ConfirmingEmergencyEdit -> ConfirmRow("Save change", "Don't save", danger = false, assistant)
                is VoiceState.ConfirmingEmergencyRemove -> ConfirmRow("Yes, move to Bin", "No, keep it", danger = true, assistant)
                is VoiceState.ConfirmingProfileName -> ConfirmRow("Save name", "Don't save", danger = false, assistant)
                is VoiceState.ExecutingAction -> Text("Working on it…", color = c.muted, fontSize = 14.sp)
                else -> Unit
            }

            if (state !is VoiceState.ExecutingAction) {
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    ListeningIndicator(listening)
                    Row {
                        CWTextButton(text = "Cancel", onClick = assistant::cancelOperation)
                        CWTextButton(text = "Close", onClick = assistant::close)
                    }
                }
            }
        }
    }
}

/** Shows that the assistant is (still) listening on its own. It is NOT a button: nothing needs tapping to continue. */
@Composable
private fun ListeningIndicator(listening: Boolean) {
    val c = CW.colors
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(c.field)
            .border(1.dp, c.accent, CircleShape)
            .semantics { contentDescription = if (listening) "Listening" else "Voice assistant" },
        contentAlignment = Alignment.Center,
    ) {
        if (listening) VoiceBars(Modifier.size(28.dp, 22.dp)) else CWIcon(R.drawable.ic_mic, null, tint = c.ivory)
    }
}

private fun EditField.optionalToClear(): Boolean = this != EditField.NAME && this != EditField.PHONE && this != EditField.CATEGORY

private class ChoiceButton(val label: String, val danger: Boolean = false, val onClick: () -> Unit)

@Composable
private fun TwoColumn(buttons: List<ChoiceButton>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        buttons.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { b -> CWButton(text = b.label, onClick = b.onClick, danger = b.danger, modifier = Modifier.weight(1f)) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ConfirmRow(yes: String, no: String, danger: Boolean, assistant: VoiceAssistant) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        CWButton(text = yes, onClick = assistant::confirm, danger = danger, modifier = Modifier.fillMaxWidth())
        CWTextButton(text = no, onClick = assistant::decline, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun ValueInput(
    label: String,
    keyboard: KeyboardType,
    onSend: (String) -> Unit,
    skipLabel: String? = null,
    onSkip: () -> Unit = {},
) {
    var text by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        CWTextField(value = text, onValueChange = { text = it }, label = label, keyboardType = keyboard)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            CWButton(
                text = "Send",
                onClick = { onSend(text); text = "" },
                enabled = text.isNotBlank(),
                modifier = Modifier.weight(1f),
            )
            if (skipLabel != null) CWTextButton(text = skipLabel, onClick = onSkip)
        }
    }
}

@Composable
private fun WarningText(text: String) {
    val c = CW.colors
    Text(text, color = c.ivory, fontSize = 13.sp, fontStyle = FontStyle.Italic, modifier = Modifier.padding(bottom = 10.dp))
}

// ---------------------------------------------------------------------------------------------- shared pieces

/** What the assistant says, always visible as text (it is also spoken when text-to-speech is available). */
@Composable
private fun AssistantText(text: String, hidden: Boolean, align: TextAlign = TextAlign.Center) {
    if (text.isBlank() || hidden) return
    val c = CW.colors
    Text(
        text,
        color = c.ivory,
        fontSize = 17.sp,
        textAlign = align,
        modifier = Modifier
            .fillMaxWidth()
            .semantics { liveRegion = LiveRegionMode.Polite },
    )
}

@Composable
private fun Transcript(snap: VoiceSnapshot, listening: Boolean, align: TextAlign = TextAlign.Center) {
    val c = CW.colors
    val shown = when {
        listening && snap.partial.isNotBlank() -> snap.partial
        snap.transcript.isNotBlank() -> snap.transcript
        else -> ""
    }
    if (shown.isEmpty()) return
    Spacer(Modifier.height(6.dp))
    Text(
        if (listening) "“$shown”" else "You said: “$shown”",
        color = if (listening) c.ivory else c.muted,
        fontSize = 14.sp,
        fontStyle = if (listening) FontStyle.Italic else FontStyle.Normal,
        textAlign = align,
        modifier = Modifier.fillMaxWidth(),
    )
}

/** Lightweight listening animation: one infinite float drives pulsing rings and (below) a few bars. Idle = static. */
@Composable
private fun VoiceOrb(active: Boolean, modifier: Modifier = Modifier) {
    val c = CW.colors
    val phase: State<Float>? = if (active) {
        rememberInfiniteTransition(label = "voice-orb").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
            label = "phase",
        )
    } else null
    val ring = c.accent
    val fill = c.panel
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(200.dp)
                .semantics { contentDescription = if (active) "Listening" else "Microphone" },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val core = 46.dp.toPx()
                val t = phase?.value
                if (t != null) {
                    for (k in 0 until 3) {
                        val p = (t + k / 3f) % 1f
                        drawCircle(
                            color = ring.copy(alpha = (1f - p) * 0.55f),
                            radius = core + (size.minDimension / 2f - core) * p,
                            center = center,
                            style = Stroke(width = 2.dp.toPx()),
                        )
                    }
                }
                drawCircle(color = fill, radius = core, center = center)
                drawCircle(color = ring, radius = core, center = center, style = Stroke(width = 1.5.dp.toPx()))
            }
            CWIcon(R.drawable.ic_mic, null, tint = c.ivory, size = 40.dp)
        }
        if (active) {
            Spacer(Modifier.height(8.dp))
            VoiceBars(Modifier.size(84.dp, 30.dp))
        }
    }
}

/** Five bars moving out of phase. Draws from a single animated float, so there is no per-frame recomposition. */
@Composable
private fun VoiceBars(modifier: Modifier = Modifier) {
    val c = CW.colors
    val phase = rememberInfiniteTransition(label = "voice-bars").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "bars",
    )
    val color = c.accent
    Canvas(modifier) {
        val count = 5
        val gap = size.width / (count * 2f - 1f)
        val barW = gap
        for (i in 0 until count) {
            val h = size.height * (0.28f + 0.72f * abs(sin(PI.toFloat() * (phase.value + i * 0.2f))))
            drawRoundRect(
                color = color,
                topLeft = Offset(i * 2f * gap, (size.height - h) / 2f),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f),
            )
        }
    }
}
