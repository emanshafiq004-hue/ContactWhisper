package com.contactwhisper.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.domain.ContactValidator
import com.contactwhisper.app.ui.components.CWButton
import com.contactwhisper.app.ui.components.CWTextField
import com.contactwhisper.app.ui.components.CameraBadge
import com.contactwhisper.app.ui.components.ProfileAvatar
import com.contactwhisper.app.ui.components.cornerGlows
import com.contactwhisper.app.ui.theme.CW
import com.contactwhisper.app.ui.theme.SetupCrimson
import com.contactwhisper.app.ui.theme.SetupEmerald

/**
 * First launch only: a LOCAL profile (no account, no Google sign-in). Charcoal background with the reduced corner
 * glows, a centred photo ringed in BOTH crimson and emerald, recessed inputs with two-colour outlines, and a Continue
 * button (emerald fill, crimson outline, raised) that saves and goes straight to Home.
 */
@Composable
fun ProfileSetupScreen(vm: AppViewModel, onDone: () -> Unit) {
    val c = CW.colors
    val settings by vm.settings.collectAsStateWithLifecycle()

    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var about by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.pickProfilePhoto(uri)
    }

    val nameError = if (submitted && name.isBlank()) "Display name is required" else null
    val emailError = if (submitted) ContactValidator.validateEmail(email) else null

    val twoColour = Brush.sweepGradient(listOf(SetupCrimson, SetupEmerald, SetupCrimson))
    val twoColourLine = Brush.horizontalGradient(listOf(SetupCrimson, SetupEmerald))

    Box(Modifier.fillMaxSize().background(c.background).cornerGlows()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Spacer(Modifier.height(16.dp))
            Text("Create Your Profile", color = c.ivory, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .size(124.dp)
                    .clickable {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
            ) {
                ProfileAvatar(settings.photoPath, settings.photoVersion, name, 124.dp, ring = twoColour, ringWidth = 3.dp)
                // small fixed-size two-colour circle on the photo's lower-right edge; the icon is never stretched
                CameraBadge(Modifier.align(Alignment.BottomEnd), size = 36.dp)
            }

            CWTextField(name, { name = it.take(40) }, "Display name *", error = nameError, outline = twoColourLine)
            CWTextField(email, { email = it }, "Email (optional)", error = emailError, keyboardType = KeyboardType.Email, outline = twoColourLine)
            CWTextField(about, { about = it.take(160) }, "About you (optional)", singleLine = false, minLines = 2, outline = twoColourLine)

            Text(
                "This info is stored on this device only.",
                color = c.muted,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )

            CWButton(
                text = "Continue",
                modifier = Modifier.fillMaxWidth(),
                fill = SetupEmeraldFill,
                outline = SetupCrimson,
                textColor = c.ivory,
                onClick = {
                    submitted = true
                    if (name.isNotBlank() && ContactValidator.validateEmail(email) == null) {
                        vm.saveProfile(name, email, about) { onDone() }
                    }
                },
            )
        }
    }
}

/** Emerald fill for the Continue button (deep enough to stay matte against charcoal). */
private val SetupEmeraldFill = androidx.compose.ui.graphics.Color(0xFF0B5A44)
