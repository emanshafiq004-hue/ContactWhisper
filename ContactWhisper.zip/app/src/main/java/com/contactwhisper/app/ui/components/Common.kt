package com.contactwhisper.app.ui.components

import android.graphics.BitmapFactory
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.contactwhisper.app.R
import com.contactwhisper.app.ui.theme.BrandCrimson
import com.contactwhisper.app.ui.theme.CW
import com.contactwhisper.app.ui.theme.EMERALD_CARD
import com.contactwhisper.app.ui.theme.LocalRoboto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ====================================================================== icons

/**
 * Icons that are the user's supplied 3D ivory PNG artwork. They are drawn as images (never tinted: tinting would
 * flatten the 3D look) and never stretched (ContentScale.Fit inside the requested square).
 * Everything else is a simple tinted vector placeholder (no supplied equivalent exists, see docs/ASSETS.md).
 */
private val SuppliedIcons: Set<Int> = setOf(
    R.drawable.ic_info, R.drawable.ic_add, R.drawable.ic_lock, R.drawable.ic_palette, R.drawable.ic_category,
    R.drawable.ic_delete, R.drawable.ic_expand_more, R.drawable.ic_edit, R.drawable.ic_star, R.drawable.ic_home,
    R.drawable.ic_star_outline, R.drawable.ic_camera, R.drawable.ic_person, R.drawable.ic_redo, R.drawable.ic_search,
    R.drawable.ic_undo, R.drawable.ic_mic, R.drawable.ic_chevron_right, R.drawable.ic_back,
    R.drawable.ic_phone_3d, R.drawable.ic_gear_3d,
)

@Composable
fun CWIcon(
    @DrawableRes id: Int,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = CW.colors.ivory,
    size: Dp = 24.dp,
    rotation: Float = 0f,
) {
    val m = modifier.size(size).then(if (rotation != 0f) Modifier.rotate(rotation) else Modifier)
    if (id in SuppliedIcons) {
        Image(
            painter = painterResource(id),
            contentDescription = contentDescription,
            modifier = m,
            contentScale = ContentScale.Fit,
            alpha = tint.alpha.coerceIn(0f, 1f),
        )
    } else {
        Icon(painter = painterResource(id), contentDescription = contentDescription, modifier = m, tint = tint)
    }
}

@Composable
fun CWIconButton(
    @DrawableRes id: Int,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = CW.colors.ivory,
    enabled: Boolean = true,
    size: Dp = 24.dp,
) {
    IconButton(onClick = onClick, modifier = modifier, enabled = enabled) {
        CWIcon(id, contentDescription, tint = if (enabled) tint else tint.copy(alpha = 0.35f), size = size)
    }
}

/** The supplied 3D warm-ivory phone icon, used for every call action. */
@Composable
fun PhoneIcon(modifier: Modifier = Modifier, size: Dp = 24.dp) {
    CWIcon(R.drawable.ic_phone_3d, "Call", modifier, size = size)
}

/** The supplied 3D warm-ivory gear icon. */
@Composable
fun GearIcon(modifier: Modifier = Modifier, size: Dp = 26.dp) {
    CWIcon(R.drawable.ic_gear_3d, "Settings", modifier, size = size)
}

@Composable
fun ScreenHeader(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            // the supplied chevron, mirrored by the asset itself (ic_back.png), never stretched
            IconButton(onClick = onBack) { CWIcon(R.drawable.ic_back, "Back", size = 22.dp) }
        } else {
            Spacer(Modifier.size(16.dp))
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = CW.colors.ivory,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        actions()
    }
}

// ====================================================================== bevel (the one shared surface treatment)

/**
 * Raised ("beveled-out") edge: a light top-left rim and a dark bottom-right rim drawn INSIDE the shape.
 * [amount] 0 = flat (nothing drawn) .. 1 = fully raised. Restrained on purpose: a 1.6dp rim, no heavy shadow.
 */
fun Modifier.bevelOut(radius: Dp, amount: Float): Modifier = drawWithContent {
    drawContent()
    if (amount > 0.01f) {
        val w = 1.6.dp.toPx()
        val r = (radius.toPx() - w / 2f).coerceAtLeast(0f)
        drawRoundRect(
            brush = Brush.linearGradient(
                0f to Color.White.copy(alpha = 0.24f * amount),
                0.5f to Color.Transparent,
                1f to Color.Black.copy(alpha = 0.45f * amount),
                start = Offset.Zero,
                end = Offset(size.width, size.height),
            ),
            topLeft = Offset(w / 2f, w / 2f),
            size = Size(size.width - w, size.height - w),
            cornerRadius = CornerRadius(r, r),
            style = Stroke(w),
        )
    }
}

/**
 * Recessed ("beveled-in") look for entry fields: a dark top-left inner rim, a faint light bottom-right rim and a soft
 * inner shadow along the top edge. Drawn over the field, inside its shape.
 */
fun Modifier.bevelIn(radius: Dp): Modifier = drawWithContent {
    drawContent()
    val w = 1.6.dp.toPx()
    val r = (radius.toPx() - w / 2f).coerceAtLeast(0f)
    drawRoundRect(
        brush = Brush.linearGradient(
            0f to Color.Black.copy(alpha = 0.55f),
            0.5f to Color.Transparent,
            1f to Color.White.copy(alpha = 0.10f),
            start = Offset.Zero,
            end = Offset(size.width, size.height),
        ),
        topLeft = Offset(w / 2f, w / 2f),
        size = Size(size.width - w, size.height - w),
        cornerRadius = CornerRadius(r, r),
        style = Stroke(w),
    )
    val clip = Path().apply {
        addRoundRect(androidx.compose.ui.geometry.RoundRect(0f, 0f, size.width, size.height, CornerRadius(radius.toPx())))
    }
    clipPath(clip) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Black.copy(alpha = 0.32f), Color.Transparent),
                startY = 0f,
                endY = 7.dp.toPx(),
            ),
        )
    }
}

// ====================================================================== buttons

/**
 * Solid matte themed button with a restrained raised bevel. Pressing lifts it slightly more and moves the fill to the
 * SAME theme's pressed tone (never another palette).
 *
 * @param fill / outline / textColor optional overrides (profile-setup Continue uses emerald fill + crimson outline).
 */
@Composable
fun CWButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    danger: Boolean = false,
    fill: Color? = null,
    outline: Color? = null,
    textColor: Color? = null,
) {
    val c = CW.colors
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val amount by animateFloatAsState(if (pressed && enabled) 1f else 0.55f, tween(80), label = "buttonBevel")
    val rest = fill ?: if (danger) c.field else c.panel
    val lifted = if (fill != null) lerp(fill, Color.White, 0.10f) else if (danger) lerp(c.field, Color.White, 0.08f) else c.panelPressed
    val bg = if (!enabled) c.surface else lerp(rest, lifted, if (pressed) 1f else 0f)
    val border = if (!enabled) c.field else outline ?: if (danger) c.danger else c.accent
    val label = if (!enabled) c.muted else textColor ?: if (danger) c.danger else c.ivory
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .height(48.dp)
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .bevelOut(10.dp, if (enabled) amount else 0f)
            .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = label, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Crimson label used by "Remove App PIN" in the Emerald theme (the button itself keeps the theme colours). */
@Composable
fun removePinTextColor(): Color = if (CW.colors.panel == EMERALD_CARD) BrandCrimson else CW.colors.ivory

@Composable
fun CWTextButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, danger: Boolean = false) {
    val c = CW.colors
    TextButton(onClick = onClick, modifier = modifier) {
        Text(text, color = if (danger) c.danger else c.ivory)
    }
}

// ====================================================================== input cards

/** Field label shown ABOVE the field with fixed spacing (so labels are never crowded against the previous field). */
@Composable
fun FieldLabel(text: String, invalid: Boolean = false, chip: Boolean = false) {
    val c = CW.colors
    if (chip) {
        val shape = RoundedCornerShape(6.dp)
        Box(
            Modifier
                .clip(shape)
                .background(c.panel)
                .border(1.dp, c.accent, shape)
                .padding(horizontal = 9.dp, vertical = 3.dp),
        ) { Text(text, color = c.ivory, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
    } else {
        Text(
            text,
            color = if (invalid) c.danger else c.muted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 2.dp),
        )
    }
}

/**
 * Entry field: solid recessed (bevel-in) card, thin outline, label above with 6dp gap.
 * States: focused (thicker outline), invalid (danger outline + message), disabled (dimmed).
 *
 * @param outline optional two-colour outline (profile setup uses crimson + emerald)
 * @param chipLabel draw the label as a filled theme-coloured chip (Profile Customization)
 */
@Composable
fun CWTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    error: String? = null,
    singleLine: Boolean = true,
    minLines: Int = 1,
    keyboardType: KeyboardType = KeyboardType.Text,
    enabled: Boolean = true,
    outline: Brush? = null,
    chipLabel: Boolean = false,
    placeholder: String? = null,
) {
    val c = CW.colors
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    val borderBrush: Brush = when {
        error != null -> SolidColor(c.danger)
        outline != null -> outline
        focused -> SolidColor(c.ivory.copy(alpha = 0.85f))
        else -> SolidColor(c.accent.copy(alpha = 0.7f))
    }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        FieldLabel(label, invalid = error != null, chip = chipLabel)
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            enabled = enabled,
            singleLine = singleLine,
            minLines = if (singleLine) 1 else minLines,
            textStyle = TextStyle(
                color = if (enabled) c.ivory else c.muted,
                fontSize = 15.sp,
                fontFamily = LocalRoboto.current,
            ),
            cursorBrush = SolidColor(c.ivory),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused },
            decorationBox = { inner ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clip(shape)
                        .background(if (enabled) c.inputWell else c.surface)
                        .border(if (focused || error != null) 1.5.dp else 1.dp, borderBrush, shape)
                        .bevelIn(10.dp)
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    contentAlignment = if (singleLine) Alignment.CenterStart else Alignment.TopStart,
                ) {
                    if (value.isEmpty() && placeholder != null) Text(placeholder, color = c.muted, fontSize = 15.sp)
                    inner()
                }
            },
        )
        if (error != null) {
            Text(error, color = c.danger, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp))
        }
    }
}

// ====================================================================== display cards

/**
 * Solid matte themed card (#78081C in Crimson, #051912 in Emerald), thin accent outline.
 * FLAT by default; raised (bevel-out, fill moves to the same theme's pressed tone) only while pressed, focused or
 * [selected]. Non-clickable cards stay flat.
 */
@Composable
fun PanelCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    selected: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
) {
    val c = CW.colors
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val focused by source.collectIsFocusedAsState()
    val amount by animateFloatAsState(if (pressed || focused || selected) 1f else 0f, tween(90), label = "cardRaise")
    val shape = RoundedCornerShape(12.dp)
    val base = modifier
        .fillMaxWidth()
        .shadow((3f * amount).dp, shape, clip = false)
        .clip(shape)
        .background(lerp(c.panel, c.panelPressed, amount))
        .border(1.dp, c.accent.copy(alpha = 0.7f), shape)
        .bevelOut(12.dp, amount)
    Box(
        if (onClick != null) base.clickable(interactionSource = source, indication = null, onClick = onClick) else base,
        content = content,
    )
}

/** Centered both ways inside whatever space the caller gives it (pass fillMaxSize / weight(1f) for a full-screen empty state). */
@Composable
fun EmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    @DrawableRes icon: Int = R.drawable.ic_person,
) {
    val c = CW.colors
    Box(modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            CWIcon(icon, null, size = 56.dp, tint = c.ivory.copy(alpha = 0.85f))
            Text(title, color = c.ivory, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, textAlign = TextAlign.Center)
            Text(message, color = c.muted, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    danger: Boolean = false,
    dismissLabel: String = "Cancel",
) {
    val c = CW.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        titleContentColor = c.ivory,
        textContentColor = c.muted,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { CWTextButton(confirmLabel, onConfirm, danger = danger) },
        dismissButton = { CWTextButton(dismissLabel, onDismiss) },
    )
}

@Composable
fun MessageDialog(title: String, text: String, onDismiss: () -> Unit, buttonLabel: String = "OK") {
    val c = CW.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        titleContentColor = c.ivory,
        textContentColor = c.muted,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { CWTextButton(buttonLabel, onDismiss) },
    )
}

// ====================================================================== avatars

/** Circle with the first letter of a name (contacts have no photos). */
@Composable
fun InitialAvatar(name: String, size: Dp, modifier: Modifier = Modifier) {
    val c = CW.colors
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(c.surface)
            .border(1.dp, c.ivory.copy(alpha = 0.55f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name.trim().firstOrNull()?.uppercase() ?: "?",
            color = c.ivory,
            fontWeight = FontWeight.SemiBold,
            fontSize = (size.value * 0.42f).sp,
        )
    }
}

/**
 * The user's local profile picture (decoded off the main thread) or an initial when none is set.
 * @param ring outline brush; default is the solid theme ring (crimson / emerald). Profile setup passes a two-colour ring.
 */
@Composable
fun ProfileAvatar(
    photoPath: String,
    photoVersion: Long,
    name: String,
    size: Dp,
    modifier: Modifier = Modifier,
    ring: Brush? = null,
    ringWidth: Dp = 2.dp,
) {
    val c = CW.colors
    val outline: Brush = ring ?: SolidColor(c.ring)
    val bitmap by produceState<ImageBitmap?>(initialValue = null, photoPath, photoVersion) {
        value = if (photoPath.isEmpty()) null else withContext(Dispatchers.IO) {
            runCatching { BitmapFactory.decodeFile(photoPath)?.asImageBitmap() }.getOrNull()
        }
    }
    val bmp = bitmap
    val frame = modifier
        .size(size)
        .clip(CircleShape)
        .border(ringWidth, outline, CircleShape)
    if (bmp != null) {
        Image(
            bitmap = bmp,
            contentDescription = "Profile picture",
            contentScale = ContentScale.Crop,
            modifier = frame,
        )
    } else {
        Box(frame.background(c.surface), contentAlignment = Alignment.Center) {
            Text(
                text = name.trim().firstOrNull()?.uppercase() ?: "?",
                color = c.ivory,
                fontWeight = FontWeight.SemiBold,
                fontSize = (size.value * 0.42f).sp,
            )
        }
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = CW.colors.muted,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        modifier = modifier.padding(horizontal = 4.dp, vertical = 4.dp),
    )
}

/** Charcoal background; working screens get a very faint theme-coloured corner accent (see [edgeAccent]). */
@Composable
fun FullScreenBackground(edges: Boolean = true, content: @Composable () -> Unit) {
    val c = CW.colors
    Box(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .then(if (edges) Modifier.edgeAccent(c.ring) else Modifier),
    ) { content() }
}
