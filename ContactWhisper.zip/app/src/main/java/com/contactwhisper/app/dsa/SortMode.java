package com.contactwhisper.app.dsa;

/** Sorting choices offered on the Home dashboard. */
public enum SortMode {
    A_Z("A–Z"),
    Z_A("Z–A"),
    RECENTLY_ADDED("Recently Added"),
    BY_CATEGORY("By Category");

    private final String label;

    SortMode(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
