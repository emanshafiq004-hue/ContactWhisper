package com.contactwhisper.app.dsa;

import java.util.ArrayList;
import java.util.List;

/**
 * Custom array-backed LIFO stack (deliberately NOT java.util.Stack). Two instances drive Undo/Redo.
 *
 * Complexity: push O(1) amortised (array doubles when full), pop O(1), peek O(1), clear O(n).
 */
public final class CustomStack<T> {
    private Object[] items = new Object[16];
    private int size;

    public void push(T value) {
        if (size == items.length) {
            Object[] bigger = new Object[items.length * 2];
            System.arraycopy(items, 0, bigger, 0, size);
            items = bigger;
        }
        items[size++] = value;
    }

    @SuppressWarnings("unchecked")
    public T pop() {
        if (size == 0) throw new IllegalStateException("stack is empty");
        T value = (T) items[--size];
        items[size] = null; // do not keep the removed element alive
        return value;
    }

    @SuppressWarnings("unchecked")
    public T peek() {
        if (size == 0) throw new IllegalStateException("stack is empty");
        return (T) items[size - 1];
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void clear() {
        for (int i = 0; i < size; i++) items[i] = null;
        size = 0;
    }

    /**
     * Removes every element matching the predicate while keeping the relative order of the rest.
     * O(n) in-place compaction (used to invalidate Undo/Redo history by contact id).
     * @return how many elements were removed
     */
    @SuppressWarnings("unchecked")
    public int removeIf(java.util.function.Predicate<? super T> filter) {
        int kept = 0;
        for (int i = 0; i < size; i++) {
            T value = (T) items[i];
            if (!filter.test(value)) items[kept++] = value;
        }
        int removed = size - kept;
        for (int i = kept; i < size; i++) items[i] = null;
        size = kept;
        return removed;
    }

    /** Top-first copy, for tests and debugging. */
    @SuppressWarnings("unchecked")
    public List<T> toListTopFirst() {
        List<T> out = new ArrayList<>(size);
        for (int i = size - 1; i >= 0; i--) out.add((T) items[i]);
        return out;
    }
}
