package com.contactwhisper.app.dsa;

/**
 * One reversible user operation, stored as full before/after snapshots so Undo/Redo can restore the
 * exact fields. These objects live on the two {@link CustomStack}s inside {@link UndoRedoManager}.
 *
 *  ADD      : before = null,   after = the new record
 *  EDIT     : before = old,    after = new
 *  DELETE   : before = record, after = null   (delete = move to the Recycle Bin)
 *  FAVORITE : before/after differ only in the favorite flag
 *  CATEGORY : before/after differ only in the category
 *  RESTORE  : before = null,   after = the record that was brought back from the Bin
 *
 * History entries are immutable snapshots plus the stable contact id. Room is always re-read when an entry is
 * applied, and entries are purged by id ({@link UndoRedoManager#purgeContacts}) when a contact is permanently deleted.
 */
public final class UndoableAction {
    public enum Type { ADD, EDIT, DELETE, FAVORITE, CATEGORY, RESTORE }

    private final Type type;
    private final ContactRecord before;
    private final ContactRecord after;

    private UndoableAction(Type type, ContactRecord before, ContactRecord after) {
        this.type = type;
        this.before = before;
        this.after = after;
    }

    public static UndoableAction add(ContactRecord created) {
        return new UndoableAction(Type.ADD, null, created);
    }

    public static UndoableAction edit(ContactRecord before, ContactRecord after) {
        return new UndoableAction(Type.EDIT, before, after);
    }

    public static UndoableAction delete(ContactRecord removed) {
        return new UndoableAction(Type.DELETE, removed, null);
    }

    public static UndoableAction restore(ContactRecord restored) {
        return new UndoableAction(Type.RESTORE, null, restored);
    }

    public static UndoableAction favorite(ContactRecord before, ContactRecord after) {
        return new UndoableAction(Type.FAVORITE, before, after);
    }

    public static UndoableAction category(ContactRecord before, ContactRecord after) {
        return new UndoableAction(Type.CATEGORY, before, after);
    }

    public Type getType() { return type; }
    public ContactRecord getBefore() { return before; }
    public ContactRecord getAfter() { return after; }

    /** Id of the contact the action concerns. */
    public long getContactId() {
        return before != null ? before.getId() : after.getId();
    }

    /** Short label for the "Undone: ..." / "Redone: ..." messages. */
    public String getLabel() {
        switch (type) {
            case ADD: return "Add contact";
            case EDIT: return "Edit contact";
            case DELETE: return "Delete contact";
            case FAVORITE: return "Favorite change";
            case CATEGORY: return "Category change";
            case RESTORE: return "Restore contact";
            default: return "Change";
        }
    }
}
