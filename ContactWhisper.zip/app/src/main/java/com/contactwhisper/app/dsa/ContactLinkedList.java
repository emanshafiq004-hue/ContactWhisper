package com.contactwhisper.app.dsa;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Custom singly linked list holding the in-memory working collection of active contacts.
 *
 * Complexity (n = number of contacts):
 *  - insertFirst / insertLast : O(1)  (head and tail pointers are both kept)
 *  - findById / update / remove: O(n) (linear walk; the hash tables provide O(1) key lookups)
 *  - iteration / toArray       : O(n)
 *
 * Practical role: the single ordered owner of every active {@link ContactRecord}. The
 * {@link ContactHashTable} indexes only store ids and are resolved back through this list.
 */
public final class ContactLinkedList implements Iterable<ContactRecord> {
    private ContactNode head;
    private ContactNode tail;
    private int size;

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    /** O(1). New contacts are shown first in natural list order. */
    public void insertFirst(ContactRecord record) {
        ContactNode node = new ContactNode(record);
        node.next = head;
        head = node;
        if (tail == null) tail = node;
        size++;
    }

    /** O(1). Used when rebuilding from the database so the stored order is preserved. */
    public void insertLast(ContactRecord record) {
        ContactNode node = new ContactNode(record);
        if (tail == null) {
            head = tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
        size++;
    }

    /** O(n). Returns the record with this id or null. */
    public ContactRecord findById(long id) {
        for (ContactNode n = head; n != null; n = n.next) {
            if (n.data.getId() == id) return n.data;
        }
        return null;
    }

    public boolean contains(long id) {
        return findById(id) != null;
    }

    /** O(n). Replaces the record that has {@code replacement.getId()}. Returns the old record or null. */
    public ContactRecord update(ContactRecord replacement) {
        for (ContactNode n = head; n != null; n = n.next) {
            if (n.data.getId() == replacement.getId()) {
                ContactRecord old = n.data;
                n.data = replacement;
                return old;
            }
        }
        return null;
    }

    /** O(n). Unlinks the node with this id. Returns the removed record or null. */
    public ContactRecord remove(long id) {
        ContactNode prev = null;
        for (ContactNode n = head; n != null; prev = n, n = n.next) {
            if (n.data.getId() == id) {
                if (prev == null) head = n.next; else prev.next = n.next;
                if (n == tail) tail = prev;
                size--;
                return n.data;
            }
        }
        return null;
    }

    public void clear() {
        head = null;
        tail = null;
        size = 0;
    }

    /** O(n) snapshot, safe to hand to other threads. */
    public ContactRecord[] toArray() {
        ContactRecord[] out = new ContactRecord[size];
        int i = 0;
        for (ContactNode n = head; n != null; n = n.next) out[i++] = n.data;
        return out;
    }

    @Override
    public Iterator<ContactRecord> iterator() {
        return new Iterator<ContactRecord>() {
            private ContactNode cursor = head;

            @Override
            public boolean hasNext() {
                return cursor != null;
            }

            @Override
            public ContactRecord next() {
                if (cursor == null) throw new NoSuchElementException();
                ContactRecord r = cursor.data;
                cursor = cursor.next;
                return r;
            }
        };
    }
}
