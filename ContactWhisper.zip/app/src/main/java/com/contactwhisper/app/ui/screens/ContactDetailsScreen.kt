package com.contactwhisper.app.ui.screens

import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.ui.components.CWIcon
import com.contactwhisper.app.ui.components.CWIconButton
import com.contactwhisper.app.ui.components.InitialAvatar
import com.contactwhisper.app.ui.components.PanelCard
import com.contactwhisper.app.ui.components.PhoneIcon
import com.contactwhisper.app.ui.components.ScreenHeader
import com.contactwhisper.app.ui.components.formatDate
import com.contactwhisper.app.ui.theme.CW

/** Shows exactly what is stored (empty optional fields are simply not shown) with Call / Edit / Delete below. */
@Composable
fun ContactDetailsScreen(
    vm: AppViewModel,
    contactId: Long,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onCall: (String) -> Unit,
) {
    val c = CW.colors
    val all by vm.visibleAll.collectAsStateWithLifecycle()
    val contact = all.firstOrNull { it.id == contactId }

    if (contact == null) {
        // Deleted: leave this screen once.
        LaunchedEffect(Unit) { onBack() }
        return
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Contact Details",
            onBack = onBack,
            actions = {
                CWIconButton(
                    id = if (contact.isFavorite) R.drawable.ic_star else R.drawable.ic_star_outline,
                    contentDescription = if (contact.isFavorite) "Remove from favorites" else "Add to favorites",
                    onClick = { vm.toggleFavorite(contact) },
                )
            },
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            PanelCard {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    InitialAvatar(contact.name, 64.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(contact.name, color = c.ivory, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Text(contact.phone, color = c.muted, fontSize = 15.sp)
                    }
                }
            }

            PanelCard {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    InfoLine(R.drawable.ic_email, "Email", contact.email)
                    InfoLine(R.drawable.ic_location, "Address", contact.address)
                    InfoLine(R.drawable.ic_notes, "Notes", contact.notes)
                    InfoLine(R.drawable.ic_category, "Category", contact.category)
                    if (contact.email.isBlank() && contact.address.isBlank() && contact.notes.isBlank() && contact.category.isBlank()) {
                        Text("No other details saved.", color = c.muted, fontSize = 13.sp)
                    }
                }
            }
            Text(
                "Added ${formatDate(contact.createdAt)}  ·  Updated ${formatDate(contact.updatedAt)}",
                color = c.muted,
                fontSize = 12.sp,
            )

            // ---- the three main actions, below the information
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionTile("Call", false, { onCall(contact.phone) }, Modifier.weight(1f)) { PhoneIcon(size = 26.dp) }
                ActionTile("Edit", false, onEdit, Modifier.weight(1f)) { CWIcon(R.drawable.ic_edit, null, size = 26.dp) }
                ActionTile("Delete", true, { vm.deleteContact(contact.id) }, Modifier.weight(1f)) {
                    CWIcon(R.drawable.ic_delete, null, tint = c.danger, size = 26.dp)
                }
            }
            Text(
                "Delete moves the contact to the Recycle Bin for 30 days.",
                color = c.muted,
                fontSize = 12.sp,
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

/** One label/value line; nothing is rendered for an empty value so no field is ever invented. */
@Composable
private fun InfoLine(@DrawableRes icon: Int, label: String, value: String) {
    if (value.isBlank()) return
    val c = CW.colors
    Row(verticalAlignment = Alignment.Top) {
        CWIcon(icon, null, tint = c.accent, size = 22.dp)
        Spacer(Modifier.width(14.dp))
        Column {
            Text(label, color = c.muted, fontSize = 12.sp)
            Text(value, color = c.ivory, fontSize = 15.sp)
        }
    }
}

@Composable
private fun ActionTile(
    label: String,
    danger: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit,
) {
    val c = CW.colors
    PanelCard(modifier = modifier.height(76.dp), onClick = onClick) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            icon()
            Spacer(Modifier.height(4.dp))
            Text(label, color = if (danger) c.danger else c.ivory, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}
