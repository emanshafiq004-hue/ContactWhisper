package com.contactwhisper.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.IOException

enum class AppTheme { CRIMSON, EMERALD }

enum class LockMethod { BIOMETRIC, PIN }

data class AppSettings(
    val loaded: Boolean = false,
    val profileDone: Boolean = false,
    val name: String = "",
    val email: String = "",
    val about: String = "",
    val photoPath: String = "",
    val photoVersion: Long = 0L,
    val theme: AppTheme = AppTheme.CRIMSON,
    val appLockEnabled: Boolean = false,
    val lockMethod: LockMethod = LockMethod.BIOMETRIC,
    val hasPin: Boolean = false,
    /** "" = the first-launch phonebook import has not been offered yet, "done" = imported, "declined" = skipped or refused. */
    val contactImport: String = "",
    /** The CALL_PHONE permission is requested at most once (on the first call attempt); afterwards the dialer is used. */
    val callPermAsked: Boolean = false,
)

private val Context.cwDataStore: DataStore<Preferences> by preferencesDataStore(name = "contactwhisper_settings")

/** Profile, theme, App Lock and PIN settings, persisted with Jetpack DataStore (survives restarts). */
class SettingsStore(private val context: Context) {

    private object Keys {
        val profileDone = booleanPreferencesKey("profile_done")
        val name = stringPreferencesKey("profile_name")
        val email = stringPreferencesKey("profile_email")
        val about = stringPreferencesKey("profile_about")
        val photoPath = stringPreferencesKey("profile_photo_path")
        val photoVersion = longPreferencesKey("profile_photo_version")
        val theme = stringPreferencesKey("theme")
        val lockEnabled = booleanPreferencesKey("app_lock_enabled")
        val lockMethod = stringPreferencesKey("lock_method")
        val pinHash = stringPreferencesKey("pin_hash")
        val pinSalt = stringPreferencesKey("pin_salt")
        val emergencySeeded = booleanPreferencesKey("emergency_seeded")
        val contactImport = stringPreferencesKey("contact_import")
        val callPermAsked = booleanPreferencesKey("call_perm_asked")
    }

    private val store get() = context.cwDataStore

    val settings: Flow<AppSettings> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            AppSettings(
                loaded = true,
                profileDone = p[Keys.profileDone] ?: false,
                name = p[Keys.name].orEmpty(),
                email = p[Keys.email].orEmpty(),
                about = p[Keys.about].orEmpty(),
                photoPath = p[Keys.photoPath].orEmpty(),
                photoVersion = p[Keys.photoVersion] ?: 0L,
                theme = p[Keys.theme]?.let { runCatching { AppTheme.valueOf(it) }.getOrNull() } ?: AppTheme.CRIMSON,
                appLockEnabled = p[Keys.lockEnabled] ?: false,
                lockMethod = p[Keys.lockMethod]?.let { runCatching { LockMethod.valueOf(it) }.getOrNull() }
                    ?: LockMethod.BIOMETRIC,
                hasPin = !p[Keys.pinHash].isNullOrEmpty() && !p[Keys.pinSalt].isNullOrEmpty(),
                contactImport = p[Keys.contactImport].orEmpty(),
                callPermAsked = p[Keys.callPermAsked] ?: false,
            )
        }

    suspend fun saveProfile(name: String, email: String, about: String) {
        store.edit {
            it[Keys.name] = name.trim()
            it[Keys.email] = email.trim()
            it[Keys.about] = about.trim()
            it[Keys.profileDone] = true
        }
    }

    suspend fun setProfilePhoto(path: String) {
        store.edit {
            it[Keys.photoPath] = path
            it[Keys.photoVersion] = System.currentTimeMillis()
        }
    }

    suspend fun setTheme(theme: AppTheme) {
        store.edit { it[Keys.theme] = theme.name }
    }

    suspend fun setAppLockEnabled(enabled: Boolean) {
        store.edit { it[Keys.lockEnabled] = enabled }
    }

    suspend fun setLockMethod(method: LockMethod) {
        store.edit { it[Keys.lockMethod] = method.name }
    }

    /** Stores a salted PBKDF2 hash of the PIN (never the PIN). Hashing runs off the main thread. */
    suspend fun setPin(pin: String) {
        val (salt, hash) = withContext(Dispatchers.Default) {
            val s = PinHasher.newSalt()
            s to PinHasher.hash(pin, s)
        }
        store.edit {
            it[Keys.pinSalt] = PinHasher.encode(salt)
            it[Keys.pinHash] = PinHasher.encode(hash)
        }
    }

    suspend fun clearPin() {
        store.edit {
            it.remove(Keys.pinSalt)
            it.remove(Keys.pinHash)
            // Without a PIN, the PIN method cannot work: fall back to biometric/device credential.
            it[Keys.lockMethod] = LockMethod.BIOMETRIC.name
        }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val prefs = store.data.first()
        val salt = prefs[Keys.pinSalt] ?: return false
        val hash = prefs[Keys.pinHash] ?: return false
        return withContext(Dispatchers.Default) {
            runCatching { PinHasher.verify(pin, PinHasher.decode(salt), PinHasher.decode(hash)) }.getOrDefault(false)
        }
    }

    suspend fun setContactImport(state: String) {
        store.edit { it[Keys.contactImport] = state }
    }

    suspend fun markCallPermAsked() {
        store.edit { it[Keys.callPermAsked] = true }
    }

    suspend fun isEmergencySeeded(): Boolean = store.data.first()[Keys.emergencySeeded] ?: false

    suspend fun markEmergencySeeded() {
        store.edit { it[Keys.emergencySeeded] = true }
    }
}
