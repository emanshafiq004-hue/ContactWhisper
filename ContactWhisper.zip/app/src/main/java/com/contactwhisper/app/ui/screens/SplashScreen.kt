package com.contactwhisper.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.contactwhisper.app.AppViewModel
import com.contactwhisper.app.R
import com.contactwhisper.app.ui.components.GradientText
import com.contactwhisper.app.ui.components.cornerGlows
import com.contactwhisper.app.ui.theme.CW
import kotlinx.coroutines.delay

/**
 * Brief splash: updated icon, "Contact Whisper" in the crimson-to-emerald gradient, the ivory tagline and a smaller,
 * lighter supporting line. Very soft crimson + emerald glows sit strictly in the corners; no loading text.
 * It leaves as soon as storage and settings are ready (short fixed hold so the branding is readable).
 */
@Composable
fun SplashScreen(vm: AppViewModel, onFinished: (profileDone: Boolean) -> Unit) {
    val c = CW.colors
    val ready by vm.ready.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    LaunchedEffect(ready, settings.loaded) {
        if (ready && settings.loaded) {
            delay(900)
            onFinished(settings.profileDone)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(c.background)
            .cornerGlows(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 24.dp),
        ) {
            Image(
                painter = painterResource(R.drawable.app_icon),
                contentDescription = "Contact Whisper icon",
                modifier = Modifier.size(140.dp),
            )
            Spacer(Modifier.height(20.dp))
            GradientText("Contact Whisper", fontSize = 32.sp)
            Spacer(Modifier.height(6.dp))
            Text("Smart Contact Manager", color = c.ivory, fontSize = 16.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text(
                "Every Contact, One Whisper Away.",
                color = c.ivory.copy(alpha = 0.6f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
            )
        }
    }
}
