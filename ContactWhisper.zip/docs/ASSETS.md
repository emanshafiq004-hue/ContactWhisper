# Assets: what is used, what is derived, what is missing

All supplied artwork lives in `app/src/main/res/drawable-nodpi/` under the **same resource names the old vector icons had**,
so no call site changed. `CWIcon` draws these as images (never tinted: the artwork is already warm ivory); every other icon
is still a tinted vector placeholder.

## Supplied and used

| Resource | Source | Where it is used |
|---|---|---|
| `app_icon.png` (512 px) | your new app icon | splash, About, lock screen |
| `ic_launcher_foreground.png` (432 px) + `ic_launcher_background` `#101214` | same icon, plate scaled to ~2/3 for the adaptive-icon safe zone | launcher icon |
| `developer_watermark.png` (900x250) | your "Eman Game Dev" watermark, cropped to its artwork | About, bottom of "Meet the Developer" |
| `ic_phone_3d.png`, `ic_gear_3d.png` | earlier supplied | every Call action; Home settings gear |
| `ic_search.png`, `ic_mic.png` | icons.zip | inside the Home search field; voice assistant |
| `ic_undo.png`, `ic_redo.png` | icons.zip | Home header |
| `ic_expand_more.png` | icons.zip (sort arrow) | Sort by, every dropdown, every category row (far right) |
| `ic_back.png` | icons.zip "go to" chevron, **mirrored**, checkerboard removed | back arrow of every screen header (Bin included) |
| `ic_chevron_right.png` | icons.zip "go to" chevron, cleaned | Settings rows, Emergency panel |
| `ic_camera.png` | icons.zip | profile photo badge (setup and Profile Customization) |
| `ic_home.png`, `ic_category.png`, `ic_star.png`, `ic_delete.png` | icons.zip | the four bottom tabs; Favorite, Category and Delete actions |
| `ic_star_outline.png` | icons.zip | not-a-favorite state |
| `ic_add.png`, `ic_edit.png` (downscaled from 4096 px) | icons.zip | Add contact / category / emergency; Rename and Edit |
| `ic_info.png`, `ic_lock.png`, `ic_palette.png`, `ic_person.png` | icons.zip | Settings rows and avatars |

## Missing (no supplied artwork; a consistent tinted vector placeholder is used)

| Needed | Placeholder (expected replacement path) |
|---|---|
| Email | `res/drawable/ic_email.xml` |
| Location / address | `res/drawable/ic_location.xml` |
| Notes | `res/drawable/ic_notes.xml` |
| Close (x) | `res/drawable/ic_close.xml` |
| Check / selected | `res/drawable/ic_check.xml` |
| Emergency Services | `res/drawable/ic_emergency.xml` |
| Restore (Bin) | `res/drawable/ic_restore.xml` |
| Select all | `res/drawable/ic_select_all.xml` |
| Collapse arrow | `res/drawable/ic_expand_less.xml` (rows rotate the supplied arrow instead) |
| **Roboto font files** | `res/font/roboto_regular.ttf`, `res/font/roboto_medium.ttf`, `res/font/roboto_bold.ttf` |

To replace any placeholder, drop a PNG with the same name into `drawable-nodpi/` and delete the vector; for an icon that
should stay tinted, do **not** add its id to the `SuppliedIcons` list in `ui/components/Common.kt`.

### Roboto

Roboto is a Google font that was not part of the supplied files and could not be downloaded in the build sandbox. The theme
(`ui/theme/Theme.kt`) looks the three files up **by name at run time** and uses them for every text style, dialog, menu and the
voice interface. Until the files exist the app falls back to the platform sans-serif (Roboto on stock Android, but not
guaranteed on every Vivo ROM). Adding the three TTFs above is all that is needed; no code change.

## Honest notes

* The watermark artwork is dark on a transparent background, so it is tinted warm ivory at run time (45 % opacity) to be
  visible on the charcoal card. Replace `developer_watermark.png` with a light version and remove the `colorFilter` in
  `InfoScreens.kt` if you prefer the original colours.
* The smoke reference video was inspected but **not** composited into the app (no usable alpha channel, and a video would
  show a black rectangle). The delete effect is a procedural approximation, see README section 3.
